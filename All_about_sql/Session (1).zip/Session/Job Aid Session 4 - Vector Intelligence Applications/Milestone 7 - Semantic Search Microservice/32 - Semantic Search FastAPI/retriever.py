"""Top-k retrieval against pgvector — consults both parallel columns."""
from __future__ import annotations

import os
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Iterator

import psycopg
from dotenv import load_dotenv
from pgvector.psycopg import HalfVector, register_vector

from providers import EmbedResult

load_dotenv()
SUPABASE_DB_URL = os.environ["SUPABASE_DB_URL"]


@dataclass
class Hit:
    id: int
    payload: dict
    similarity: float
    provider_used: str


@contextmanager
def _conn() -> Iterator[psycopg.Connection]:
    with psycopg.connect(SUPABASE_DB_URL) as conn:
        register_vector(conn)
        yield conn


def _column_for(result: EmbedResult) -> str:
    return "embedding_gemini" if result.provider == "gemini" else "embedding_nvidia"


def _cast_for(result: EmbedResult) -> str:
    return "halfvec" if result.provider == "nvidia" else "vector"


def _bind_vec(result: EmbedResult):
    """Wrap the query vector in HalfVector when targeting the halfvec column."""
    if result.provider == "nvidia":
        return HalfVector(result.vector)
    return list(result.vector)


def search_companies(q: EmbedResult, k: int = 5) -> list[Hit]:
    col = _column_for(q)
    cast = _cast_for(q)
    sql = f"""
        SELECT c.company_id, c.name, c.overview_text,
               1 - (e.{col} <=> %s::{cast}) AS similarity
        FROM   company_embeddings e
        JOIN   companies c ON c.company_id = e.company_id
        WHERE  e.field_name = 'overview_text'
          AND  e.{col} IS NOT NULL
        ORDER  BY e.{col} <=> %s::{cast}
        LIMIT  %s;
    """
    with _conn() as conn, conn.cursor() as cur:
        bound = _bind_vec(q)
        cur.execute(sql, (bound, bound, k))
        rows = cur.fetchall()
    return [
        Hit(
            id=row[0],
            payload={"name": row[1], "overview_text": row[2]},
            similarity=float(row[3]),
            provider_used=q.provider,
        )
        for row in rows
    ]


def search_projects(q: EmbedResult, k: int = 5) -> list[Hit]:
    col = _column_for(q)
    cast = _cast_for(q)
    sql = f"""
        SELECT i.innovx_id, i.company_id, i.project_idx,
               1 - (i.{col} <=> %s::{cast}) AS similarity
        FROM   innovx_embeddings i
        WHERE  i.{col} IS NOT NULL
        ORDER  BY i.{col} <=> %s::{cast}
        LIMIT  %s;
    """
    with _conn() as conn, conn.cursor() as cur:
        bound = _bind_vec(q)
        cur.execute(sql, (bound, bound, k))
        rows = cur.fetchall()
    return [
        Hit(
            id=row[0],
            payload={"company_id": row[1], "project_idx": row[2]},
            similarity=float(row[3]),
            provider_used=q.provider,
        )
        for row in rows
    ]


def similar_to_company(company_id: int, k: int = 5) -> list[Hit]:
    """'More like this' — compare against the stored vector of a specific company."""
    sql = """
        WITH seed AS (
            SELECT embedding_gemini AS g, embedding_nvidia AS n
            FROM   company_embeddings
            WHERE  company_id = %s AND field_name = 'overview_text'
            LIMIT  1
        )
        SELECT c.company_id, c.name, c.overview_text,
               CASE WHEN (SELECT g FROM seed) IS NOT NULL
                    THEN 1 - (e.embedding_gemini <=> (SELECT g FROM seed))
                    ELSE 1 - (e.embedding_nvidia <=> (SELECT n FROM seed))
               END AS similarity
        FROM   company_embeddings e
        JOIN   companies c ON c.company_id = e.company_id
        WHERE  e.field_name = 'overview_text'
          AND  e.company_id <> %s
        ORDER  BY similarity DESC
        LIMIT  %s;
    """
    with _conn() as conn, conn.cursor() as cur:
        cur.execute(sql, (company_id, company_id, k))
        rows = cur.fetchall()
    return [
        Hit(
            id=row[0],
            payload={"name": row[1], "overview_text": row[2]},
            similarity=float(row[3]) if row[3] is not None else 0.0,
            provider_used="mixed",
        )
        for row in rows
    ]
