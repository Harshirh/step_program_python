"""Embedding providers (self-contained — no reuse from Milestone 7).

Primary  : gemini-embedding-2-preview            (Gemini API)
Fallback : nvidia/llama-nemotron-embed-vl-1b-v2:free  (OpenRouter)
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Literal

from dotenv import load_dotenv
from rich.console import Console

load_dotenv()
_console = Console()

GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]
OPENROUTER_API_KEY = os.environ["OPENROUTER_API_KEY"]
GEMINI_OUTPUT_DIM = int(os.getenv("GEMINI_OUTPUT_DIM", "768"))

EMBED_PRIMARY = "gemini-embedding-2-preview"
EMBED_FALLBACK = "nvidia/llama-nemotron-embed-vl-1b-v2:free"


@dataclass(frozen=True)
class EmbedResult:
    provider: Literal["gemini", "nvidia"]
    model: str
    vector: list[float]


_gemini_client = None
_openrouter_client = None


def _gemini():
    global _gemini_client
    if _gemini_client is None:
        from google import genai
        _gemini_client = genai.Client(api_key=GEMINI_API_KEY)
    return _gemini_client


def _openrouter():
    global _openrouter_client
    if _openrouter_client is None:
        from openai import OpenAI
        _openrouter_client = OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=OPENROUTER_API_KEY,
        )
    return _openrouter_client


def embed(text: str) -> EmbedResult:
    _console.print(f"[dim]  → Gemini: embedding {len(text)} chars (dim={GEMINI_OUTPUT_DIM})[/]")
    try:
        resp = _gemini().models.embed_content(
            model=EMBED_PRIMARY,
            contents=[text],
            config={"output_dimensionality": GEMINI_OUTPUT_DIM},
        )
        vec = list(resp.embeddings[0].values)
        _console.print(f"[green]  ✓ Gemini OK — dim={len(vec)}[/]")
        return EmbedResult(provider="gemini", model=EMBED_PRIMARY, vector=vec)
    except Exception as e:  # noqa: BLE001
        _console.print(f"[yellow]  ! Gemini failed: {type(e).__name__}: {e}[/]")
        # encoding_format="float" forces float output; OpenAI-compat providers
        # ignore the SDK's default base64 request and the SDK then mis-parses
        # the response as ValueError: No embedding data received.
        resp = _openrouter().embeddings.create(
            model=EMBED_FALLBACK,
            input=text,
            encoding_format="float",
        )
        vec = list(resp.data[0].embedding)
        _console.print(f"[green]  ✓ NVIDIA OK — dim={len(vec)}[/]")
        return EmbedResult(provider="nvidia", model=EMBED_FALLBACK, vector=vec)
