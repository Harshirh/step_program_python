# 34 — Train / Serve Split  *(PPT — 5 min)*

## Why we do not train in the classroom

Training would mean:

- Pulling every `company_embeddings.embedding_gemini` row into pandas.
- Joining `companies.category` as the label.
- A train/test split, fitting LogReg, tracking accuracy.
- ~5 minutes of silence while scikit-learn runs.

None of that teaches anything students will use tomorrow. Instead we ship a **pre-trained artifact** — `artifacts/category_classifier.joblib` — and the class focuses on the *serving* pattern.

## The artifact contract

The `.joblib` file loaded by `main.py` is a `sklearn.pipeline.Pipeline` with exactly two stages:

```
Pipeline([
    ("scaler", StandardScaler(with_mean=False)),
    ("clf",    LogisticRegression(max_iter=1000, multi_class="auto")),
])
```

Fit on `X = company_embeddings.embedding_gemini (dim=768)` and `y = companies.category`. The pipeline exposes `.classes_` and `.predict_proba()` — that is the entire interface `main.py` depends on.

## Loading at startup, not per-request

```python
from joblib import load
MODEL = load("artifacts/category_classifier.joblib")   # ~seconds, once

@app.post("/predict/category")
def predict(...):
    probs = MODEL.predict_proba(vec_2d)                # ~microseconds
    ...
```

Reloading on every request would pay the disk-read cost per call and make memory pressure unpredictable.

## What if the artifact is missing

The service starts with a loud log line:

```
[15:22:10] ! artifacts/category_classifier.joblib not found
[15:22:10] ! /predict/category will return 503 until the file is provided
```

`/placement/fit` keeps working — it does not need the model.

## How students get the artifact

Option A (default): the instructor supplies a pre-trained `.joblib` via shared drive. Drop it into `artifacts/`.

Option B (advanced / optional homework): a `train.py` script that reads Supabase, fits the pipeline, and writes the `.joblib`. Not graded, not required for class.
