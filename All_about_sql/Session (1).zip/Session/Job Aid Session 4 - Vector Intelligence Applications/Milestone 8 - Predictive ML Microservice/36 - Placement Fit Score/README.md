# 36 — Placement Fit Score  *(Hands-On — 20 min)*

Adds one endpoint — `POST /placement/fit` — to the **same** FastAPI app from item 35 (`:8004`). No new venv, no second uvicorn process.

## Endpoint

```
POST /placement/fit
{
  "candidate_profile": "Python developer with 3 years in NLP, experience with LangChain and Supabase...",
  "top_n": 3
}
```

Response:

```json
{
  "candidate_embedding_provider": "gemini",
  "overall_best": {
    "company_id": 7,
    "company_name": "Fractal Analytics",
    "fit_percent": 82.4
  },
  "top_n": [
    {"company_id": 7,  "company_name": "Fractal Analytics", "fit_percent": 82.4},
    {"company_id": 12, "company_name": "TigerAnalytics",    "fit_percent": 78.1},
    {"company_id": 3,  "company_name": "Tredence",          "fit_percent": 76.9}
  ]
}
```

## How it works

1. Embed `candidate_profile` via Gemini primary / NVIDIA fallback.
2. For every company with a stored `overview_text` embedding, compute cosine similarity in SQL.
3. Convert similarity → percent (`100 * (1 - cosine_distance)`).
4. Return `top_n` ranked by fit.

**No model is trained for this endpoint.** The "ML" is the embedding geometry itself.

## Why this sits in the ML microservice, not the Search one

Semantically it feels like search. Operationally it is a prediction surface used by placement teams — the call site and SLA are closer to the classifier than to semantic search. Keeping it alongside `/predict/category` makes the microservice boundary "Predictive" rather than "Search".

## Terminal trace

```
[15:40:05] ▶ POST /placement/fit
[15:40:05]   → Gemini: embedding 184 chars (dim=768)
[15:40:06]   ✓ Gemini OK — dim=768
[15:40:06]   · querying company_embeddings (gemini column), top_n=3
[15:40:06]   ✓ best fit: Fractal Analytics (82.4%)
[15:40:06] ← 200 OK in 0.9s
```

## Files

This item **does not** ship new files. The `/placement/fit` route is already implemented in `35 - Category Classifier/main.py` — this folder is documentation only, kept separate so the job-aid numbering stays aligned with the lesson plan.

If you would prefer the route in its own file, extract the `/placement/fit` section of `main.py` into `placement.py` and include it via `app.include_router(...)` — optional refactor, not required.

## Intentional non-scope

- No candidate filters (location, notice period).
- No company-side weighting (role demand, current openings).
- No hybrid score (skills + overview). Overview text only.
