import { useState, useEffect, useRef, memo } from "react";
import {
  Star, ExternalLink, Play, Building2, Target, Users, Banknote,
  Globe2, Package, Cpu, Handshake, Swords, LineChart, Gem, Leaf,
  Newspaper, PieChart, ShieldAlert, MapPin, ShieldCheck, GraduationCap,
  Award, Briefcase, Globe, Phone, Twitter, Facebook, Instagram, Linkedin,
  CalendarDays, Users2, TrendingUp, DollarSign
} from "lucide-react";
import { motion } from "framer-motion";
import { buildIntelligenceSections, type IntelligenceField, type IntelligenceSection } from "@/data/intelligenceData";
import { fetchCompany, fetchCompanyDetail } from "@/lib/serviceApi";
import { useCompany } from "@/context/CompanyContext";
import { normalizeCompanyProfile } from "@/lib/companyData";
import { CompanyLogo } from "@/components/ui/CompanyLogo";


const SKILL_PILL_COLORS = [
  "bg-[#eff6ff] text-[#1d4ed8] border border-[#bfdbfe]",
  "bg-[#f5f3ff] text-[#7c3aed] border border-[#ddd6fe]",
  "bg-[#ecfeff] text-[#0f766e] border border-[#a5f3fc]",
  "bg-[#fff7ed] text-[#c2410c] border border-[#fed7aa]",
  "bg-[#f0fdf4] text-[#15803d] border border-[#bbf7d0]",
  "bg-[#fef2f2] text-[#b91c1c] border border-[#fecaca]",
];

const SECTION_ICONS: Record<string, React.ReactNode> = {
  "Company Identity": <Building2 className="w-4 h-4" />,
  "Overview & Vision": <Target className="w-4 h-4" />,
  "Leadership": <Users className="w-4 h-4" />,
  "Funding & Financials": <Banknote className="w-4 h-4" />,
  "Global Presence": <Globe2 className="w-4 h-4" />,
  "Products & Services": <Package className="w-4 h-4" />,
  "Technology Stack": <Cpu className="w-4 h-4" />,
  "Partnerships & Ecosystem": <Handshake className="w-4 h-4" />,
  "Competitive Landscape": <Swords className="w-4 h-4" />,
  "Market Opportunity": <LineChart className="w-4 h-4" />,
  "Core Value Proposition & ESG": <Gem className="w-4 h-4" />,
  "Culture & Work Life": <Leaf className="w-4 h-4" />,
  "Recent News & Milestones": <Newspaper className="w-4 h-4" />,
  "Sales & Customer Metrics": <PieChart className="w-4 h-4" />,
  "Risk & Compliance": <ShieldAlert className="w-4 h-4" />,
  "Work Location & Commute": <MapPin className="w-4 h-4" />,
  "Safety & Wellbeing": <ShieldCheck className="w-4 h-4" />,
  "Career Growth & Learning": <GraduationCap className="w-4 h-4" />,
  "Brand & Reputation": <Award className="w-4 h-4" />,
  "Compensation & Benefits": <Briefcase className="w-4 h-4" />,
  "Digital Presence & Ratings": <Globe className="w-4 h-4" />,
  "Contact Information": <Phone className="w-4 h-4" />,
};

// Ensures any URL from the DB opens correctly in a new tab
const toAbsoluteUrl = (url: string): string => {
  const trimmed = url.trim();
  if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return trimmed;
  if (trimmed.startsWith("@")) return `https://twitter.com/${trimmed.replace("@", "")}`;
  return `https://${trimmed}`;
};

const isNullish = (v: string) => {
  const n = v.trim().toLowerCase();
  return n === "n/a" || n === "na" || n === "null" || n === "-" || n === "none";
};

const renderValue = (field: IntelligenceField) => {
  const { value, type } = field;
  if (!value) return null;
  if (isNullish(value)) {
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded bg-secondary/80 text-[11px] font-semibold text-muted-foreground font-body uppercase tracking-wider">
        Not Available
      </span>
    );
  }
  if (type === "url") {
    let href = value;
    let displayValue = value;
    if (value.startsWith("@")) {
      href = `https://twitter.com/${value.substring(1)}`;
    } else if (!value.startsWith("http")) {
      href = `https://${value}`;
      displayValue = value.replace(/^https?:\/\//, "");
    } else {
      displayValue = value.replace(/^https?:\/\//, "");
    }
    return (
      <a href={href} target="_blank" rel="noopener noreferrer"
        className="inline-flex items-center gap-1 font-body text-sm font-semibold text-dream hover:underline underline-offset-2 break-all">
        {displayValue}
        <ExternalLink className="w-3.5 h-3.5 shrink-0" />
      </a>
    );
  }
  if (type === "video") {
    const href = value.startsWith("http") ? value : `https://${value}`;
    return (
      <a href={href} target="_blank" rel="noopener noreferrer"
        className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-dream text-white hover:bg-dream/90 transition-colors text-sm font-bold font-body">
        <Play className="w-3.5 h-3.5 fill-current" />
        Watch Video
      </a>
    );
  }
  if (type === "rating") {
    return (
      <span className="inline-flex items-center gap-1.5 text-sm font-semibold font-body text-foreground">
        <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
        {value}
      </span>
    );
  }
  if (type === "list") {
    const items = value.split(/[;,]/).map((s) => s.trim()).filter(Boolean);
    if (items.length <= 1) return <p className="font-body text-sm font-semibold text-foreground leading-relaxed">{value}</p>;
    return (
      <div className="flex flex-wrap gap-1.5">
        {items.map((item, i) => (
          <span key={i} className={`font-body text-xs font-semibold px-2.5 py-0.5 rounded-full ${SKILL_PILL_COLORS[i % SKILL_PILL_COLORS.length]}`}>
            {item}
          </span>
        ))}
      </div>
    );
  }
  if (type === "paragraph") {
    return <p className="text-sm font-body font-medium text-foreground/90 leading-relaxed whitespace-pre-wrap">{value}</p>;
  }
  // Auto-detect semicolon/comma-separated atomic values and render as pills
  if (value.includes(";") || (value.includes(",") && value.split(",").length > 2 && !/,\d{3}/.test(value))) {
    const items = value.split(/[;,]/).map((s) => s.trim()).filter(Boolean);
    if (items.length > 1) {
      return (
        <div className="flex flex-wrap gap-1.5">
          {items.map((item, i) => (
            <span
              key={i}
              className={`font-body text-xs font-semibold px-2.5 py-0.5 rounded-full ${SKILL_PILL_COLORS[i % SKILL_PILL_COLORS.length]}`}
            >
              {item}
            </span>
          ))}
        </div>
      );
    }
  }
  return <p className="text-sm font-semibold font-body text-foreground leading-snug">{value}</p>;
};

const FieldRow = memo(({ field, isLast }: { field: IntelligenceField; isLast: boolean }) => (
  <div className={`group flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-4 py-3 sm:py-3.5 px-2 -mx-2 hover:bg-muted/30 transition-colors rounded-lg ${!isLast ? "border-b border-border/30" : ""}`}>
    <div className="sm:w-1/3 shrink-0 sm:pt-0.5">
      <p className="font-body text-[13px] font-medium text-muted-foreground">{field.label}</p>
    </div>
    <div className="sm:w-2/3 min-w-0 break-words">{renderValue(field)}</div>
  </div>
));

const SectionHeader = memo(({ section, count }: { section: IntelligenceSection; count: number }) => (
  <div className="flex items-center gap-2.5 px-4 py-3 md:px-5 md:py-3.5 border-b border-border/50">
    <span className="text-muted-foreground shrink-0">{SECTION_ICONS[section.title] ?? <Building2 className="w-4 h-4" />}</span>
    <h2 className="font-heading font-semibold text-sm md:text-base text-foreground truncate">{section.title}</h2>
    {count > 0 && (
      <span className="ml-0.5 text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-secondary text-muted-foreground font-body shrink-0 tabular-nums">
        {count}
      </span>
    )}
  </div>
));

const IdentitySection = memo(({ section, sectionRef }: {
  section: IntelligenceSection;
  sectionRef: (el: HTMLDivElement | null) => void;
}) => {
  const nonEmpty = section.fields.filter(f => f.value && f.value.trim() !== "");
  return (
    <motion.div ref={sectionRef} id="section-company-identity"
      initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}
      className="bg-card rounded-xl shadow-sm border border-border/50 overflow-hidden">
      <SectionHeader section={section} count={nonEmpty.length} />
      <div className="px-4 py-2 md:px-5 md:py-3">
        {nonEmpty.length > 0 ? (
          nonEmpty.map((field, i) => <FieldRow key={i} field={field} isLast={i === nonEmpty.length - 1} />)
        ) : (
          <div className="py-6 text-center"><p className="font-body text-sm text-muted-foreground">No data points available.</p></div>
        )}
      </div>
    </motion.div>
  );
});

interface SectionCardProps {
  section: IntelligenceSection;
  index: number;
  sectionRef: (el: HTMLDivElement | null) => void;
}

const SectionCard = memo(({ section, index, sectionRef }: SectionCardProps) => {
  const nonEmptyFields = section.fields.filter(f => f.value && f.value.trim() !== "");
  return (
    <motion.div ref={sectionRef} id={`section-${section.title.replace(/\s+/g, "-").toLowerCase()}`}
      initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.03, duration: 0.3 }}
      className="bg-card rounded-xl shadow-sm border border-border/50 overflow-hidden">
      <SectionHeader section={section} count={nonEmptyFields.length} />
      <div className="px-4 py-2 md:px-5 md:py-3">
        {nonEmptyFields.length > 0
          ? nonEmptyFields.map((field, i) => <FieldRow key={i} field={field} isLast={i === nonEmptyFields.length - 1} />)
          : <div className="py-6 text-center"><p className="font-body text-sm text-muted-foreground">No data points available.</p></div>
        }
      </div>
    </motion.div>
  );
});

const CompanyIntelligence = () => {
  const [sections, setSections] = useState<IntelligenceSection[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(0);
  const [heroInView, setHeroInView] = useState(true);
  const { companyId, companyName, logoUrl } = useCompany();
  const [resolvedLogoUrl, setResolvedLogoUrl] = useState(logoUrl);

  const [identityMeta, setIdentityMeta] = useState({
    category: "", companyType: "", websiteUrl: "",
    linkedinUrl: "", twitterHandle: "", facebookUrl: "",
    instagramUrl: "", officeLocations: "",
    foundedYear: "", employeeSize: "", annualRevenue: "",
    ceoName: "", industry: "", companyMaturity: "",
  });

  const resetIdentityMeta = () => {
    setIdentityMeta({
      category: "", companyType: "", websiteUrl: "",
      linkedinUrl: "", twitterHandle: "", facebookUrl: "",
      instagramUrl: "", officeLocations: "",
      foundedYear: "", employeeSize: "", annualRevenue: "",
      ceoName: "", industry: "", companyMaturity: "",
    });
  };

  const getWebsiteUrl = () => {
    if (identityMeta.websiteUrl) return identityMeta.websiteUrl;
    const s = sections.find(s => s.title === "Digital Presence & Ratings");
    return s?.fields.find(f => f.label === "Website URL")?.value || "";
  };

  const sectionRefs = useRef<(HTMLDivElement | null)[]>([]);
  const tabBarRef = useRef<HTMLDivElement>(null);
  const heroRef = useRef<HTMLDivElement>(null);
  const tabRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const isScrollingRef = useRef(false);

  useEffect(() => {
    setResolvedLogoUrl(logoUrl);
  }, [logoUrl]);

  useEffect(() => {
    const fetchLogo = async () => {
      if (!companyId || logoUrl) return;
      try {
        const companyJson = await fetchCompany(companyId);
        const shortJson = companyJson.short_json as Record<string, unknown> | undefined;
        const dbLogoUrl = typeof shortJson?.logo_url === "string" ? shortJson.logo_url : "";
        if (dbLogoUrl) {
          setResolvedLogoUrl(dbLogoUrl);
        }
      } catch {
        // Keep page rendering even when logo lookup fails.
      }
    };

    fetchLogo();
  }, [companyId, logoUrl]);

  useEffect(() => {
    const fetchData = async () => {
      if (!companyId) {
        setSections([]);
        resetIdentityMeta();
        setLoading(false);
        return;
      }
      try {
        const data = await fetchCompanyDetail(companyId);
        if (!data) {
          setSections([]);
          resetIdentityMeta();
        } else {
          const profile = normalizeCompanyProfile(data);
          const built = buildIntelligenceSections(profile.merged);
          setSections(built); extractIdentityMeta(built);
        }
      } catch (error) {
        console.error("Company intelligence fetch error:", error);
        setSections([]);
        resetIdentityMeta();
      }
      setLoading(false);
    };
    fetchData();
  }, [companyId]);

  const extractIdentityMeta = (sects: IntelligenceSection[]) => {
    const identity = sects.find(s => s.title === "Company Identity");
    const presence = sects.find(s => s.title === "Digital Presence & Ratings");
    const global = sects.find(s => s.title === "Global Presence");
    const leadership = sects.find(s => s.title === "Leadership");
    const financials = sects.find(s => s.title === "Funding & Financials");
    if (!identity) return;
    setIdentityMeta({
      category: identity.fields.find(f => f.label === "Category")?.value ?? "",
      companyType: identity.fields.find(f => f.label === "Company Type")?.value ?? "",
      foundedYear: identity.fields.find(f => f.label === "Year of Incorporation")?.value ?? "",
      employeeSize: identity.fields.find(f => f.label === "Employee Size")?.value ?? "",
      companyMaturity: identity.fields.find(f => f.label === "Company Maturity")?.value ?? "",
      industry: identity.fields.find(f => f.label === "Nature of Company")?.value ?? "",
      websiteUrl: presence?.fields.find(f => f.label === "Website URL")?.value ?? "",
      linkedinUrl: presence?.fields.find(f => f.label === "LinkedIn Profile URL")?.value ?? "",
      twitterHandle: presence?.fields.find(f => f.label === "Twitter (X) Handle")?.value ?? "",
      facebookUrl: presence?.fields.find(f => f.label === "Facebook Page URL")?.value ?? "",
      instagramUrl: presence?.fields.find(f => f.label === "Instagram Page URL")?.value ?? "",
      officeLocations: global?.fields.find(f => f.label === "Office Locations")?.value ?? "",
      ceoName: leadership?.fields.find(f => f.label === "CEO / Founder Name")?.value ?? "",
      annualRevenue: financials?.fields.find(f => f.label === "Annual Revenue")?.value ?? "",
    });
  };

  const getScrollContainer = (): HTMLElement =>
    (document.querySelector("main") as HTMLElement) ?? document.documentElement;

  const getHeaderOffset = () => heroInView ? 56 : 108;

  useEffect(() => {
    if (loading || sections.length === 0) return;
    const timer = setTimeout(() => {
      const container = getScrollContainer();
      let currentIdx = -1;
      const onScroll = () => {
        if (isScrollingRef.current) return;
        const cTop = container.getBoundingClientRect().top;

        if (heroRef.current) {
          const heroBottom = heroRef.current.getBoundingClientRect().bottom;
          setHeroInView(heroBottom > cTop + 10);
        }

        let closest = 0, minDist = Infinity;
        sectionRefs.current.forEach((el, i) => {
          if (!el) return;
          // Use headerHeight for precise tab sticky offset
          const d = Math.abs(el.getBoundingClientRect().top - cTop - getHeaderOffset() - 48);
          if (d < minDist) { minDist = d; closest = i; }
        });
        if (currentIdx !== closest) {
          currentIdx = closest; setActiveTab(closest);
          const tab = tabRefs.current[closest];
          if (tab && tabBarRef.current) {
            tabBarRef.current.scrollTo({ left: tab.offsetLeft - tabBarRef.current.offsetWidth / 2 + tab.offsetWidth / 2, behavior: "smooth" });
          }
        }
      };
      container.addEventListener("scroll", onScroll, { passive: true });
      return () => container.removeEventListener("scroll", onScroll);
    }, 300);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, sections]);

  const scrollToSection = (idx: number) => {
    isScrollingRef.current = true;
    setActiveTab(idx);
    const el = sectionRefs.current[idx];
    const container = getScrollContainer();
    if (el && container) {
      const newTop = el.getBoundingClientRect().top - container.getBoundingClientRect().top + container.scrollTop - getHeaderOffset() - 48;
      container.scrollTo({ top: newTop, behavior: "smooth" });
    }
    const tab = tabRefs.current[idx];
    if (tab && tabBarRef.current) {
      tabBarRef.current.scrollTo({ left: tab.offsetLeft - tabBarRef.current.offsetWidth / 2 + tab.offsetWidth / 2, behavior: "smooth" });
    }
    setTimeout(() => { isScrollingRef.current = false; }, 900);
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="rounded-xl bg-muted animate-pulse h-36 md:h-44" />
        <div className="h-9 bg-muted rounded-xl animate-pulse" />
        {[...Array(4)].map((_, i) => <div key={i} className="h-32 bg-card rounded-xl border border-border/50 animate-pulse" />)}
      </div>
    );
  }

  const catColor =
    identityMeta.category.toLowerCase().includes("super dream")
      ? "bg-super-dream/20 text-super-dream border-super-dream/30"
      : identityMeta.category.toLowerCase().includes("dream")
        ? "bg-dream/20 text-dream border-dream/30"
        : "bg-emerald-500/20 text-emerald-300 border-emerald-400/30";

  const websiteUrl = getWebsiteUrl();

  return (
    <div className="flex flex-col pb-8">

      {/* ── HERO ─────────────────────────────────────────────────────────── */}
      <motion.div
        ref={heroRef}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-xl p-5 md:p-8 text-white relative overflow-hidden shadow-sm"
        style={{ background: "linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%)" }}
        role="banner"
      >
        <div className="absolute top-0 right-0 w-[300px] h-[300px] sm:w-[500px] sm:h-[500px] bg-blue-500/10 rounded-full blur-[80px] sm:blur-[100px] -translate-y-1/2 translate-x-1/3 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[250px] h-[250px] sm:w-[400px] sm:h-[400px] bg-indigo-500/10 rounded-full blur-[60px] sm:blur-[80px] translate-y-1/3 -translate-x-1/3 pointer-events-none" />

        <div className="relative z-10 flex flex-col justify-center h-full">

          {/* ── Row 1: platform label + social icons ── */}
          <div className="flex justify-between items-start mb-4">
            <span className="inline-block text-[10px] uppercase tracking-widest text-white/50 bg-white/10 px-3 py-1 rounded-full font-heading font-semibold">
              SRM UNIVERSITY � INTELLIGENCE PLATFORM
            </span>

            {/* Social Icons right-aligned at top */}
            <div className="flex items-center gap-1.5 hidden sm:flex">
              {identityMeta.linkedinUrl && !isNullish(identityMeta.linkedinUrl) && (
                <a href={toAbsoluteUrl(identityMeta.linkedinUrl)} target="_blank" rel="noopener noreferrer"
                  className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/5 hover:bg-white/15 text-white/70 hover:text-white transition-all border border-white/10">
                  <Linkedin className="w-4 h-4" />
                </a>
              )}
              {identityMeta.twitterHandle && !isNullish(identityMeta.twitterHandle) && (
                <a href={toAbsoluteUrl(identityMeta.twitterHandle)} target="_blank" rel="noopener noreferrer"
                  className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/5 hover:bg-white/15 text-white/70 hover:text-white transition-all border border-white/10">
                  <Twitter className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>

          {/* ── Row 2: logo + name + badges + website ── */}
          <div className="flex items-start gap-4 mb-2">
            {/* Logo */}
            <div className="w-16 h-16 rounded-xl bg-white border border-border/50 flex items-center justify-center overflow-hidden flex-shrink-0 shadow-lg">
              <CompanyLogo
                name={companyName || "Company"}
                databaseLogoUrl={resolvedLogoUrl}
                className="w-full h-full object-contain p-2"
              />
            </div>

            {/* Name + badges + website */}
            <div className="min-w-0 flex-1 pt-1">
              <h1 className="font-heading text-2xl md:text-3xl lg:text-4xl font-bold text-white tracking-tight leading-tight mb-2">
                {companyName || "Company Intelligence"}
              </h1>

              <div className="flex flex-wrap items-center gap-2 mb-2">
                {identityMeta.category && !isNullish(identityMeta.category) && (
                  <span className={`font-body text-[10px] sm:text-[11px] font-bold px-2.5 py-1 rounded-md border backdrop-blur-md ${catColor.replace('bg-', 'bg-transparent border-white/20 text-').split(' ')[1] || 'text-white/90 bg-white/10 border-white/10'}`}>
                    {identityMeta.category}
                  </span>
                )}
                {identityMeta.companyType && !isNullish(identityMeta.companyType) && (
                  <span className="font-body text-[10px] sm:text-[11px] text-white/80 font-semibold bg-white/10 border border-white/10 px-2.5 py-1 rounded-md backdrop-blur-md">
                    {identityMeta.companyType}
                  </span>
                )}
                {identityMeta.industry && !isNullish(identityMeta.industry) && (
                  <span className="font-body text-[10px] sm:text-[11px] text-white/60 font-medium px-1">
                    · {identityMeta.industry}
                  </span>
                )}
              </div>

              {/* Website */}
              {websiteUrl && !isNullish(websiteUrl) && (
                <a href={toAbsoluteUrl(websiteUrl)}
                  target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 font-body text-[12px] sm:text-[13px] text-blue-300 hover:text-blue-200 transition-colors group">
                  <Globe className="w-3.5 h-3.5" />
                  <span className="group-hover:underline underline-offset-4">{websiteUrl.replace(/^https?:\/\//, '').replace(/\/$/, '')}</span>
                  <ExternalLink className="w-3 h-3 opacity-60 ml-0.5" />
                </a>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      {/* ── Extracted Stat Grid (Premium Bento Cards on Page Background) ── */}
      <div className="mt-4 mb-2">
        {(() => {
          const stats = ([
            identityMeta.foundedYear && !isNullish(identityMeta.foundedYear) && { icon: <CalendarDays className="w-4 h-4" />, label: "Founded", value: identityMeta.foundedYear },
            identityMeta.employeeSize && !isNullish(identityMeta.employeeSize) && { icon: <Users2 className="w-4 h-4" />, label: "Employees", value: identityMeta.employeeSize },
            identityMeta.ceoName && !isNullish(identityMeta.ceoName) && { icon: <Users className="w-4 h-4" />, label: "CEO", value: identityMeta.ceoName },
            identityMeta.annualRevenue && !isNullish(identityMeta.annualRevenue) && { icon: <DollarSign className="w-4 h-4" />, label: "Revenue", value: identityMeta.annualRevenue },
            identityMeta.companyMaturity && !isNullish(identityMeta.companyMaturity) && { icon: <TrendingUp className="w-4 h-4" />, label: "Stage", value: identityMeta.companyMaturity },
          ] as any[]).filter(Boolean);
          if (!stats.length) return null;
          return (
            <div className="flex flex-wrap items-stretch gap-3">
              {stats.map((stat: any, i: number) => (
                <div
                  key={i}
                  className="flex-1 min-w-[160px] flex flex-col justify-center gap-1.5 bg-card border border-border/60 hover:border-border transition-colors rounded-xl p-3.5 shadow-sm"
                >
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    {stat.icon}
                    <p className="font-body text-[10px] sm:text-[11px] uppercase tracking-widest font-semibold">{stat.label}</p>
                  </div>
                  <p className="font-heading text-[14px] sm:text-[15px] font-bold text-foreground leading-snug">{stat.value}</p>
                </div>
              ))}
            </div>
          );
        })()}
      </div>
      {/* TAB NAV (STICKY) */}
      <div
        className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border/50 -mx-4 px-4 md:-mx-6 md:px-6 lg:-mx-8 lg:px-8 shadow-sm transition-all duration-300 flex flex-col pt-3"
      >
        {/* Compact Header that appears on scroll */}
        <div className={`flex items-center gap-3 overflow-hidden transition-all duration-300 ${!heroInView ? "h-[52px] opacity-100 mb-2" : "h-0 opacity-0 mb-0"}`}>
          <div className="w-10 h-10 rounded-lg bg-white border border-border/50 flex items-center justify-center p-1 shrink-0 shadow-sm">
            <CompanyLogo
              name={companyName || "Company"}
              databaseLogoUrl={resolvedLogoUrl}
              className="w-full h-full object-contain"
            />
          </div>

          <div className="flex flex-col min-w-0 flex-1 justify-center">
            <div className="flex items-center gap-2">
              <span className="font-heading font-bold text-sm md:text-base text-foreground truncate leading-none pt-0.5">
                {companyName || "Company Intelligence"}
              </span>
              {websiteUrl && !isNullish(websiteUrl) && (
                <a href={toAbsoluteUrl(websiteUrl)} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground shrink-0 hidden sm:block">
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>

            <div className="flex items-center gap-2.5 mt-1.5 text-[10px] sm:text-[11px] text-muted-foreground whitespace-nowrap overflow-hidden mask-fade-right">
              {identityMeta.category && !isNullish(identityMeta.category) && (
                <span className="font-semibold uppercase tracking-wider text-foreground/80 bg-secondary/80 px-1.5 py-0.5 rounded-[4px] leading-none flex items-center shrink-0">
                  {identityMeta.category}
                </span>
              )}
              {identityMeta.companyMaturity && !isNullish(identityMeta.companyMaturity) && (
                <span className="flex items-center gap-1 shrink-0">
                  <TrendingUp className="w-3 h-3" />
                  <span className="truncate">{identityMeta.companyMaturity}</span>
                </span>
              )}
              {identityMeta.employeeSize && !isNullish(identityMeta.employeeSize) && (
                <span className="flex items-center gap-1 shrink-0">
                  <Users2 className="w-3 h-3" />
                  {identityMeta.employeeSize}
                </span>
              )}
            </div>
          </div>
        </div>

        <div
          ref={tabBarRef}
          className="flex gap-1.5 overflow-x-auto pb-3"
          role="tablist"
          style={{ WebkitOverflowScrolling: "touch", scrollbarWidth: "none" }}
        >
          {sections.map((section, idx) => {
            const isActive = activeTab === idx;
            return (
              <button
                key={section.title}
                ref={el => { tabRefs.current[idx] = el; }}
                role="tab"
                aria-selected={isActive}
                onClick={() => scrollToSection(idx)}
                className={`
                  flex items-center gap-1.5 whitespace-nowrap px-3 py-1.5 rounded-full text-[12px] font-body font-semibold
                  transition-all duration-200 shrink-0 border
                  ${isActive
                    ? "bg-dream text-white border-dream shadow-sm"
                    : "bg-secondary/60 text-muted-foreground border-transparent hover:bg-secondary hover:text-foreground"
                  }
                `}
              >
                <span className="w-3.5 h-3.5 shrink-0 flex items-center justify-center">
                  {SECTION_ICONS[section.title] ?? <Building2 className="w-3.5 h-3.5" />}
                </span>
                {section.title}
              </button>
            );
          })}
        </div>
      </div>

      {/* SECTIONS */}
      <div className="flex flex-col gap-4 mt-5">
        {sections.length === 0 && (
          <div className="bg-card rounded-xl shadow-sm border border-border/50 p-6 text-center">
            <p className="font-body text-sm text-muted-foreground">No company intelligence data is available for this company.</p>
          </div>
        )}
        {sections.map((section, idx) => {
          if (section.title === "Company Identity") {
            return (
              <IdentitySection
                key={section.title}
                section={section}
                sectionRef={el => { sectionRefs.current[idx] = el; }}
              />
            );
          }
          return (
            <SectionCard
              key={section.title}
              section={section}
              index={idx}
              sectionRef={el => { sectionRefs.current[idx] = el; }}
            />
          );
        })}
      </div>
    </div>
  );
};

export default CompanyIntelligence;
