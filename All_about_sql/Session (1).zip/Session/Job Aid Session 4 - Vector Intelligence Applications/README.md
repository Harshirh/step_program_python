# Job Aid Session 4 — Vector Intelligence Applications

Day 4 of the program. Two standalone microservices built on the embeddings written by Session 3. Each has its own venv and `.env` — no reuse from any earlier session.

## Scope

| Milestone | Focus | Items | Port |
|-----------|-------|-------|------|
| **Milestone 7** | Semantic Search microservice — top-k retrieval + LLM re-ranking. | 30 – 32 | `:8003` |
| **Milestone 8** | Predictive ML microservice — category classifier + placement-fit score. | 33 – 36 | `:8004` |

## Prerequisite

You must have successfully run Session 3 Milestone 6 `backfill.py`. The following tables must be populated in your Supabase project:

- `company_embeddings`
- `innovx_embeddings`
- `skill_embeddings`

Session 4 **reads** from these tables — it does not write to them.

## Provider Wiring

| Purpose | Primary | Fallback |
|---------|---------|----------|
| Query-time embeddings | `gemini-embedding-2-preview` | `nvidia/llama-nemotron-embed-vl-1b-v2:free` |
| LLM re-rank (Milestone 7 only) | `openai/gpt-oss-120b:free` (OpenRouter) | `nvidia/nemotron-3-super-120b-a12b:free` (OpenRouter) |

Both LLM calls are **streamed** and every token/chunk is mirrored to the terminal so students see progress instead of a hanging curl.

## Folder layout

```
Job Aid Session 4 - Vector Intelligence Applications/
├── README.md
├── Milestone 7 - Semantic Search Microservice/
│   ├── 30 - What is Semantic Search.md
│   ├── 31 - LangChain Retrievers and pgvector.md
│   └── 32 - Semantic Search FastAPI/
│       ├── README.md
│       ├── requirements.txt
│       ├── .env.example
│       ├── providers.py      (embed + chat with fallback, streaming)
│       ├── retriever.py      (pgvector top-k + LLM rerank)
│       └── main.py           (FastAPI :8003)
└── Milestone 8 - Predictive ML Microservice/
    ├── 33 - From Embeddings to Predictions.md
    ├── 34 - Train Serve Split.md
    ├── 35 - Category Classifier/
    │   ├── README.md
    │   ├── requirements.txt
    │   ├── .env.example
    │   ├── main.py           (FastAPI :8004 /predict/category)
    │   └── artifacts/
    │       └── README.md     (drop the pre-trained .joblib here)
    └── 36 - Placement Fit Score/
        ├── README.md
        └── main.py           (adds /placement/fit to the same :8004 service)
```

## End-of-day deliverables

- `POST /search/companies` — semantic company search with optional LLM rerank.
- `POST /search/projects`  — semantic InnovX project search.
- `GET  /similar/{company_id}` — "more like this" with LLM explanation.
- `POST /predict/category` — classify a company overview into its category.
- `POST /placement/fit`    — cosine-fit score between a candidate skill profile and every company.
