import { useState, useEffect } from "react";

interface CompanyLogoProps {
  name: string;
  websiteUrl?: string; // Kept for interface compatibility
  databaseLogoUrl?: string;
  className?: string;
}

export const CompanyLogo = ({ name, databaseLogoUrl, className = "" }: CompanyLogoProps) => {
  const [imgSrc, setImgSrc] = useState<string | null>(null);
  const [hasError, setHasError] = useState(false);

  const getCompanyInitials = (name: string) => {
    return name
      .split(" ")
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase() || "")
      .join("");
  };

  useEffect(() => {
    // Determine the source - strictly databaseLogoUrl without external APIs
    if (databaseLogoUrl && !hasError) {
      setImgSrc(databaseLogoUrl);
    } else {
      setImgSrc(null); // Fallback to initials
    }
  }, [databaseLogoUrl, hasError]);

  const handleError = () => {
    setHasError(true);
    setImgSrc(null);
  };

  if (!imgSrc) {
    return (
      <div className="w-full h-full flex items-center justify-center text-white font-heading font-bold text-sm bg-navy rounded-lg">
        {getCompanyInitials(name)}
      </div>
    );
  }

  return (
    <img
      src={imgSrc}
      alt={`${name} logo`}
      className={className}
      onError={handleError}
      loading="lazy"
    />
  );
};
