import { useState, useMemo, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Search, X, Users, TrendingUp, TrendingDown, MapPin, ArrowRight } from "lucide-react";
import { fetchCompanies } from "@/lib/serviceApi";
import { useCompany } from "@/context/CompanyContext";
import { normalizeCompanySummary, type CompanySummary } from "@/lib/companyData";
import { CompanyLogo } from "@/components/ui/CompanyLogo";
import React from "react";

const filterPills = [
  { label: "All", activeClass: "bg-foreground text-background border-foreground" },
  { label: "Super Dream", activeClass: "bg-[#7c3aed] text-white border-[#7c3aed]" },
  { label: "Dream", activeClass: "bg-[#2563eb] text-white border-[#2563eb]" },
  { label: "Standard", activeClass: "bg-[#16a34a] text-white border-[#16a34a]" },
  { label: "Regular", activeClass: "bg-[#d97706] text-white border-[#d97706]" },
] as const;

const NA_VALUES = new Set(["na", "n/a", "none", "-", "--", "null", "undefined", "not available", "n.a.", "n.a"]);
const cleanValue = (v: string): string => (NA_VALUES.has(v.trim().toLowerCase()) ? "" : v.trim());

function getCompanyTypeColor(companyType: string) {
  const colors: Record<string, string> = {
    "Super Dream": "bg-[#7c3aed]/10 text-[#7c3aed] border-[#7c3aed]/20",
    "Dream": "bg-[#2563eb]/10 text-[#2563eb] border-[#2563eb]/20",
    "Standard": "bg-[#16a34a]/10 text-[#16a34a] border-[#16a34a]/20",
    "Regular": "bg-[#d97706]/10 text-[#d97706] border-[#d97706]/20",
  };
  return colors[companyType] || "bg-secondary text-secondary-foreground border-transparent";
}

// ─── CompanyCard hoisted OUTSIDE Index to make React.memo effective ───────────
// Defining it inside Index caused it to be redeclared every render,
// completely defeating memoization even though the component uses React.memo.
const CompanyCard = React.memo(
  ({
    company,
    index,
    onClick,
  }: {
    company: CompanySummary;
    index: number;
    onClick: (c: CompanySummary) => void;
  }) => {
    const companyTypeColor = getCompanyTypeColor(company.companyType);

    return (
      <button
        type="button"
        style={{ animationDelay: `${index * 30}ms`, animationFillMode: "both" }}
        className="text-left block w-full bg-card rounded-xl shadow-sm transition-all duration-200 cursor-pointer border border-border/50 animate-in fade-in slide-in-from-bottom-4 will-change-transform relative"
        onClick={() => onClick(company)}
      >
        <div className="p-5">
          {/* Top row: logo + badge */}
          <div className="flex items-start justify-between mb-4">
            <div className="w-16 h-16 rounded-xl bg-white border border-border/40 flex items-center justify-center overflow-hidden flex-shrink-0 p-2 shadow-sm">
              <CompanyLogo
                name={company.name}
                websiteUrl={company.websiteUrl}
                databaseLogoUrl={company.logoUrl}
                className="w-full h-full object-contain"
              />
            </div>
            {company.companyType && (
              <span className={`text-[10px] font-semibold px-2.5 py-0.5 rounded-full border ${companyTypeColor}`}>
                {company.companyType}
              </span>
            )}
          </div>

          {/* Name block */}
          <h3 title={company.name} className="font-heading font-bold text-[15px] text-foreground truncate mb-0.5">
            {company.name}
          </h3>
          {company.shortName && (
            <p title={company.shortName} className="font-body text-[12px] text-muted-foreground truncate mb-4">
              {company.shortName}
            </p>
          )}

          {/* Info rows */}
          <div className="space-y-2">
            {(() => {
              const loc = cleanValue(company.headquartersLocation || "");
              return (
                <div className="flex items-center gap-1.5" title={loc || "not publicly available"}>
                  <MapPin className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                  <span className={`text-[12px] truncate ${loc ? "text-muted-foreground" : "text-muted-foreground/60 italic"}`}>
                    {loc || "not publicly available"}
                  </span>
                </div>
              );
            })()}
            {(() => {
              const size = cleanValue(company.employeeSize || "");
              return (
                <div className="flex items-center gap-1.5" title={size || "not publicly available"}>
                  <Users className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                  <span className={`text-[12px] truncate ${size ? "text-muted-foreground" : "text-muted-foreground/60 italic"}`}>
                    {size || "not publicly available"}
                  </span>
                </div>
              );
            })()}
            {(() => {
              const growth = cleanValue(company.yoyGrowthRate || "");
              const isNegative = growth && growth.trim().startsWith("-");
              if (!growth) {
                return (
                  <div className="flex items-center gap-1.5">
                    <TrendingUp className="w-3.5 h-3.5 text-muted-foreground/60 shrink-0" />
                    <span className="text-[12px] text-muted-foreground/60 italic truncate">
                      not publicly available
                    </span>
                  </div>
                );
              }
              return (
                <div className="flex items-center gap-1.5">
                  {isNegative
                    ? <TrendingDown className="w-3.5 h-3.5 text-red-500 shrink-0" />
                    : <TrendingUp className="w-3.5 h-3.5 text-emerald-500 shrink-0" />}
                  <span className={`text-[12px] font-medium truncate ${isNegative ? "text-red-600" : "text-emerald-600"}`}>
                    {growth}
                  </span>
                </div>
              );
            })()}
          </div>

          {/* Static Arrow */}
          <div className="absolute bottom-3 right-4 pointer-events-none">
            <ArrowRight className="w-4 h-4 text-muted-foreground/50 stroke-[1.5]" />
          </div>
        </div>
      </button>
    );
  }
);

CompanyCard.displayName = "CompanyCard";

// ─── Index Page ───────────────────────────────────────────────────────────────
const Index = () => {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [activeCompanyType, setActiveCompanyType] = useState("All");

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 200);
    return () => clearTimeout(timer);
  }, [search]);

  const [companies, setCompanies] = useState<CompanySummary[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { setCompany } = useCompany();

  useEffect(() => {
    const loadCompanies = async () => {
      setLoading(true);
      try {
        const data = await fetchCompanies();
        const parsed = (data || []).map((row: any) => {
          return normalizeCompanySummary(row);
        });
        setCompanies(parsed);
      } catch (error) {
        console.error("Error fetching companies:", error);
      } finally {
        setLoading(false);
      }
    };

    loadCompanies();
  }, []);

  const filtered = useMemo(() => {
    return companies.filter((c) => {
      const matchSearch = c.name.toLowerCase().includes(debouncedSearch.toLowerCase());
      const matchType = activeCompanyType === "All" || (c.companyType || "Unspecified") === activeCompanyType;
      return matchSearch && matchType;
    });
  }, [debouncedSearch, activeCompanyType, companies]);

  const counts = useMemo(() => {
    const searchFiltered = companies.filter((c) =>
      c.name.toLowerCase().includes(debouncedSearch.toLowerCase())
    );

    const map: Record<string, number> = { All: searchFiltered.length };
    searchFiltered.forEach((c) => {
      const companyType = c.companyType || "Unspecified";
      map[companyType] = (map[companyType] || 0) + 1;
    });
    return map;
  }, [companies, debouncedSearch]);

  const handleCompanyClick = useCallback((company: CompanySummary) => {
    setCompany(company.companyId, company.name, company.logoUrl);
    navigate("/company/dashboard");
  }, [navigate, setCompany]);

  const resetFilters = useCallback(() => {
    setSearch("");
    setDebouncedSearch("");
    setActiveCompanyType("All");
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="bg-navy text-primary-foreground py-8 md:py-10 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="font-heading text-xl md:text-3xl lg:text-4xl font-bold mb-2">
            SRM University Research &amp; Placement Analytics Portal
          </h1>
          <p className="font-body text-primary-foreground/60 text-xs md:text-sm mb-5">
            Your strategic edge for campus placements
          </p>
          <div className="max-w-lg mx-auto relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              inputMode="search"
              autoComplete="off"
              autoCorrect="off"
              autoCapitalize="off"
              spellCheck={false}
              placeholder="Search companies by name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="Search companies by name"
              className="w-full h-11 pl-11 pr-11 rounded-xl bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-dream text-sm"
            />
            {(search !== "" || activeCompanyType !== "All") && (
              <button
                type="button"
                onClick={resetFilters}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors rounded-full hover:bg-muted/50 active:scale-95"
                title="Reset filters"
                aria-label="Reset all filters"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div
          className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide"
          role="group"
          aria-label="Filter companies by type"
        >
          {filterPills.map((pill) => {
            const isActive = activeCompanyType === pill.label;
            const colorClass = isActive
              ? pill.activeClass
              : "border border-border bg-transparent text-foreground md:hover:border-foreground/30 md:hover:bg-secondary";
            return (
              <button
                key={pill.label}
                type="button"
                onPointerDown={(e) => {
                  // Prevent hover state focus stealing on touch devices
                  if (e.pointerType === "touch") e.preventDefault();
                  setActiveCompanyType(pill.label);
                }}
                onClick={() => setActiveCompanyType(pill.label)}
                aria-label={`Filter by ${pill.label}`}
                aria-pressed={isActive}
                className={`flex-shrink-0 select-none outline-none rounded-full border px-4 py-2 text-xs font-semibold transition-all duration-200 ${colorClass}`}
              >
                {pill.label}{" "}
                <span className="ml-1 opacity-70">{counts[pill.label] ?? 0}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid */}
      <div className="max-w-6xl mx-auto px-4 pb-12">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="bg-card rounded-xl shadow-sm border border-border/50 p-5 animate-pulse">
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-16 h-16 rounded-xl bg-muted" />
                  <div className="flex-1">
                    <div className="h-4 bg-muted rounded w-3/4 mb-2" />
                    <div className="h-3 bg-muted rounded w-1/2" />
                  </div>
                </div>
                <div className="h-3 bg-muted rounded w-1/3 mb-4" />
                <div className="h-8 bg-muted rounded" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {filtered.map((company, i) => (
              <CompanyCard
                key={company.companyId}
                company={company}
                index={i}
                onClick={handleCompanyClick}
              />
            ))}
          </div>
        )}
        {!loading && filtered.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">
            <p className="text-lg font-heading text-foreground">No companies found</p>
            <p className="text-sm mt-1 mb-4">Try adjusting your search or filters</p>
            <button
              onClick={resetFilters}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-dream hover:underline active:opacity-70"
              aria-label="Reset all filters and search"
            >
              <X className="w-4 h-4" />
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Index;
