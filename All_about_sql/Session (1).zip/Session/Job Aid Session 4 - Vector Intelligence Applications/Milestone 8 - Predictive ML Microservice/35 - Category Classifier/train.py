"""Train `artifacts/category_classifier.joblib` from Supabase data.

Run once (or whenever the embeddings / labels change):

    python train.py

Data contract
-------------
X : company_embeddings.embedding_gemini   (dim = GEMINI_OUTPUT_DIM, default 768)
y : companies.category                    (free-text, treated as multi-class)

Only rows with both a populated Gemini embedding for `field_name='overview_text'`
AND a non-empty category are used.

Model
-----
sklearn.pipeline.Pipeline([
    StandardScaler(with_mean=False),
    LogisticRegression(max_iter=1000),
])

Output
------
artifacts/category_classifier.joblib  (exposes .classes_ and .predict_proba)
"""
from __future__ import annotations

import os
import sys
from collections import Counter
from pathlib import Path

import numpy as np
import psycopg
from dotenv import load_dotenv
from joblib import dump
from pgvector.psycopg import register_vector
from rich.console import Console
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

load_dotenv()
_console = Console()

SUPABASE_DB_URL = os.environ["SUPABASE_DB_URL"]
GEMINI_OUTPUT_DIM = int(os.getenv("GEMINI_OUTPUT_DIM", "768"))
MODEL_PATH = Path(os.getenv("MODEL_PATH", "artifacts/category_classifier.joblib"))

QUERY = """
    SELECT e.embedding_gemini, c.category
    FROM   company_embeddings e
    JOIN   companies c ON c.company_id = e.company_id
    WHERE  e.field_name = 'overview_text'
      AND  e.embedding_gemini IS NOT NULL
      AND  c.category IS NOT NULL
      AND  length(trim(c.category)) > 0;
"""


def _load_rows() -> tuple[np.ndarray, np.ndarray]:
    _console.rule("[bold cyan]1. loading labelled rows from Supabase[/]")
    with psycopg.connect(SUPABASE_DB_URL) as conn:
        register_vector(conn)
        with conn.cursor() as cur:
            cur.execute(QUERY)
            rows = cur.fetchall()
    if not rows:
        _console.print("[red]✗ no labelled rows found. Backfill companies first and make sure companies.category is populated.[/]")
        sys.exit(1)

    X = np.asarray([r[0] for r in rows], dtype=np.float32)
    y = np.asarray([str(r[1]).strip() for r in rows])
    _console.print(f"[green]✓ {len(rows)} rows  X.shape={X.shape}  classes={len(set(y))}[/]")
    return X, y


def _drop_singleton_classes(X: np.ndarray, y: np.ndarray, min_count: int = 2) -> tuple[np.ndarray, np.ndarray]:
    counts = Counter(y)
    singletons = {cls for cls, n in counts.items() if n < min_count}
    if not singletons:
        return X, y
    names = ", ".join(repr(str(s)) for s in sorted(singletons))
    _console.print(f"[yellow]! dropping {len(singletons)} class(es) with <{min_count} samples: {names}[/]")
    mask = np.array([cls not in singletons for cls in y])
    return X[mask], y[mask]


def main() -> int:
    X, y = _load_rows()
    X, y = _drop_singleton_classes(X, y)

    classes = sorted(set(y))
    if len(classes) < 2:
        _console.print(f"[red]✗ need ≥2 classes with ≥2 samples each; got {classes}[/]")
        return 1

    _console.rule("[bold cyan]2. class distribution[/]")
    for cls, n in sorted(Counter(y).items(), key=lambda kv: -kv[1]):
        _console.print(f"  {cls!r:40} {n}")

    _console.rule("[bold cyan]3. train / test split[/]")
    try:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y,
        )
    except ValueError:
        _console.print("[yellow]! stratified split failed (tiny classes); falling back to non-stratified[/]")
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42,
        )
    _console.print(f"  train={len(X_train)}  test={len(X_test)}")

    _console.rule("[bold cyan]4. fitting LogisticRegression[/]")
    pipeline = Pipeline([
        ("scaler", StandardScaler(with_mean=False)),
        ("clf",    LogisticRegression(max_iter=1000)),
    ])
    pipeline.fit(X_train, y_train)
    _console.print("[green]✓ fit complete[/]")

    _console.rule("[bold cyan]5. evaluation[/]")
    train_acc = pipeline.score(X_train, y_train)
    test_acc = pipeline.score(X_test, y_test)
    _console.print(f"  train accuracy : {train_acc:.3f}")
    _console.print(f"  test  accuracy : {test_acc:.3f}")
    _console.print()
    _console.print(classification_report(y_test, pipeline.predict(X_test), zero_division=0))

    _console.rule("[bold cyan]6. saving artifact[/]")
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    dump(pipeline, MODEL_PATH)
    size_kb = MODEL_PATH.stat().st_size / 1024
    _console.print(f"[green]✓ wrote {MODEL_PATH} ({size_kb:.1f} KB)[/]")
    _console.print(f"  classes: {list(pipeline.classes_)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
