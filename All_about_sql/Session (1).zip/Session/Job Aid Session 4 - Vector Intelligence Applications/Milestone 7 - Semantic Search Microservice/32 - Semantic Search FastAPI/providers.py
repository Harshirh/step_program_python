"""Embedding + streaming-chat providers with automatic fallback.

Primary LLM  : openai/gpt-oss-120b:free                  (OpenRouter)
Fallback LLM : nvidia/nemotron-3-super-120b-a12b:free     (OpenRouter)

Every LLM chunk is printed to the terminal as it streams in, so students
can see the rerank running live rather than waiting for a silent HTTP call.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Iterator, Literal

from dotenv import load_dotenv

from rich.console import Console

load_dotenv()
_console = Console()

GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]
OPENROUTER_API_KEY = os.environ["OPENROUTER_API_KEY"]
GEMINI_OUTPUT_DIM = int(os.getenv("GEMINI_OUTPUT_DIM", "768"))

LLM_PRIMARY = os.getenv("LLM_PRIMARY", "openai/gpt-oss-120b:free")
LLM_FALLBACK = os.getenv("LLM_FALLBACK", "nvidia/nemotron-3-super-120b-a12b:free")

EMBED_PRIMARY = "gemini-embedding-2-preview"
EMBED_FALLBACK = "nvidia/llama-nemotron-embed-vl-1b-v2:free"


def _log(msg: str, style: str = "dim") -> None:
    _console.print(f"[{style}]{msg}[/]")


# ---------------------------------------------------------------- embeddings

@dataclass(frozen=True)
class EmbedResult:
    provider: Literal["gemini", "nvidia"]
    model: str
    vector: list[float]


_gemini_client = None
_openrouter_client = None


def _gemini():
    global _gemini_client
    if _gemini_client is None:
        from google import genai
        _gemini_client = genai.Client(api_key=GEMINI_API_KEY)
    return _gemini_client


def _openrouter():
    global _openrouter_client
    if _openrouter_client is None:
        from openai import OpenAI
        _openrouter_client = OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=OPENROUTER_API_KEY,
        )
    return _openrouter_client


def embed(text: str) -> EmbedResult:
    _log(f"  → Gemini: embedding {len(text)} chars (dim={GEMINI_OUTPUT_DIM})")
    try:
        resp = _gemini().models.embed_content(
            model=EMBED_PRIMARY,
            contents=[text],
            config={"output_dimensionality": GEMINI_OUTPUT_DIM},
        )
        vec = list(resp.embeddings[0].values)
        _log(f"  ✓ Gemini OK — dim={len(vec)}", "green")
        return EmbedResult(provider="gemini", model=EMBED_PRIMARY, vector=vec)
    except Exception as e:  # noqa: BLE001
        _log(f"  ! Gemini failed: {type(e).__name__}: {e}", "yellow")
        # encoding_format="float" forces float output; OpenAI-compat providers
        # ignore the SDK's default base64 request and the SDK then mis-parses
        # the response as ValueError: No embedding data received.
        resp = _openrouter().embeddings.create(
            model=EMBED_FALLBACK,
            input=text,
            encoding_format="float",
        )
        vec = list(resp.data[0].embedding)
        _log(f"  ✓ NVIDIA OK — dim={len(vec)}", "green")
        return EmbedResult(provider="nvidia", model=EMBED_FALLBACK, vector=vec)


# ----------------------------------------------------------- streaming chat

def chat_stream(messages: list[dict]) -> tuple[str, str]:
    """Streamed chat with model fallback.

    Prints each chunk to the terminal.  Returns (full_text, model_used).
    Raises RuntimeError only if BOTH models fail — caller decides what to do.
    """
    for model in (LLM_PRIMARY, LLM_FALLBACK):
        try:
            _console.print(f"[bold cyan]▶ LLM stream:[/] {model}")
            stream = _openrouter().chat.completions.create(
                model=model,
                messages=messages,
                stream=True,
            )
            parts: list[str] = []
            for chunk in _iter_chunks(stream):
                parts.append(chunk)
                _console.print(chunk, end="", soft_wrap=True)
            _console.print()  # newline after stream
            _console.print(f"[green]  ✓ {model} complete ({len(''.join(parts))} chars)[/]")
            return "".join(parts), model
        except Exception as e:  # noqa: BLE001
            _log(f"  ! {model} failed: {type(e).__name__}: {e}", "yellow")
            continue
    raise RuntimeError("All LLM providers failed")


def _iter_chunks(stream) -> Iterator[str]:
    for event in stream:
        delta = event.choices[0].delta
        piece = getattr(delta, "content", None)
        if piece:
            yield piece
