# 28 — Embedding Models and Provider Wiring  *(PPT — 10 min)*

## The two providers, side by side

|                | Gemini (primary)                      | OpenRouter (fallback)                               |
|----------------|---------------------------------------|-----------------------------------------------------|
| Model          | `gemini-embedding-2-preview`          | `nvidia/llama-nemotron-embed-vl-1b-v2:free`          |
| SDK            | `google-genai` (`from google import genai`) | `openai` (base_url = `https://openrouter.ai/api/v1`) |
| API key env    | `GEMINI_API_KEY`                      | `OPENROUTER_API_KEY`                                 |
| Output dim     | Matryoshka — we force **768**         | Fixed — **verify with `--probe-dims`**               |
| Cost           | Free tier, rate-limited               | Free tier, rate-limited                              |
| Used when      | Default for every row                 | Gemini errors, 429s, or times out                    |

## The fallback pattern

```python
def embed(text: str) -> EmbedResult:
    log.step(f"→ Gemini: embedding {len(text)} chars")
    try:
        vec = gemini_client.models.embed_content(
            model="gemini-embedding-2-preview",
            contents=[text],
            config={"output_dimensionality": 768},
        ).embeddings[0].values
        log.ok(f"  Gemini OK — dim={len(vec)}")
        return EmbedResult(provider="gemini", vector=vec)
    except Exception as e:
        log.warn(f"  Gemini failed: {type(e).__name__}: {e}")
        log.step(f"→ OpenRouter (NVIDIA): retrying")
        vec = openrouter_client.embeddings.create(
            model="nvidia/llama-nemotron-embed-vl-1b-v2:free",
            input=text,
        ).data[0].embedding
        log.ok(f"  NVIDIA OK — dim={len(vec)}")
        return EmbedResult(provider="nvidia", vector=vec)
```

## Why we print so much

The whole script can take minutes. If it sits silent, a student cannot tell whether:
- the HTTP call is stuck
- a retry is in progress
- the DB write is slow
- or their API key is wrong

Every provider call, every DB upsert, every batch boundary gets a `log.step(...)` line with a wall-clock timestamp. `log.ok`, `log.warn`, `log.err` colour-code the outcome via `rich`.

## Matryoshka — one sentence

`gemini-embedding-2-preview` is trained such that the **first 768 dims** of a 3072-dim output are themselves a valid, near-optimal 768-dim embedding. That lets us pick the dim at call time via `output_dimensionality=768`, trading quality for storage/speed.

## What `--probe-dims` does

Before backfilling anything, we fetch a single embedding from each provider, print the observed dimension, and exit. Students compare that to the `vector(N)` dims in `sql/001_create_embedding_tables.sql` and adjust **before** running the real backfill. Cheaper than discovering a dim mismatch halfway through 500 rows.
