import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";
import { compression } from "vite-plugin-compression2";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
    hmr: {
      overlay: false,
    },
  },
  plugins: [
    react(),
    mode === "development" && componentTagger(),
    // Gzip compression for servers that support Content-Encoding: gzip
    compression({ algorithms: ["gzip"] }),
    // Brotli compression — modern browsers prefer this (better ratio than gzip)
    compression({ algorithms: ["brotliCompress"] }),
  ].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  build: {
    // Faster reporting during CI/CD
    reportCompressedSize: false,
    // Split CSS per async chunk for better caching
    cssCodeSplit: true,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes("node_modules")) {
            if (id.includes("react") || id.includes("react-dom") || id.includes("react-router-dom")) {
              return "vendor";
            }
            if (
              id.includes("@radix-ui") ||
              id.includes("lucide-react")
            ) {
              return "ui";
            }
            if (id.includes("@supabase")) {
              return "supabase";
            }
            if (id.includes("framer-motion")) {
              return "motion";
            }
            if (id.includes("recharts")) {
              return "charts";
            }
            if (id.includes("@tanstack/react-query")) {
              return "query";
            }
          }
        },
      },
    },
  },
}));
