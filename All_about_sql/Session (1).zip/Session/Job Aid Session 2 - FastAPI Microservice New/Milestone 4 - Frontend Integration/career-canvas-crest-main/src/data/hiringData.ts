export interface HiringRoundSection {
  name: string;
  items: string[];
}

export interface HiringRound {
  round: number;
  name: string;
  tags: string[];
  assessmentMode?: string;
  roundCategory?: string;
  evaluationType?: string;
  elimination: string;
  sections: HiringRoundSection[];
}
