import { useState, useEffect } from "react";
import { ChevronDown, Lock, Info, TrendingUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { bloomInfo, criticalityInfo, type BloomLevel, type SkillArea, type Criticality } from "@/data/skillsData";
import { fetchSkillIntelligence } from "@/lib/serviceApi";
import { useCompany } from "@/context/CompanyContext";
import { CompanyLogo } from "@/components/ui/CompanyLogo";

const bloomColumns: { key: BloomLevel; desc: string }[] = [
  { key: "CU", desc: "Recall facts, define concepts. Basic recognition and identification of terms." },
  { key: "AP", desc: "Use knowledge in new situations. Execute procedures, implement solutions." },
  { key: "AS", desc: "Break into components, find relationships. Compare, contrast, deconstruct." },
  { key: "EV", desc: "Make judgments, justify decisions. Critique, defend, assess trade-offs." },
  { key: "CR", desc: "Design new solutions, construct, produce. Highest order thinking." },
];

const SkillIntelligence = () => {
  const [expanded, setExpanded] = useState<number | null>(null);
  const [skills, setSkills] = useState<SkillArea[]>([]);
  const [loading, setLoading] = useState(true);
  const { companyId, companyName, logoUrl } = useCompany();

  useEffect(() => {
    const fetchSkills = async () => {
      if (!companyId) { setLoading(false); return; }

      try {
        const data = await fetchSkillIntelligence(companyId);
        setSkills((data || []) as SkillArea[]);
      } catch (err) {
        console.error("Skill fetch error:", err);
        setSkills([]);
      }
      setLoading(false);
    };

    fetchSkills();
  }, [companyId]);

  // ── Loading ───────────────────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="space-y-5">
        <div className="h-14 bg-muted rounded-xl animate-pulse" />
        <div className="h-28 bg-muted rounded-xl animate-pulse" />
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-20 bg-muted rounded-xl animate-pulse" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-8 pt-4 md:pt-6 lg:pt-8">

      {/* ── Page header ──────────────────────────────────────────────────── */}
      <div>
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 md:w-14 md:h-14 rounded-xl bg-white border border-border/50 flex flex-shrink-0 items-center justify-center p-1.5 shadow-sm">
            <CompanyLogo
              name={companyName || "Company"}
              databaseLogoUrl={logoUrl}
              className="w-full h-full object-contain"
            />
          </div>
          <div className="mt-0.5">
             <div className="flex items-center gap-2 mb-1">
              <div className="w-6 h-6 rounded-md bg-[#eff6ff] flex items-center justify-center flex-shrink-0">
                <TrendingUp className="w-3.5 h-3.5 text-[#3b82f6]" aria-hidden="true" />
              </div>
              <h1 className="font-heading text-xl md:text-2xl font-bold text-foreground leading-tight">
                {companyName ? `${companyName} Skill Intelligence` : "Skill Intelligence Matrix"}
              </h1>
            </div>
            <p className="font-body text-sm text-muted-foreground">
              2D Skill Model — minimum depth level (1–10) × Bloom's cognitive level.
            </p>
          </div>
        </div>
      </div>

      {/* ── Bloom's Taxonomy — exactly 5 columns ─────────────────────────── */}
      <section className="bg-[#f8fafc] rounded-xl border border-border/50 p-5" aria-label="Bloom's Taxonomy levels">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-5 h-5 rounded-full bg-[#3b82f6] flex items-center justify-center" aria-hidden="true">
            <Info className="w-3 h-3 text-white" />
          </div>
          <h2 className="font-heading font-bold text-sm text-foreground">Bloom's Taxonomy Levels</h2>
        </div>
        {/* Exactly 5 columns on desktop */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {bloomColumns.map((col) => {
            const info = bloomInfo[col.key];
            return (
              <div key={col.key} className={`${info.tintBg} rounded-lg p-3`}>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className={`text-[10px] font-heading font-bold px-2 py-0.5 rounded-full ${info.bg} ${info.text}`}>
                    {info.shortLabel}
                  </span>
                  <span className="font-heading text-xs font-semibold text-foreground">{info.label}</span>
                </div>
                <p className="font-body text-xs text-muted-foreground leading-relaxed">{col.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* ── Criticality legend — 3 cards ─────────────────────────────────── */}
      <section className="bg-card rounded-xl shadow-sm border border-border/50 p-5" aria-label="Skill criticality levels">
        <h2 className="font-heading font-bold text-[15px] text-foreground mb-4">What Differentiates Selected vs Rejected</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {[
            { label: "CRITICAL",  bg: "bg-[#fff1f2]", text: "text-[#dc2626]", desc: "Must demonstrate mastery. Evaluated deeply. Weak here = immediate rejection." },
            { label: "IMPORTANT", bg: "bg-[#fffbeb]", text: "text-[#d97706]", desc: "Solid proficiency expected. Questions probe analysis ability. Gaps noticed." },
            { label: "BASELINE",  bg: "bg-[#f0fdf4]", text: "text-[#16a34a]", desc: "Foundational awareness sufficient. Applied-level understanding. Not elimination-worthy." },
          ].map((c) => (
            <div key={c.label} className={`${c.bg} rounded-lg p-3.5`}>
              <p className={`font-heading text-[11px] font-bold uppercase mb-1.5 ${c.text}`}>{c.label}</p>
              <p className="font-body text-[13px] text-foreground/80 leading-relaxed">{c.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Skill Cards ───────────────────────────────────────────────────── */}
      <div className="space-y-4">
        {skills.length === 0 && (
          <section className="bg-card rounded-xl shadow-sm border border-border/50 p-6 text-center">
            <p className="font-body text-sm text-muted-foreground">No skill intelligence data is available for this company.</p>
          </section>
        )}
        {skills.map((skill, i) => {
          const isOpen = expanded === i;
          const bloom = bloomInfo[skill.bloom];
          const crit = criticalityInfo[skill.criticality];

          // Progress bar colour: match the Bloom level color
          const barColor = bloom.bg;

          return (
            <div key={i} className="bg-card rounded-xl shadow-sm border border-border/50 overflow-hidden">
              <div className="p-5">
                {/* Skill name + bloom badge + score */}
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <h3 className="font-heading font-semibold text-[17px] text-foreground">{skill.name}</h3>
                    <span className={`font-heading text-[10px] font-bold px-2.5 py-0.5 rounded-full ${bloom.bg} ${bloom.text}`}>
                      {bloom.shortLabel}
                    </span>
                  </div>
                  <div className="flex items-baseline gap-0.5 flex-shrink-0">
                    <span className="font-heading text-xl font-bold text-foreground">{skill.score}</span>
                    <span className="font-body text-sm text-muted-foreground">/10</span>
                  </div>
                </div>

                {/* Cognitive description */}
                <p className="font-body text-[13px] text-muted-foreground mb-3 line-clamp-1">{skill.description}</p>

                {/* Progress bar — 6px height, width = score/10 */}
                <div className="w-full h-1.5 bg-[#f1f5f9] rounded-full overflow-hidden mb-2" role="progressbar" aria-valuenow={skill.score} aria-valuemin={0} aria-valuemax={10}>
                  <div className={`h-full rounded-full ${barColor}`} style={{ width: `${skill.score * 10}%` }} />
                </div>

                {/* Cognitive level + criticality label */}
                <div className="flex items-center justify-between font-body text-xs text-muted-foreground mb-3">
                  <span>
                    Cognitive Level:{" "}
                    <span className={`font-semibold ${bloom.textColor}`}>
                      {bloom.shortLabel}
                    </span>{" "}
                    ({bloom.label})
                  </span>
                  <span className={`font-heading font-semibold ${crit.text}`}>{skill.criticality}</span>
                </div>

                {/* Toggle button — "View Topic Roadmap ↓" */}
                <div className="border-t border-border/50 pt-3">
                  <button
                    onClick={() => setExpanded(isOpen ? null : i)}
                    aria-expanded={isOpen}
                    aria-label={isOpen ? `Collapse ${skill.name} roadmap` : `View ${skill.name} topic roadmap`}
                    className="w-full flex items-center justify-center gap-1.5 font-body text-xs text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {isOpen ? "Hide" : "View"} Topic Roadmap (Level 1–{skill.targetLevel}){" "}
                    <ChevronDown
                      className={`w-3.5 h-3.5 transition-transform duration-200 ${isOpen ? "rotate-180" : "rotate-0"}`}
                      aria-hidden="true"
                    />
                  </button>
                </div>
              </div>

              {/* ── Expandable roadmap — exactly 10 levels ────────────────── */}
              <AnimatePresence>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.22 }}
                    className="overflow-hidden"
                  >
                    <div className="px-5 pb-5 border-t border-border/50 pt-4">
                      <div className="flex items-center gap-2 mb-4">
                        <div className="w-2.5 h-2.5 rounded-full bg-[#ef4444] flex-shrink-0" aria-hidden="true" />
                        <p className="font-heading text-sm font-semibold text-foreground">
                          Master all topics from Level 1 – {skill.targetLevel}
                        </p>
                      </div>

                      <div className="space-y-2">
                        {skill.levels.map((lvl) => {
                          const isTarget = lvl.level === skill.targetLevel;
                          const isLocked = lvl.level > skill.targetLevel;

                          // Target level — uses Bloom level's specific colors
                          if (isTarget) {
                            return (
                              <div key={lvl.level} className={`flex items-start gap-3 p-3 rounded-lg ${bloom.tintBg} border-2 ${bloom.borderColor}`}>
                                <div className={`w-7 h-7 rounded-full ${bloom.bg} flex items-center justify-center font-heading text-xs font-bold text-white flex-shrink-0`}>
                                  {lvl.level}
                                </div>
                                <div className="min-w-0">
                                  <div className="flex items-center gap-2">
                                    <p className={`font-heading text-sm font-semibold ${bloom.textColor}`}>
                                      Level {lvl.level} — {lvl.name}
                                    </p>
                                    <span className={`font-heading text-[9px] font-bold ${bloom.bg} text-white px-1.5 py-0.5 rounded`}>
                                      REQUIRED
                                    </span>
                                  </div>
                                  <p className="font-body text-xs text-foreground/70 mt-0.5">{lvl.desc}</p>
                                </div>
                              </div>
                            );
                          }

                          // Locked levels — lock icon, 50% opacity, "Beyond scope"
                          if (isLocked) {
                            return (
                              <div key={lvl.level} className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30 opacity-50">
                                <div className="w-7 h-7 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                                  <Lock className="w-3 h-3 text-muted-foreground" aria-hidden="true" />
                                </div>
                                <div className="min-w-0">
                                  <div className="flex items-center gap-2">
                                    <p className="font-body text-sm text-muted-foreground">
                                      Level {lvl.level} — {lvl.name}
                                    </p>
                                    <span className="font-body text-[10px] italic text-muted-foreground">Beyond scope</span>
                                  </div>
                                  <p className="font-body text-xs text-muted-foreground">{lvl.desc}</p>
                                </div>
                              </div>
                            );
                          }

                          // Normal levels (1 to target-1) — gray circle, white bg, gray border
                          return (
                            <div key={lvl.level} className="flex items-start gap-3 p-3 rounded-lg bg-secondary/50 border border-border/30">
                              <div className="w-7 h-7 rounded-full border-2 border-muted-foreground/30 flex items-center justify-center font-heading text-xs font-medium text-muted-foreground flex-shrink-0">
                                {lvl.level}
                              </div>
                              <div className="min-w-0">
                                <p className="font-heading text-sm font-medium text-foreground">
                                  Level {lvl.level} — {lvl.name}
                                </p>
                                <p className="font-body text-xs text-muted-foreground mt-0.5">{lvl.desc}</p>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SkillIntelligence;
