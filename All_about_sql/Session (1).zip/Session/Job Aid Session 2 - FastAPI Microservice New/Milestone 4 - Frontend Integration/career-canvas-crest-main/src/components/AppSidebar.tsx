import { Home, Building2, Target, RefreshCw, Zap, ArrowLeft } from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { useLocation, useNavigate } from "react-router-dom";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";

const navItems = [
  { title: "Dashboard", url: "/company/dashboard", icon: Home },
  { title: "Company Intelligence", url: "/company/intelligence", icon: Building2 },
  { title: "Skill Intelligence", url: "/company/skills", icon: Target },
  { title: "Hiring Rounds", url: "/company/rounds", icon: RefreshCw },
  { title: "InnovX", url: "/company/InnovX", icon: Zap, badge: true },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const navigate = useNavigate();

  return (
    <Sidebar collapsible="icon" className="border-r-0">
      <SidebarContent className="bg-sidebar">
        {/* Logo */}
        <div className="px-4 py-5 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center flex-shrink-0 overflow-hidden p-0.5">
            <img
              src="/srm_logo.png"
              alt="SRM University Logo"
              className="w-full h-full object-contain"
            />
          </div>
          {!collapsed && (
            <div>
              <h2 className="text-sm font-heading font-bold text-sidebar-foreground">SRM Portal</h2>
              <p className="text-[10px] text-sidebar-foreground/50">Placement Intelligence</p>
            </div>
          )}
        </div>

        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink
                      to={item.url}
                      aria-label={item.title}
                      className="relative flex items-center gap-3 px-4 py-2.5 rounded-md text-sidebar-foreground/70 transition-all duration-200 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                      activeClassName="bg-sidebar-accent text-sidebar-foreground border-l-[3px] border-dream"
                    >
                      <item.icon className="w-4 h-4 flex-shrink-0" />
                      {!collapsed && (
                        <span className="text-sm font-medium">{item.title}</span>
                      )}
                      {item.badge && !collapsed && (
                        <span className="ml-auto text-[9px] font-bold uppercase px-1.5 py-0.5 rounded-full bg-super-dream text-white animate-glow">
                          NEW
                        </span>
                      )}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="bg-sidebar px-4 py-3">
        <button
          onClick={() => navigate("/")}
          aria-label="Back to all companies list"
          className="flex items-center gap-2 text-xs text-sidebar-foreground/40 hover:text-sidebar-foreground/70 transition-colors"
        >
          <ArrowLeft className="w-3 h-3" />
          {!collapsed && <span>All Companies</span>}
        </button>
      </SidebarFooter>
    </Sidebar>
  );
}
