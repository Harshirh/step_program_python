# Milestone 5 - Docker Deployment

This milestone contains the Docker-based deployment setup for the project.

Folder:

`Milestone 5 - Docker Deployment/docker-deployment`

## What This Setup Runs

- milestone 3 backend: FastAPI + SQLModel service
- milestone 4 frontend: React + Vite application

## Files in This Folder

- `docker-compose.yml`
- `backend.Dockerfile`
- `frontend.Dockerfile`
- `README.md`

## Prerequisites

- Docker Desktop installed and running
- Existing `.env` files configured for milestone 3 and milestone 4

## Update Environment Variables Before Running

### Backend `.env`

Update:

`Milestone-3/placement-analytics-service/.env`

Required key:

```env
DATABASE_URL=postgresql://postgres.<project-ref>:<your-password>@aws-1-ap-south-1.pooler.supabase.com:5432/postgres
```

### Frontend `.env`

Update:

`Milestone 4 - Frontend Integration/career-canvas-crest-main/.env`

Recommended keys:

```env
VITE_SUPABASE_URL=https://<your-project-ref>.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=<your-supabase-publishable-key>
VITE_DATABASE_URL=postgresql://postgres.<project-ref>:<your-password>@aws-1-ap-south-1.pooler.supabase.com:5432/postgres
```

Note:

- `docker-compose.yml` already sets `VITE_COMPANY_API_URL=http://localhost:8001`
- `docker-compose.yml` already sets `VITE_INNOVX_API_URL=http://localhost:8001`

## Run with Docker Compose

Open PowerShell in the Docker deployment folder:

```powershell
cd "C:\Users\DELL\Downloads\SRM\Job Aid Session 2 - FastAPI Microservice\Milestone 5 - Docker Deployment\docker-deployment"
docker compose up --build
```

## Access the Applications

After the containers start:

- FastAPI backend: `http://localhost:8001`
- Swagger docs: `http://localhost:8001/docs`
- Frontend UI: `http://localhost:8090`

## Verify the Deployment

1. Run `docker compose up --build`.
2. Open `http://localhost:8001/docs`.
3. Execute `GET /health`.
4. Execute company, hiring rounds, and skill intelligence APIs.
5. Open `http://localhost:8090`.
6. Navigate through the frontend pages.
7. Open browser DevTools and confirm API calls are hitting `localhost:8001`.

## Stop the Containers

```powershell
docker compose down
```

## Rebuild After Changes

If dependencies or Dockerfiles change:

```powershell
docker compose up --build
```

## Notes for Students

- The backend container uses FastAPI and SQLModel.
- The frontend container uses the Vite development server.
- The backend container is mapped to host port `8001` to avoid conflicts with a locally running milestone 3 backend on `8000`.
- The frontend container is mapped to host port `8090` to avoid conflicts with Jenkins or other services using `8080`.
- If port `8090` is already in use on your machine, update the port mapping in `docker-compose.yml`.
- If port `8001` is already in use, update the port mapping in `docker-compose.yml`.
