# Career Canvas Frontend

This is the milestone 4 frontend application built with React, TypeScript, and Vite.

## Key Files

- `.env`
- `package.json`
- `src/lib/serviceApi.ts`
- `src/pages/*`

## Install and Run

```powershell
cd "C:\Users\DELL\Downloads\SRM\Job Aid Session 2 - FastAPI Microservice\Milestone 4 - Frontend Integration\career-canvas-crest-main"
npm install
npm run dev
```

## Backend Requirement

Backend must already be running on:

`http://localhost:8000`

Swagger:

`http://localhost:8000/docs`

## How to Get Supabase Frontend Credentials

Official docs:

- Supabase API keys: https://supabase.com/docs/guides/api/api-keys
- Supabase API URL and keys overview: https://supabase.com/docs/guides/api/creating-routes

Detailed steps:

1. Log in to Supabase.
2. Open the project.
3. Click `Connect`.
4. Copy the `Project URL`.
5. Copy the `Publishable key`.
6. If required, open `Project Settings -> API Keys` and confirm the same values.

## How to Get the Database URL

Official docs:

- Connection strings: https://supabase.com/docs/reference/postgres/connection-strings

Steps:

1. Open the project in Supabase.
2. Click `Connect`.
3. Copy the PostgreSQL connection string.
4. For most student Windows environments, use the `Session pooler` URI.
5. Replace `[YOUR-PASSWORD]` with the real password.

## Update `.env`

```env
VITE_COMPANY_API_URL=http://localhost:8000
VITE_INNOVX_API_URL=http://localhost:8000
VITE_PLACEMENT_API_URL=http://localhost:8002
VITE_SUPABASE_URL=https://<project-ref>.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_xxxxxxxxx
VITE_DATABASE_URL=postgresql://postgres.<project-ref>:<your-password>@aws-1-ap-south-1.pooler.supabase.com:5432/postgres
```

## API Usage by Page

- Home page -> `GET /api/v1/companies`
- Dashboard -> `GET /api/v1/companies/{id}/full-json`, `GET /api/v1/hiring-rounds/{id}`, `GET /api/v1/skill-intelligence/{id}`
- Company Intelligence -> `GET /api/v1/company-details/{id}`
- Skill Intelligence -> `GET /api/v1/skill-intelligence/{id}`
- Hiring Pipeline -> `GET /api/v1/hiring-rounds/{id}`
- InnovX -> `GET /api/v1/innovx/{id}`

## Performance Note

The frontend is intentionally split so:

- home page fetches `short_json` only
- dashboard fetches `full_json` only

This avoids loading unnecessary data for the wrong page.
