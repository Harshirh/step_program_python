"""Predictive ML microservice — FastAPI on :8004.

Milestone 8 ships this file with two endpoints:
  - POST /predict/category   (item 35)
  - POST /placement/fit      (item 36, defined here too to keep one process)
"""
from __future__ import annotations

import os
from pathlib import Path

import numpy as np
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from rich.console import Console

load_dotenv()
_console = Console()
GEMINI_OUTPUT_DIM = int(os.getenv("GEMINI_OUTPUT_DIM", "768"))
MODEL_PATH = Path(os.getenv("MODEL_PATH", "artifacts/category_classifier.joblib"))

# Embedding providers reused from the same pattern as Milestone 7.
# (Copied locally — this microservice is standalone.)
from providers import embed, EMBED_PRIMARY, EMBED_FALLBACK  # type: ignore

app = FastAPI(title="Predictive ML", version="0.1.0")


# -------------------------------------------------------------- model loading

MODEL = None
MODEL_ERROR: str | None = None


@app.on_event("startup")
def _load_model() -> None:
    global MODEL, MODEL_ERROR
    if not MODEL_PATH.exists():
        MODEL_ERROR = f"{MODEL_PATH} not found"
        _console.print(f"[yellow]! {MODEL_ERROR}[/]")
        _console.print("[yellow]! /predict/category will return 503 until provided[/]")
        return
    try:
        from joblib import load
        MODEL = load(MODEL_PATH)
        _console.print(f"[green]✓ model loaded from {MODEL_PATH}[/]")
        _console.print(f"  · classes: {list(MODEL.classes_)}")
    except Exception as e:  # noqa: BLE001
        MODEL_ERROR = f"{type(e).__name__}: {e}"
        _console.print(f"[red]✗ failed to load model: {MODEL_ERROR}[/]")


# ----------------------------------------------------------------- endpoints

class PredictRequest(BaseModel):
    company_overview: str = Field(..., min_length=10)


class ProbItem(BaseModel):
    category: str
    probability: float


class PredictResponse(BaseModel):
    predicted_category: str
    probability: float
    top_k: list[ProbItem]
    embedding_provider: str
    model_file: str


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok" if MODEL is not None else "model_missing",
        "model_path": str(MODEL_PATH),
        "model_error": MODEL_ERROR,
        "embed_primary": EMBED_PRIMARY,
        "embed_fallback": EMBED_FALLBACK,
    }


@app.post("/predict/category", response_model=PredictResponse)
def predict_category(body: PredictRequest) -> PredictResponse:
    if MODEL is None:
        raise HTTPException(status_code=503, detail=MODEL_ERROR or "model not loaded")

    _console.rule(f"[bold]POST /predict/category[/]  text_len={len(body.company_overview)}")
    result = embed(body.company_overview)
    vec = np.asarray(result.vector, dtype=np.float32).reshape(1, -1)

    if vec.shape[1] != GEMINI_OUTPUT_DIM:
        raise HTTPException(
            status_code=500,
            detail=f"embedding dim mismatch: got {vec.shape[1]}, expected {GEMINI_OUTPUT_DIM}",
        )

    probs = MODEL.predict_proba(vec)[0]
    order = np.argsort(probs)[::-1]
    top_k = [ProbItem(category=str(MODEL.classes_[i]), probability=float(probs[i])) for i in order[:5]]
    pred = top_k[0]
    _console.print(f"  ✓ predicted={pred.category} (p={pred.probability:.2f})")
    return PredictResponse(
        predicted_category=pred.category,
        probability=pred.probability,
        top_k=top_k,
        embedding_provider=result.provider,
        model_file=str(MODEL_PATH),
    )


# ============================================================================
# Item 36 — /placement/fit  (same FastAPI app; code kept here to reuse the
#                            embedding client and avoid a second process)
# ============================================================================

class PlacementRequest(BaseModel):
    candidate_profile: str = Field(..., min_length=10)
    top_n: int = 3


class PlacementCompany(BaseModel):
    company_id: int
    company_name: str
    fit_percent: float


class PlacementResponse(BaseModel):
    candidate_embedding_provider: str
    overall_best: PlacementCompany
    top_n: list[PlacementCompany]


@app.post("/placement/fit", response_model=PlacementResponse)
def placement_fit(body: PlacementRequest) -> PlacementResponse:
    import psycopg
    from pgvector.psycopg import HalfVector, register_vector

    _console.rule("[bold]POST /placement/fit[/]")
    result = embed(body.candidate_profile)
    col = "embedding_gemini" if result.provider == "gemini" else "embedding_nvidia"
    bound = list(result.vector) if result.provider == "gemini" else HalfVector(result.vector)

    dsn = os.environ["SUPABASE_DB_URL"]
    sql = f"""
        SELECT c.company_id, c.name,
               100 * (1 - (e.{col} <=> %s::vector)) AS fit_percent
        FROM   company_embeddings e
        JOIN   companies c ON c.company_id = e.company_id
        WHERE  e.field_name = 'overview_text'
          AND  e.{col} IS NOT NULL
        ORDER  BY e.{col} <=> %s::vector
        LIMIT  %s;
    """
    with psycopg.connect(dsn) as conn:
        register_vector(conn)
        with conn.cursor() as cur:
            cur.execute(sql, (bound, bound, body.top_n))
            rows = cur.fetchall()

    if not rows:
        raise HTTPException(status_code=404, detail="no company embeddings available")

    top = [
        PlacementCompany(company_id=r[0], company_name=r[1], fit_percent=float(r[2]))
        for r in rows
    ]
    _console.print(f"  ✓ best fit: {top[0].company_name} ({top[0].fit_percent:.1f}%)")
    return PlacementResponse(
        candidate_embedding_provider=result.provider,
        overall_best=top[0],
        top_n=top,
    )
