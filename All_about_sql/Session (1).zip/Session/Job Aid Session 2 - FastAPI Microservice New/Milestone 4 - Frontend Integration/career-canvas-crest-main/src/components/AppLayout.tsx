import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { Outlet, useLocation, Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import { useCompany } from "@/context/CompanyContext";

const breadcrumbMap: Record<string, string> = {
  "/company/dashboard": "Dashboard",
  "/company/intelligence": "Company Intelligence",
  "/company/skills": "Skill Intelligence",
  "/company/rounds": "Hiring Rounds",
  "/company/InnovX": "InnovX",
};

export function AppLayout() {
  const location = useLocation();
  const currentLabel = breadcrumbMap[location.pathname];
  const { companyId, companyName } = useCompany();

  return (
    <SidebarProvider>
      <div className="flex h-screen w-full overflow-hidden">
        <AppSidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-12 flex items-center border-b bg-card px-4 gap-3 flex-shrink-0">
            <SidebarTrigger className="md:hidden h-9 w-9 [&_svg]:size-5" aria-label="Toggle navigation menu" />
            {currentLabel && (
              <nav className="flex items-center gap-1.5 text-sm text-muted-foreground" aria-label="Breadcrumb">
                <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
                <ChevronRight className="w-3 h-3" aria-hidden="true" />
                
                {companyId && (
                  <div className="flex items-center gap-1.5 hidden sm:flex">
                    <span
                      title={companyName}
                      className="text-foreground/80 font-medium truncate max-w-[140px] cursor-default"
                    >
                      {companyName}
                    </span>
                    <ChevronRight className="w-3 h-3" aria-hidden="true" />
                  </div>
                )}
                
                <span className="text-foreground font-medium" aria-current="page">{currentLabel}</span>
              </nav>
            )}
          </header>
          <main className="flex-1 overflow-auto bg-background px-4 pb-4 md:px-6 md:pb-6 lg:px-8 lg:pb-8 scroll-pt-[60px] pb-safe">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
