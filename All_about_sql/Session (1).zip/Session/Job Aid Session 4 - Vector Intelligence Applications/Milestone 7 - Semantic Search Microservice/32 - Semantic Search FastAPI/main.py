"""Semantic Search microservice — FastAPI on :8003."""
from __future__ import annotations

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from rich.console import Console

import providers
import retriever

_console = Console()
app = FastAPI(title="Semantic Search", version="0.1.0")


# ------------------------------------------------------------------- schemas

class SearchRequest(BaseModel):
    query: str = Field(..., min_length=1)
    k: int = 5
    rerank: bool = True


class SearchHit(BaseModel):
    id: int
    payload: dict
    similarity: float
    provider_used: str


class SearchResponse(BaseModel):
    hits: list[SearchHit]
    rerank_text: str | None = None
    rerank_model: str | None = None
    rerank_skipped: bool = False
    rerank_reason: str | None = None


# ------------------------------------------------------------------- helpers

RERANK_SYSTEM = (
    "You are helping a user find companies that best match a free-text query. "
    "You will be given the user query and a ranked list of candidate companies. "
    "Return a short paragraph (max 4 sentences) naming the best 1–2 matches "
    "and explaining why, based on the candidates' overview text."
)


def _rerank_prompt(query: str, hits: list[retriever.Hit]) -> list[dict]:
    lines = [f"User query: {query}", "", "Candidates:"]
    for i, h in enumerate(hits, 1):
        name = h.payload.get("name", f"company {h.id}")
        overview = (h.payload.get("overview_text") or "")[:500]
        lines.append(f"{i}. {name} (sim={h.similarity:.2f}) — {overview}")
    return [
        {"role": "system", "content": RERANK_SYSTEM},
        {"role": "user", "content": "\n".join(lines)},
    ]


# ------------------------------------------------------------------- routes

@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "embed_primary": providers.EMBED_PRIMARY,
        "embed_fallback": providers.EMBED_FALLBACK,
        "llm_primary": providers.LLM_PRIMARY,
        "llm_fallback": providers.LLM_FALLBACK,
    }


@app.post("/search/companies", response_model=SearchResponse)
def search_companies(body: SearchRequest) -> SearchResponse:
    _console.rule(f"[bold]POST /search/companies[/]  query={body.query!r}")
    q = providers.embed(body.query)
    hits = retriever.search_companies(q, k=body.k)
    _console.print(f"  · {len(hits)} hits (best sim={hits[0].similarity:.2f})" if hits else "  · 0 hits")
    resp = SearchResponse(hits=[SearchHit(**h.__dict__) for h in hits])
    if body.rerank and hits:
        try:
            text, model = providers.chat_stream(_rerank_prompt(body.query, hits))
            resp.rerank_text = text
            resp.rerank_model = model
        except Exception as e:  # noqa: BLE001
            resp.rerank_skipped = True
            resp.rerank_reason = f"{type(e).__name__}: {e}"
            _console.print(f"[yellow]  ! rerank skipped: {resp.rerank_reason}[/]")
    return resp


@app.post("/search/projects", response_model=SearchResponse)
def search_projects(body: SearchRequest) -> SearchResponse:
    _console.rule(f"[bold]POST /search/projects[/]  query={body.query!r}")
    q = providers.embed(body.query)
    hits = retriever.search_projects(q, k=body.k)
    return SearchResponse(hits=[SearchHit(**h.__dict__) for h in hits])


@app.get("/similar/{company_id}", response_model=SearchResponse)
def similar(company_id: int, k: int = 5, rerank: bool = True) -> SearchResponse:
    _console.rule(f"[bold]GET /similar/{company_id}[/]  k={k}")
    hits = retriever.similar_to_company(company_id, k=k)
    if not hits:
        raise HTTPException(status_code=404, detail=f"no embedding for company_id={company_id}")
    resp = SearchResponse(hits=[SearchHit(**h.__dict__) for h in hits])
    if rerank:
        try:
            query = f"companies similar to company_id={company_id}"
            text, model = providers.chat_stream(_rerank_prompt(query, hits))
            resp.rerank_text = text
            resp.rerank_model = model
        except Exception as e:  # noqa: BLE001
            resp.rerank_skipped = True
            resp.rerank_reason = f"{type(e).__name__}: {e}"
    return resp
