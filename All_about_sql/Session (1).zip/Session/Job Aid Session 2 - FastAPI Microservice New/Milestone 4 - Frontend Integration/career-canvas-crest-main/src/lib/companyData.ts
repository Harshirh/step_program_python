import type { HiringRound, HiringRoundSection } from "@/data/hiringData";
import type { Company } from "@/lib/serviceApi";

type JsonRecord = Record<string, unknown>;

export interface CompanySummary {
  companyId: number;
  name: string;
  shortName: string;
  category: string;
  companyType: string;
  logoUrl: string;
  employeeSize: string;
  incorporationYear: string;
  yoyGrowthRate: string;
  officeLocations: string;
  headquartersLocation: string;
  operatingCountries: string;
  websiteUrl?: string;
}

export interface CompanyProfile {
  companyId: number;
  shortJson: JsonRecord;
  fullJson: JsonRecord;
  merged: Record<string, string>;
}

export interface DashboardSkill {
  name: string;
  difficulty: "BEGINNER" | "PRO" | "ADVANCED" | "EXPERT";
  score: number;
  cogSize: number;
  concepts: number;
}

export interface InnovXTrendCard {
  title: string;
  description: string;
  drivers: string[];
  impactAreas: string[];
  period: string;
  importance: string;
  timeHorizonYears?: number;
}

export interface InnovXProjectCard {
  title: string;
  description: string;
  outcome: string;
  problemStatement: string;
  targetCustomer: string;
  timeHorizon: string;
  innovationType: string;
  capabilities: string[];
  dependentTrends: string[];
  tierLevel?: string;
}

export interface InnovXCompetitorCard {
  competitorName: string;
  competitorType: string;
  betName: string;
  betDescription: string;
  coreStrength: string;
  marketPositioning: string;
  innovationCategory: string;
  strategicObjective: string;
  threatLevel: string;
  futuristicLevel: string;
}

export interface InnovXPillar {
  pillarName: string;
  focusArea: string;
  description: string;
  ctoVision?: string;
  risks?: string;
  technologies: string[];
}

export interface InnovXMaster {
  industry: string;
  companyName: string;
  subIndustry: string;
  targetMarket: string;
  geographicFocus: string;
  coreBusinessModel: string;
}

export interface InnovXViewModel {
  master: InnovXMaster | null;
  trends: InnovXTrendCard[];
  roadmap: InnovXProjectCard[];
  projects: InnovXProjectCard[];
  competitors: InnovXCompetitorCard[];
  pillars: InnovXPillar[];
}

interface HiringSkillSet {
  skill_set_code?: string;
  typical_questions?: string;
}

interface HiringRoundJson {
  round_number?: number;
  round_name?: string;
  round_category?: string;
  assessment_mode?: string;
  evaluation_type?: string;
  skill_sets?: HiringSkillSet[];
}

export interface JobRoleDetail {
  role_title?: string;
  role_category?: string;
  opportunity_type?: string;
  compensation?: string;
  ctc_or_stipend?: number | string;
  bonus?: string;
  job_description?: string;
  benefits_summary?: string;
  hiring_rounds?: HiringRoundJson[];
}

export interface RoleHiringPipeline {
  role: JobRoleDetail;
  rounds: HiringRound[];
}

interface HiringDataJson {
  company_name?: string;
  job_role_details?: JobRoleDetail[];
}

interface InnovxTrend {
  trend_name?: string;
  trend_description?: string;
  trend_drivers?: string[];
  impact_areas?: string[];
  time_horizon_years?: number;
  strategic_importance?: string;
}

interface InnovxRoadmapItem {
  time_horizon?: string;
  innovation_type?: string;
  innovation_theme?: string;
  problem_statement?: string;
  target_customer?: string;
  expected_outcome?: string;
  dependent_trend_names?: string[];
  required_capabilities?: string[];
}

interface InnovxCompetitor {
  competitor_name?: string;
  competitor_type?: string;
  market_positioning?: string;
  core_strength?: string;
  bet_name?: string;
  bet_description?: string;
  innovation_category?: string;
  strategic_objective?: string;
  threat_level?: string;
  futuristic_level?: string;
}

interface InnovxMasterJson {
  industry?: string;
  company_name?: string;
  sub_industry?: string;
  target_market?: string;
  geographic_focus?: string;
  core_business_model?: string;
}

interface InnovxPillarJson {
  pillar_name?: string;
  focus_area?: string;
  pillar_description?: string;
  cto_vision_statement?: string;
  strategic_risks?: string;
  key_technologies?: string[];
}

interface InnovxProject {
  project_name?: string;
  problem_statement?: string;
  business_value?: string;
  target_users?: string;
  innovation_objective?: string;
  tier_level?: string;
  primary_use_case?: string;
  secondary_use_cases?: string[];
  ai_ml_technologies?: string[];
  architecture_style?: string;
  backend_technologies?: string[];
  frontend_technologies?: string[];
  infrastructure_cloud?: string;
  data_storage_processing?: string;
  integrations_apis?: string[];
  security_compliance?: string;
  success_metrics?: string[];
  aligned_pillar_names?: string[];
  differentiation_factor?: string;
  time_horizon?: string;
}

interface InnovxDataJson {
  innovx_master?: InnovxMasterJson;
  industry_trends?: InnovxTrend[];
  innovation_roadmap?: InnovxRoadmapItem[];
  innovx_projects?: InnovxProject[];
  competitive_landscape?: InnovxCompetitor[];
  strategic_pillars?: InnovxPillarJson[];
}

const asRecord = (value: unknown): JsonRecord =>
  value && typeof value === "object" && !Array.isArray(value) ? (value as JsonRecord) : {};

const asString = (value: unknown): string => {
  if (value === null || value === undefined) return "";
  if (typeof value === "string") return value.trim();
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  return "";
};

const splitItems = (value: string): string[] =>
  value
    .split(/\r?\n|[.;•]/)
    .map((item) => item.trim())
    .filter(Boolean);

const titleCaseFromCode = (value: string): string =>
  value
    .replace(/[_-]+/g, " ")
    .toLowerCase()
    .replace(/\b\w/g, (char) => char.toUpperCase());

const normalizeCompanyType = (category: string): string => {
  if (!category) return "Regular";
  const cat = category.toLowerCase();
  if (cat.includes("super") || cat.includes("oracle") || cat.includes("google") || cat.includes("microsoft") || cat.includes("amazon")) 
    return "Super Dream";
  if (cat.includes("dream") || cat.includes("flipkart") || cat.includes("adobe") || cat.includes("salesforce"))
    return "Dream";
  if (cat.includes("standard") || cat.includes("wipro") || cat.includes("tcs") || cat.includes("hcl") || cat.includes("cognizant"))
    return "Standard";
  return "Regular";
};

const scoreToDifficulty = (score: number): DashboardSkill["difficulty"] => {
  if (score >= 8) return "EXPERT";
  if (score >= 6) return "ADVANCED";
  if (score >= 4) return "PRO";
  return "BEGINNER";
};

export function normalizeCompanySummary(row: any): CompanySummary {
  // Handle Company type from companies table (10 actual companies)
  if ('company_id' in row && !row.short_json) {
    const company = row as Company;
    return {
      companyId: company.company_id,
      name: company.name || "Unknown",
      shortName: company.short_name || "",
      category: company.category || "Regular",
      companyType: normalizeCompanyType(company.category || ""),
      logoUrl: "",
      employeeSize: company.employee_size || "",
      incorporationYear: company.incorporation_year || "",
      yoyGrowthRate: "",
      officeLocations: company.office_count || "",
      headquartersLocation: company.headquarters_address || "",
      operatingCountries: "",
      websiteUrl: company.website_url || "",
    };
  }

  // Handle CompanyJsonRow type with nested JSON (legacy, for backward compatibility)
  const shortJson = asRecord(row.short_json);
  const fullJson = asRecord(row.full_json);

  return {
    companyId: row.company_id,
    name: asString(shortJson.name) || "Unknown",
    shortName: asString(shortJson.short_name),
    category: asString(shortJson.category) || "Regular",
    companyType: asString(shortJson.company_type) || normalizeCompanyType(asString(shortJson.category) || ""),
    logoUrl: asString(shortJson.logo_url),
    employeeSize: asString(shortJson.employee_size),
    incorporationYear: asString(fullJson.incorporation_year) || asString(shortJson.incorporation_year),
    yoyGrowthRate: asString(shortJson.yoy_growth_rate),
    officeLocations: asString(shortJson.office_locations),
    headquartersLocation: asString(fullJson.headquarters_address) || asString(shortJson.headquarters_address),
    operatingCountries: asString(shortJson.operating_countries),
    websiteUrl: asString(shortJson.website_url) || asString(fullJson.website_url),
  };
}

export function normalizeCompanyProfile(row: {
  company_id: number;
  short_json?: unknown;
  full_json?: unknown;
} | Company): CompanyProfile {
  // Handle new Company interface
  if ('name' in row) {
    const company = row as Company;
    const merged: Record<string, string> = {};

    // Map company fields to merged object
    merged['name'] = asString(company.name);
    merged['short_name'] = asString(company.short_name);
    merged['category'] = asString(company.category);
    merged['incorporation_year'] = asString(company.incorporation_year);
    merged['nature_of_company'] = asString(company.nature_of_company);
    merged['headquarters_address'] = asString(company.headquarters_address);
    merged['office_count'] = asString(company.office_count);
    merged['employee_size'] = asString(company.employee_size);
    merged['website_url'] = asString(company.website_url);
    merged['linkedin_url'] = asString(company.linkedin_url);
    merged['twitter_handle'] = asString(company.twitter_handle);
    merged['facebook_url'] = asString(company.facebook_url);
    merged['instagram_url'] = asString(company.instagram_url);
    merged['primary_contact_email'] = asString(company.primary_contact_email);
    merged['primary_phone_number'] = asString(company.primary_phone_number);
    merged['overview_text'] = asString(company.overview_text);
    merged['vision_statement'] = asString(company.vision_statement);
    merged['mission_statement'] = asString(company.mission_statement);
    merged['legal_issues'] = asString(company.legal_issues);
    merged['carbon_footprint'] = asString(company.carbon_footprint);

    return {
      companyId: company.company_id,
      shortJson: {},
      fullJson: merged,
      merged,
    };
  }

  // Handle old format with short_json and full_json
  const shortJson = asRecord(row.short_json);
  const fullJson = asRecord(row.full_json);
  const mergedKeys = new Set([...Object.keys(shortJson), ...Object.keys(fullJson)]);
  const merged: Record<string, string> = {};

  if (!shortJson.name && fullJson.name) {
    shortJson.name = fullJson.name;
  }

  for (const key of mergedKeys) {
    merged[key] = asString(fullJson[key]) || asString(shortJson[key]);
  }

  return {
    companyId: row.company_id,
    shortJson,
    fullJson,
    merged,
  };
}

export function normalizeDashboardSkills(
  skillLevels: Array<{
    required_level: number;
    skill_set_master?: { skill_set_name?: string | null } | Array<{ skill_set_name?: string | null }> | null;
  }>
): DashboardSkill[] {
  return skillLevels
    .map((skillLevel) => {
      const score = Number(skillLevel.required_level) || 0;
      const skillSetMaster = Array.isArray(skillLevel.skill_set_master)
        ? skillLevel.skill_set_master[0]
        : skillLevel.skill_set_master;

      return {
        name: skillSetMaster?.skill_set_name?.trim() || "Unnamed Skill",
        difficulty: scoreToDifficulty(score),
        score,
        cogSize: Math.max(1, Math.min(5, Math.ceil(score / 2))),
        concepts: Math.max(3, score + 4),
      };
    })
    .sort((left, right) => right.score - left.score)
    .slice(0, 5);
}

export function normalizeHiringData(raw: unknown): RoleHiringPipeline[] {
  const hiringData = asRecord(raw) as HiringDataJson;
  const roles = Array.isArray(hiringData.job_role_details) ? hiringData.job_role_details : [];

  return roles.map((role) => {
    const hiringRounds = Array.isArray(role.hiring_rounds) ? role.hiring_rounds : [];
    
    const rounds = hiringRounds.map((round, index) => {
      const sections: HiringRoundSection[] = [];

      const skillSections = (round.skill_sets || [])
        .map((skillSet) => {
          const items = splitItems(asString(skillSet.typical_questions));
          if (!items.length) return null;

          return {
            name: titleCaseFromCode(asString(skillSet.skill_set_code) || "General"),
            items,
          };
        })
        .filter(Boolean) as HiringRoundSection[];

      sections.push(...skillSections);

      if (!sections.length && role.job_description) {
        sections.push({
          name: "Round Focus",
          items: splitItems(asString(role.job_description)),
        });
      }

      const tagSet = new Set(
        [
          asString(round.assessment_mode),
          asString(round.round_category),
          asString(round.evaluation_type),
        ].filter(Boolean)
      );

      const defaultEliminations = ["~60% eliminated", "~50% eliminated", "~40% eliminated", "~30% eliminated", "~20% eliminated"];

      return {
        round: Number(round.round_number) || index + 1,
        name: asString(round.round_name) || `Round ${index + 1}`,
        tags: Array.from(tagSet),
        assessmentMode: asString(round.assessment_mode) || undefined,
        roundCategory: asString(round.round_category) || undefined,
        evaluationType: asString(round.evaluation_type) || undefined,
        elimination: asString((round as any).elimination_rate) || defaultEliminations[index] || "~10% eliminated",
        sections,
      };
    }).sort((left, right) => left.round - right.round);

    return { role, rounds };
  });
}

export function normalizeInnovXData(raw: unknown): InnovXViewModel {
  const innovxData = asRecord(raw) as InnovxDataJson;

  // ── Master context ──
  const m = innovxData.innovx_master || {};
  const master: InnovXMaster | null = Object.values(m).some((v) => v) ? {
    industry: asString(m.industry),
    companyName: asString(m.company_name),
    subIndustry: asString(m.sub_industry),
    targetMarket: asString(m.target_market),
    geographicFocus: asString(m.geographic_focus),
    coreBusinessModel: asString(m.core_business_model),
  } : null;

  // ── Industry trends ──
  const trends: InnovXTrendCard[] = (innovxData.industry_trends || []).map((trend) => ({
    title: asString(trend.trend_name) || "Industry Trend",
    description: asString(trend.trend_description),
    drivers: Array.isArray(trend.trend_drivers) ? trend.trend_drivers.filter(Boolean) as string[] : [],
    impactAreas: Array.isArray(trend.impact_areas) ? trend.impact_areas.filter(Boolean) as string[] : [],
    period: trend.time_horizon_years ? `${trend.time_horizon_years}-year horizon` : "",
    importance: asString(trend.strategic_importance),
    timeHorizonYears: trend.time_horizon_years,
  }));

  // ── Innovation themes (Roadmap) ──
  const roadmap: InnovXProjectCard[] = (innovxData.innovation_roadmap || []).map((item) => ({
    title: asString(item.innovation_theme) || "Innovation Theme",
    description: asString(item.problem_statement),
    outcome: asString(item.expected_outcome),
    problemStatement: asString(item.problem_statement),
    targetCustomer: asString(item.target_customer),
    timeHorizon: asString(item.time_horizon),
    innovationType: asString(item.innovation_type),
    capabilities: Array.isArray(item.required_capabilities) ? item.required_capabilities.filter(Boolean) as string[] : [],
    dependentTrends: Array.isArray(item.dependent_trend_names) ? item.dependent_trend_names.filter(Boolean) as string[] : [],
  }));

  // ── Innovation projects ──
  const projects: InnovXProjectCard[] = (innovxData.innovx_projects || []).map((p) => ({
    title: asString(p.project_name) || "Innovation Project",
    description: asString(p.innovation_objective) || asString(p.problem_statement),
    outcome: asString(p.business_value),
    problemStatement: asString(p.problem_statement),
    targetCustomer: asString(p.target_users),
    timeHorizon: asString(p.time_horizon) || asString(p.tier_level),
    innovationType: "Project",
    capabilities: [
      ...(Array.isArray(p.ai_ml_technologies) ? p.ai_ml_technologies : []),
      ...(Array.isArray(p.backend_technologies) ? p.backend_technologies : []),
      ...(Array.isArray(p.frontend_technologies) ? p.frontend_technologies : [])
    ].filter(Boolean),
    dependentTrends: Array.isArray(p.aligned_pillar_names) ? p.aligned_pillar_names : [],
    tierLevel: asString(p.tier_level),
  }));

  // ── Competitive landscape ──
  const competitors: InnovXCompetitorCard[] = (innovxData.competitive_landscape || []).map((c) => ({
    competitorName: asString(c.competitor_name),
    competitorType: asString(c.competitor_type),
    betName: asString(c.bet_name),
    betDescription: asString(c.bet_description),
    coreStrength: asString(c.core_strength),
    marketPositioning: asString(c.market_positioning),
    innovationCategory: asString(c.innovation_category),
    strategicObjective: asString(c.strategic_objective),
    threatLevel: asString(c.threat_level),
    futuristicLevel: asString(c.futuristic_level),
  }));

  // ── Strategic Pillars ──
  const pillars: InnovXPillar[] = (innovxData.strategic_pillars || []).map((p) => ({
    pillarName: asString(p.pillar_name),
    focusArea: asString(p.focus_area),
    description: asString(p.pillar_description),
    ctoVision: asString(p.cto_vision_statement),
    risks: asString(p.strategic_risks),
    technologies: Array.isArray(p.key_technologies) ? p.key_technologies : [],
  }));

  return { master, trends, roadmap, projects, competitors, pillars };
}
