import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Building2, Target, RefreshCw, Zap, ExternalLink, ChevronDown, ChevronUp } from "lucide-react";
import { motion } from "framer-motion";
import { fetchCompanyFullJson, fetchHiringRounds, fetchSkillIntelligence } from "@/lib/serviceApi";
import { useCompany } from "@/context/CompanyContext";
import { normalizeCompanyProfile, normalizeHiringData } from "@/lib/companyData";
import { CompanyLogo } from "@/components/ui/CompanyLogo";

const difficultyBadge: Record<string, string> = {
  EXPERT: "bg-[#dc2626] text-white",
  ADVANCED: "bg-[#ea580c] text-white",
  PRO: "bg-[#2563eb] text-white",
  BEGINNER: "bg-[#16a34a] text-white",
};

const difficultyBar: Record<string, string> = {
  EXPERT: "bg-[#dc2626]",
  ADVANCED: "bg-[#ea580c]",
  PRO: "bg-[#2563eb]",
  BEGINNER: "bg-[#16a34a]",
};

const quickNav = [
  { icon: Building2, title: "Company Intelligence", sub: "Profile details", link: "/company/intelligence", color: "text-dream" },
  { icon: Target, title: "Skill Intelligence", sub: "Skills matrix", link: "/company/skills", color: "text-super-dream" },
  { icon: RefreshCw, title: "Hiring Rounds", sub: "Interview flow", link: "/company/rounds", color: "text-standard" },
  { icon: Zap, title: "InnovX", sub: "Trends & projects", link: "/company/InnovX", color: "text-regular", badge: true },
];

const skillPillColors = [
  "bg-[#eff6ff] text-[#1d4ed8] border border-[#bfdbfe]",
  "bg-[#f5f3ff] text-[#7c3aed] border border-[#ddd6fe]",
  "bg-[#ecfeff] text-[#0f766e] border border-[#a5f3fc]",
  "bg-[#fff7ed] text-[#c2410c] border border-[#fed7aa]",
  "bg-[#f0fdf4] text-[#15803d] border border-[#bbf7d0]",
  "bg-[#fef2f2] text-[#b91c1c] border border-[#fecaca]",
];

const scoreToDifficulty = (score: number): "BEGINNER" | "PRO" | "ADVANCED" | "EXPERT" => {
  if (score >= 8) return "EXPERT";
  if (score >= 6) return "ADVANCED";
  if (score >= 4) return "PRO";
  return "BEGINNER";
};

const cleanText = (value?: string) => {
  const normalized = (value || "").trim();
  if (!normalized) return "";
  const lowered = normalized.toLowerCase();
  if (["n/a", "na", "null", "undefined", "-", "--", "none"].includes(lowered)) return "";
  return normalized;
};

const joinPreview = (...parts: Array<string | undefined>) =>
  parts.map(cleanText).filter(Boolean).join(" - ");

const emptyDash = {
  name: "",
  tagline: "",
  roles: [] as Array<{ title: string; description: string; skills: string[]; links: string[]; rounds: number }>,
  rounds: 0,
  highlights: [] as Array<{ title: string; preview: string }>,
  skills: [] as Array<{ name: string; difficulty: "BEGINNER" | "PRO" | "ADVANCED" | "EXPERT"; score: number }>,
  logoUrl: "",
  websiteUrl: "",
};

const CompanyDashboard = () => {
  const { companyId, companyName, logoUrl: contextLogoUrl } = useCompany();
  const [dash, setDash] = useState(emptyDash);
  const [loading, setLoading] = useState(true);
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false);
  const [isRolesExpanded, setIsRolesExpanded] = useState(false);

  useEffect(() => {
    const fetchDashboard = async () => {
      if (!companyId) {
        setDash(emptyDash);
        setLoading(false);
        return;
      }

      try {
        const [companyResult, hiringResult, skillsResult] = await Promise.allSettled([
          fetchCompanyFullJson(companyId),
          fetchHiringRounds(companyId, companyName),
          fetchSkillIntelligence(companyId),
        ]);

        const companyRes = companyResult.status === "fulfilled" ? companyResult.value : null;
        const hiringRes = hiringResult.status === "fulfilled" ? hiringResult.value : null;
        const skillsRes = skillsResult.status === "fulfilled" ? skillsResult.value : [];

        if (!companyRes) {
          setDash(emptyDash);
          setLoading(false);
          return;
        }

        const profile = normalizeCompanyProfile(companyRes);
        const co = profile.merged;
        const pipelines = hiringRes ? normalizeHiringData(hiringRes) : [];
        const companySkills = (skillsRes || []).map((skill) => skill.name).slice(0, 6);
        const allRoles = pipelines.map((p) => ({
          title: p.role?.role_title || "",
          description: p.role?.job_description || "",
          skills: companySkills,
          links: [cleanText(co.website_url)].filter(Boolean) as string[],
          rounds: p.rounds.length,
        }));
        const primaryRole = pipelines[0] || { role: {}, rounds: [] };
        const skills = (skillsRes || [])
          .map((skill) => ({
            name: skill.name,
            difficulty: scoreToDifficulty(skill.score),
            score: skill.score,
          }))
          .sort((left, right) => right.score - left.score)
          .slice(0, 5);

        const highlights = [
          { title: "Company Identity", preview: joinPreview(cleanText(co.incorporation_year) && `Founded ${cleanText(co.incorporation_year)}`, co.headquarters_address) },
          { title: "Overview & Vision", preview: cleanText(co.vision_statement) || cleanText(co.mission_statement) || cleanText(co.overview_text) },
          { title: "Leadership", preview: joinPreview(cleanText(co.ceo_name) && `CEO: ${cleanText(co.ceo_name)}`, co.employee_size) },
          { title: "Funding & Financials", preview: joinPreview(cleanText(co.annual_revenue) && `Revenue: ${cleanText(co.annual_revenue)}`, cleanText(co.yoy_growth_rate) && `Growth: ${cleanText(co.yoy_growth_rate)}`) },
          { title: "Global Presence", preview: joinPreview(co.operating_countries, cleanText(co.office_count) && `${cleanText(co.office_count)} offices`) },
          { title: "Products & Services", preview: cleanText(co.offerings_description) },
        ].filter((item) => item.preview);

        setDash({
          name: co.name || companyName || "",
          tagline: cleanText(co.overview_text),
          roles: allRoles,
          logoUrl: contextLogoUrl || co.logo_url || co.logo || "",
          websiteUrl: cleanText(co.website_url),
          rounds: primaryRole.rounds.length,
          highlights,
          skills,
        });
      } catch (error) {
        console.error("Dashboard fetch error:", error);
        setDash(emptyDash);
      }

      setLoading(false);
    };

    fetchDashboard();
  }, [companyId, companyName, contextLogoUrl]);

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="rounded-xl bg-muted animate-pulse h-40" />
        <div className="bg-card rounded-xl border border-border/50 p-6 animate-pulse h-36" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-card rounded-xl border border-border/50 p-4 animate-pulse h-24" />
          ))}
        </div>
      </div>
    );
  }

  const d = dash;
  const displayedRoles = d.roles.length > 0 ? (isRolesExpanded ? d.roles : d.roles.slice(0, 1)) : [];
  const hasMultipleRoles = d.roles.length > 1;

  return (
    <div className="space-y-6 pb-8 pt-4 md:pt-6 lg:pt-8">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-xl p-6 md:p-8 text-white relative overflow-hidden"
        style={{ background: "linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%)" }}
        role="banner"
      >
        <div className="relative z-10">
          <span className="inline-block text-[10px] uppercase tracking-widest text-white/50 bg-white/10 px-3 py-1 rounded-full mb-4 font-heading font-semibold">
            SRM UNIVERSITY | INTELLIGENCE PLATFORM
          </span>
          <div className="flex items-center gap-4 mb-2">
            <div className="w-16 h-16 rounded-xl bg-white border border-border/50 flex items-center justify-center overflow-hidden flex-shrink-0 shadow-lg">
              <CompanyLogo
                name={d.name || companyName || "Company"}
                websiteUrl={d.websiteUrl}
                databaseLogoUrl={contextLogoUrl || d.logoUrl}
                className="w-full h-full object-contain p-2"
              />
            </div>
            <h1 className="font-heading text-2xl md:text-3xl lg:text-4xl font-bold text-white leading-tight">
              {d.name || companyName}
            </h1>
          </div>
          {d.tagline && (
            <div className="mt-3">
              <p className={`text-white/80 text-sm md:text-base max-w-3xl font-body leading-relaxed transition-all duration-300 ${!isDescriptionExpanded ? "line-clamp-2" : ""}`}>
                {d.tagline}
              </p>
              {d.tagline.length > 150 && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsDescriptionExpanded(!isDescriptionExpanded);
                  }}
                  className="text-white/60 hover:text-white text-xs font-medium mt-2 flex items-center gap-1 transition-colors"
                  aria-expanded={isDescriptionExpanded}
                >
                  {isDescriptionExpanded ? (
                    <>
                      View less <ChevronUp className="w-4 h-4" />
                    </>
                  ) : (
                    <>
                      View more <ChevronDown className="w-4 h-4" />
                    </>
                  )}
                </button>
              )}
            </div>
          )}
        </div>
        {d.rounds > 0 && (
          <div className="absolute top-6 right-6 bg-white/10 backdrop-blur-sm rounded-lg px-4 py-2 text-center hidden md:block">
            <p className="text-2xl font-heading font-bold text-white">{d.rounds}</p>
            <p className="text-[10px] uppercase tracking-wide text-white/60 font-heading">Rounds</p>
          </div>
        )}
        <div className="absolute -right-20 -bottom-20 w-60 h-60 bg-dream/10 rounded-full blur-3xl pointer-events-none" />
      </motion.div>

      <section className="bg-card rounded-xl shadow-sm border border-border/50 p-5 md:p-6" aria-labelledby="role-details-heading">
        <h2 id="role-details-heading" className="font-heading font-semibold text-base mb-4 text-foreground">
          Role Details
          {d.roles.length > 0 && (
            <span className="ml-2 text-sm font-normal text-muted-foreground">({d.roles.length} {d.roles.length === 1 ? "role" : "roles"})</span>
          )}
        </h2>
        {displayedRoles.length > 0 ? (
          <div className="space-y-6">
            {displayedRoles.map((role, index) => (
              <div key={index} className={index > 0 ? "pt-4 border-t border-border/50" : ""}>
                {role.title && <h3 className="font-heading font-bold text-lg mb-2 text-foreground">{role.title}</h3>}
                {role.description && <p className="font-body text-sm text-muted-foreground mb-4 leading-relaxed max-w-3xl">{role.description}</p>}
                {role.skills.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-4" aria-label="Required skills">
                    {role.skills.map((skill, i) => (
                      <span key={skill} className={`px-2.5 py-1 rounded-full text-xs font-medium ${skillPillColors[i % skillPillColors.length]}`}>
                        {skill}
                      </span>
                    ))}
                  </div>
                )}
                {role.links.length > 0 && (
                  <div className="flex gap-4 flex-wrap">
                    {role.links.map((link) => (
                      <a
                        key={link}
                        href={link.startsWith("http") ? link : `https://${link}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label={`Open ${link} in new tab`}
                        className="font-body text-xs text-dream hover:underline inline-flex items-center gap-1"
                      >
                        {link}
                        <ExternalLink className="w-3 h-3" aria-hidden="true" />
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p className="font-body text-sm text-muted-foreground">No role data available.</p>
        )}
        {hasMultipleRoles && (
          <button
            onClick={() => setIsRolesExpanded(!isRolesExpanded)}
            className="text-dream hover:underline text-sm font-medium mt-4 flex items-center gap-1 transition-colors"
            aria-expanded={isRolesExpanded}
          >
            {isRolesExpanded ? (
              <>
                View less <ChevronUp className="w-4 h-4" />
              </>
            ) : (
              <>
                View more ({d.roles.length - 1} more) <ChevronDown className="w-4 h-4" />
              </>
            )}
          </button>
        )}
      </section>

      <section aria-label="Quick navigation">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {quickNav.map((item) => (
            <Link
              key={item.title}
              to={item.link}
              aria-label={`Navigate to ${item.title}`}
              className="bg-card rounded-xl shadow-sm border border-border/50 p-4 hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 group flex flex-col"
            >
              <div className="flex items-start justify-between mb-3">
                <item.icon className={`w-5 h-5 ${item.color}`} aria-hidden="true" />
                {"badge" in item && item.badge && (
                  <span className="font-body text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-[#7c3aed] text-white animate-glow">
                    NEW
                  </span>
                )}
              </div>
              <h4 className="font-heading font-semibold text-sm mb-1 text-foreground">{item.title}</h4>
              <p className="font-body text-xs text-muted-foreground mb-3">{item.sub}</p>
              <span className="font-body text-xs text-dream font-medium group-hover:underline mt-auto">Explore {"->"}</span>
            </Link>
          ))}
        </div>
      </section>

      <section aria-label="Company highlights">
        <h2 className="font-heading font-semibold text-base mb-4 text-foreground">Company Highlights</h2>
        {d.highlights.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {d.highlights.map((highlight, i) => (
              <Link
                key={i}
                to="/company/intelligence"
                aria-label={`Explore ${highlight.title}`}
                className="bg-card rounded-xl shadow-sm border border-border/50 p-4 block hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 group"
              >
                <h4 className="font-heading font-semibold text-sm mb-1 text-foreground">{highlight.title}</h4>
                <p className="font-body text-xs text-muted-foreground mb-2 line-clamp-2">{highlight.preview}</p>
                <span className="font-body text-xs text-dream group-hover:underline">Explore {"->"}</span>
              </Link>
            ))}
          </div>
        ) : (
          <div className="bg-card rounded-xl shadow-sm border border-border/50 p-5 text-center">
            <p className="font-body text-sm text-muted-foreground">No company highlights available.</p>
          </div>
        )}
      </section>

      <section aria-label="Skill expectations">
        <h2 className="font-heading font-semibold text-base mb-4 text-foreground">Skill Expectations</h2>
        <div className="bg-card rounded-xl shadow-sm border border-border/50 p-5">
          <div className="space-y-5">
            {d.skills.map((skill, i) => (
              <div key={i}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-heading font-semibold text-sm text-foreground">{skill.name}</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${difficultyBadge[skill.difficulty]}`}>
                      {skill.difficulty}
                    </span>
                  </div>
                  <span className="font-body text-sm text-muted-foreground font-medium" aria-label={`Score ${skill.score} out of 10`}>
                    {skill.score}/10
                  </span>
                </div>
                <div className="w-full h-1.5 bg-secondary rounded-full overflow-hidden" role="progressbar" aria-valuenow={skill.score} aria-valuemin={0} aria-valuemax={10}>
                  <div className={`h-full rounded-full transition-all duration-500 ${difficultyBar[skill.difficulty]}`} style={{ width: `${skill.score * 10}%` }} />
                </div>
              </div>
            ))}
            {d.skills.length === 0 && (
              <p className="font-body text-sm text-muted-foreground text-center py-4">No skill data available.</p>
            )}
          </div>
          <Link to="/company/skills" className="inline-block mt-5 font-body text-sm text-dream hover:underline font-medium">
            View full skill matrix {"->"}
          </Link>
        </div>
      </section>
    </div>
  );
};

export default CompanyDashboard;
