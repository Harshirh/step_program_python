# 30 — What is Semantic Search  *(PPT — 5 min)*

## Keyword search vs semantic search

| | Keyword (SQL `LIKE`, `tsvector`) | Semantic (vector) |
|-|----------------------------------|-------------------|
| Matches on | Surface tokens | Meaning |
| "AI consultancy" finds | rows containing that exact phrase | *"machine-learning services firm"*, *"data-science partner"*, etc. |
| Needs | An inverted index | An embedding + ANN index |
| Breaks on | Synonyms, paraphrases | Proper nouns, IDs, SKUs |

Both are valid — **hybrid search** combines them. For the classroom we do pure semantic.

## The retrieval pipeline

```
user query string
      │
      ▼
embed(query)  ─► 768-D vector   (Gemini primary, NVIDIA fallback)
      │
      ▼
pgvector ANN  ─► top-k rows     (ORDER BY embedding <=> query_vec LIMIT 5)
      │
      ▼
(optional) LLM re-rank          (streamed to terminal)
      │
      ▼
JSON response
```

Step 1 is a single HTTP call. Step 2 is one SQL query. Step 3 is optional — turn it off with `rerank=false` when you want raw vector results to see why the ordering looks the way it does.

## Why re-rank at all

Top-k cosine neighbours are **semantically near**, not necessarily **intent-matching**. A 120B LLM reading the top-5 rows + the original query can spot the best fit and justify it in natural language. Cost: one extra call, streamed. Benefit: much better demo + human-readable reasoning.

If the LLM provider is down, the service falls back to the secondary model automatically; if both are down, it drops the rerank step and returns the raw top-k with a warning. The pipeline never blocks on the rerank.
