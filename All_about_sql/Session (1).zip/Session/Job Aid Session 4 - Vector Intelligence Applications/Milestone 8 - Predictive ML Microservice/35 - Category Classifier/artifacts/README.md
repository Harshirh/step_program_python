# artifacts/

Drop `category_classifier.joblib` into this folder.

This file is a `sklearn.pipeline.Pipeline` trained offline on
`company_embeddings.embedding_gemini` (dim=768) with `companies.category` as the
label. The instructor provides the file; students are not expected to train it
in class.

If the file is missing, the microservice starts anyway and `/predict/category`
returns `503 Service Unavailable` with a clear message. `/placement/fit` is
unaffected.
