import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AppLayout } from "./components/AppLayout";
import { CompanyProvider } from "./context/CompanyContext";

const Index = lazy(() => import("./pages/Index"));
const NotFound = lazy(() => import("./pages/NotFound"));
const CompanyDashboard = lazy(() => import("./pages/CompanyDashboard"));
const CompanyIntelligence = lazy(() => import("./pages/CompanyIntelligence"));
const SkillIntelligence = lazy(() => import("./pages/SkillIntelligence"));
const HiringPipeline = lazy(() => import("./pages/HiringPipeline"));
const InnovX = lazy(() => import("./pages/InnovX"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Data is considered fresh for 5 minutes — avoids refetching on navigation
      staleTime: 5 * 60 * 1000,
      // Keep data in cache for 10 minutes after last subscriber unmounts
      gcTime: 10 * 60 * 1000,
      // Single retry on failure (good for slow mobile networks)
      retry: 1,
      // Don't refetch when window regains focus (reduces API pressure on mobile)
      refetchOnWindowFocus: false,
    },
  },
});

// Full-screen skeleton that visually matches the home page shell
const PageSkeleton = () => (
  <div className="min-h-screen bg-background animate-pulse">
    <div className="h-32 bg-primary/10" />
    <div className="max-w-6xl mx-auto px-4 py-6">
      <div className="flex gap-2 mb-6">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-8 w-20 rounded-full bg-muted" />
        ))}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="bg-card rounded-xl border border-border/50 p-5 h-48" />
        ))}
      </div>
    </div>
  </div>
);

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <CompanyProvider>
          <BrowserRouter>
            <Suspense fallback={<PageSkeleton />}>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/company" element={<AppLayout />}>
                  <Route index element={<Navigate to="dashboard" replace />} />
                  <Route path="dashboard" element={<CompanyDashboard />} />
                  <Route path="intelligence" element={<CompanyIntelligence />} />
                  <Route path="skills" element={<SkillIntelligence />} />
                  <Route path="rounds" element={<HiringPipeline />} />
                  <Route path="InnovX" element={<InnovX />} />
                </Route>
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
          </BrowserRouter>
        </CompanyProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
