# 27 — What is a Vector Database  *(PPT — 10 min)*

> **Vector database** = a database that can index and search high-dimensional float arrays by **distance**, not by equality.

## The 3 ideas that matter

1. **Embedding.** A model turns a chunk of text into a fixed-length array of floats (e.g. 768 numbers). Semantically similar texts produce arrays that are close in that 768-D space.
2. **Distance.** "Close" is measured by **cosine distance** (1 − cosine similarity). Values near 0 = near-identical meaning; near 1 = unrelated.
3. **ANN index.** Scanning every row is O(n·d). An **Approximate Nearest Neighbour** index (HNSW, IVFFlat) returns top-k in roughly O(log n) with ~99% recall.

## Why pgvector specifically

Our Supabase project already has Postgres. `pgvector` is a Postgres extension — adds a `vector` column type and HNSW/IVFFlat index operators. That means:

- **No new service to run.** No Pinecone account, no Weaviate container.
- **Joins work.** `company_embeddings` can `JOIN companies` in one SQL query. A separate vector DB would force a two-hop round trip.
- **One connection string.** The same `SUPABASE_DB_URL` that Session 2 microservices use.

## What a pgvector column looks like

```sql
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE company_embeddings (
  company_id          int REFERENCES companies(company_id),
  field_name          text,
  embedding_gemini    vector(768),       -- Gemini, float32, HNSW ≤2000 dims
  embedding_nvidia    halfvec(2048),     -- NVIDIA, float16, HNSW ≤4000 dims
  model_used          text,
  created_at          timestamptz DEFAULT now()
);

CREATE INDEX ON company_embeddings USING hnsw (embedding_gemini vector_cosine_ops);
CREATE INDEX ON company_embeddings USING hnsw (embedding_nvidia halfvec_cosine_ops);
```

Two parallel columns because the two providers emit different dimensions — pgvector requires a fixed dim per column.

### Why `halfvec` on the NVIDIA side

pgvector's HNSW index on the regular `vector` type caps at **2000 dimensions**. NVIDIA's 2048-dim output overflows that ceiling. The `halfvec` type (float16) has an HNSW ceiling of **4000 dimensions** — which fits 2048 comfortably, halves storage, and costs effectively nothing in cosine-search quality.

## The top-k query we will run tomorrow

```sql
SELECT company_id, 1 - (embedding_gemini <=> $1) AS similarity
FROM   company_embeddings
WHERE  field_name = 'overview_text'
ORDER  BY embedding_gemini <=> $1
LIMIT  5;
```

`<=>` is pgvector's cosine-distance operator. Today we only **write** these rows; Session 4's `/search/companies` does the `ORDER BY`.

## HNSW vs IVFFlat — which do we pick

**HNSW.** Slightly slower to build, much faster to query, no "train" step. For our row counts (<10k) build time is a non-issue. IVFFlat makes sense past ~1M rows.
