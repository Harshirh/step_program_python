"""Row loaders — pull source text out of existing Supabase tables.

Table mapping (Session 2 New schema):

    companies                 -> companies backfill  (one row per (company, field))
    innovx_json.json_data     -> innovx backfill     (one row per project inside the JSON)
    skill_set_master +        -> skills backfill     (one row per skill_set)
      company_skill_levels
"""
from __future__ import annotations

import json
from typing import Any, Iterator

import psycopg

import log

# Which text fields from `companies` we embed.  Keep the list small for the
# classroom; add more once students see the search working end-to-end.
COMPANY_FIELDS = [
    "overview_text",
    "vision_statement",
    "mission_statement",
]


def load_companies(conn: psycopg.Connection, *, limit: int | None = None) -> Iterator[dict]:
    cols = ", ".join(COMPANY_FIELDS)
    sql = f"SELECT company_id, name, {cols} FROM public.companies ORDER BY company_id"
    if limit is not None:
        sql += f" LIMIT {int(limit)}"
    with conn.cursor() as cur:
        cur.execute(sql)
        rows = cur.fetchall()
    log.step(f"loaded {len(rows)} companies")
    for row in rows:
        company_id, name, *values = row
        for field_name, text in zip(COMPANY_FIELDS, values):
            if text and text.strip():
                yield {
                    "company_id": company_id,
                    "company_name": name,
                    "field_name": field_name,
                    "text": text.strip(),
                }


# -----------------------------------------------------------------------------
# InnovX  -- the JSON lives in innovx_json.json_data.  Shape varies a bit, so
# we look for a projects list in a few common places before falling back to
# the whole document as a single blob.
# -----------------------------------------------------------------------------

PROJECT_LIST_PATHS: tuple[tuple[str, ...], ...] = (
    ("projects",),
    ("innovx_master", "projects"),
    ("innovx_master", "initiatives"),
    ("innovx_master", "themes"),
)


def _get_path(d: Any, path: tuple[str, ...]) -> Any:
    cur: Any = d
    for key in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(key)
    return cur


def _innovx_project_text(project: Any) -> str:
    """Flatten one project-like object into an embedding-ready string."""
    if not isinstance(project, dict):
        return str(project).strip()
    parts: list[str] = []
    for key in (
        "name", "title", "project_name",
        "description", "summary", "problem_statement",
        "outcome", "impact",
        "technologies", "tech_stack", "tools",
    ):
        value = project.get(key)
        if isinstance(value, list):
            value = ", ".join(str(v) for v in value)
        if value:
            parts.append(f"{key}: {value}")
    return "\n".join(parts).strip()


def load_innovx(conn: psycopg.Connection, *, limit: int | None = None) -> Iterator[dict]:
    sql = "SELECT id, company_id, json_data FROM public.innovx_json ORDER BY id"
    if limit is not None:
        sql += f" LIMIT {int(limit)}"
    with conn.cursor() as cur:
        cur.execute(sql)
        rows = cur.fetchall()
    log.step(f"loaded {len(rows)} innovx_json rows")

    for innovx_id, company_id, json_data in rows:
        payload = json_data if isinstance(json_data, dict) else {}

        projects: list[Any] | None = None
        for path in PROJECT_LIST_PATHS:
            candidate = _get_path(payload, path)
            if isinstance(candidate, list) and candidate:
                projects = candidate
                log.detail(f"innovx_id={innovx_id}: found {len(projects)} items at path {'.'.join(path)}")
                break

        if projects is None:
            # No recognised project list — embed the whole JSON once so the
            # company still gets some representation.
            blob = json.dumps(payload, ensure_ascii=False)
            log.detail(f"innovx_id={innovx_id}: no project list found, embedding whole document ({len(blob)} chars)")
            yield {
                "innovx_id": innovx_id,
                "company_id": company_id,
                "project_idx": 0,
                "text": blob[:8000],
            }
            continue

        for idx, project in enumerate(projects):
            text = _innovx_project_text(project)
            if text:
                yield {
                    "innovx_id": innovx_id,
                    "company_id": company_id,
                    "project_idx": idx,
                    "text": text,
                }


# -----------------------------------------------------------------------------
# Skills  -- one embedding per skill_set (name + description).  The row keys
# off skill_set_id from skill_set_master.  company_skill_levels is where that
# skill is consumed; not needed for the embedding itself.
# -----------------------------------------------------------------------------

def load_skills(conn: psycopg.Connection, *, limit: int | None = None) -> Iterator[dict]:
    sql = """
        SELECT skill_set_id,
               skill_set_name,
               skill_set_description
        FROM   public.skill_set_master
        ORDER  BY skill_set_id
    """
    if limit is not None:
        sql += f" LIMIT {int(limit)}"
    with conn.cursor() as cur:
        cur.execute(sql)
        rows = cur.fetchall()
    log.step(f"loaded {len(rows)} skill_set_master rows")
    for skill_set_id, name, description in rows:
        parts: list[str] = []
        if name:
            parts.append(str(name).strip())
        if description:
            parts.append(str(description).strip())
        text = " — ".join(parts)
        if not text:
            continue
        yield {"skill_set_id": skill_set_id, "text": text}
