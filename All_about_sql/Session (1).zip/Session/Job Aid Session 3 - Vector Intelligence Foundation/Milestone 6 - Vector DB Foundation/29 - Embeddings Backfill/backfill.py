"""Backfill embeddings from Supabase rows into pgvector tables.

Entrypoint used by students:

    python backfill.py --probe-dims
    python backfill.py --table companies --limit 10 --dry-run
    python backfill.py --table companies
    python backfill.py --table innovx
    python backfill.py --table skills
    python backfill.py --table all
"""
from __future__ import annotations

import argparse
import hashlib
import sys

import log
import providers
from db import (
    connect,
    upsert_company_embedding,
    upsert_innovx_embedding,
    upsert_skill_embedding,
)
from sources import load_companies, load_innovx, load_skills


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _run_companies(*, limit: int | None, dry_run: bool) -> None:
    with connect() as conn:
        items = list(load_companies(conn, limit=limit))
        total = len(items)
        for i, item in enumerate(items, 1):
            log.step(
                f"row {i}/{total}  company_id={item['company_id']}  "
                f"field={item['field_name']}  ({len(item['text'])} chars)"
            )
            result = providers.embed(item["text"])
            if dry_run:
                log.warn("dry-run — skipping DB write")
                continue
            upsert_company_embedding(
                conn,
                company_id=item["company_id"],
                field_name=item["field_name"],
                source_text_hash=_hash(item["text"]),
                result=result,
            )


def _run_innovx(*, limit: int | None, dry_run: bool) -> None:
    with connect() as conn:
        items = list(load_innovx(conn, limit=limit))
        total = len(items)
        for i, item in enumerate(items, 1):
            log.step(
                f"row {i}/{total}  innovx_id={item['innovx_id']}  "
                f"project_idx={item['project_idx']}  ({len(item['text'])} chars)"
            )
            result = providers.embed(item["text"])
            if dry_run:
                log.warn("dry-run — skipping DB write")
                continue
            upsert_innovx_embedding(
                conn,
                innovx_id=item["innovx_id"],
                company_id=item.get("company_id"),
                project_idx=item["project_idx"],
                source_text_hash=_hash(item["text"]),
                result=result,
            )


def _run_skills(*, limit: int | None, dry_run: bool) -> None:
    with connect() as conn:
        items = list(load_skills(conn, limit=limit))
        total = len(items)
        for i, item in enumerate(items, 1):
            log.step(
                f"row {i}/{total}  skill_set_id={item['skill_set_id']}  "
                f"({len(item['text'])} chars)"
            )
            result = providers.embed(item["text"])
            if dry_run:
                log.warn("dry-run — skipping DB write")
                continue
            upsert_skill_embedding(
                conn,
                skill_set_id=item["skill_set_id"],
                source_text_hash=_hash(item["text"]),
                result=result,
            )


def main() -> int:
    parser = argparse.ArgumentParser(description="Embeddings backfill (Session 3 Milestone 6)")
    parser.add_argument("--table", choices=["companies", "innovx", "skills", "all"])
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--probe-dims", action="store_true")
    args = parser.parse_args()

    if args.probe_dims:
        providers.probe_dims()
        return 0

    if not args.table:
        parser.error("--table is required (or use --probe-dims)")

    dispatch = {
        "companies": _run_companies,
        "innovx":    _run_innovx,
        "skills":    _run_skills,
    }

    targets = list(dispatch) if args.table == "all" else [args.table]
    for t in targets:
        log.step(f"=== backfilling {t} " + ("(DRY-RUN) " if args.dry_run else "") + "===")
        dispatch[t](limit=args.limit, dry_run=args.dry_run)
        log.ok(f"{t} complete")

    return 0


if __name__ == "__main__":
    sys.exit(main())
