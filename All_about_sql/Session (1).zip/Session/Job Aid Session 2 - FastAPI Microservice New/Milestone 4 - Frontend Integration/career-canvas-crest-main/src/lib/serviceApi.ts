const INNOVX_API_URL = import.meta.env.VITE_INNOVX_API_URL || "http://localhost:8000";
const PLACEMENT_API_URL = import.meta.env.VITE_PLACEMENT_API_URL || "http://localhost:8002";
const COMPANY_API_URL = import.meta.env.VITE_COMPANY_API_URL || "http://localhost:8000";

const getErrorMessage = async (response: Response) => {
  try {
    const body = await response.json();
    return (body?.detail || body?.error || JSON.stringify(body)) as string;
  } catch {
    return `${response.status} ${response.statusText}`;
  }
};

export interface InnovxResponse {
  innovx_master: Record<string, unknown>;
  industry_trends: Array<Record<string, unknown>>;
  innovation_roadmap: Array<Record<string, unknown>>;
  competitive_landscape: Array<Record<string, unknown>>;
  strategic_pillars: Array<Record<string, unknown>>;
  innovx_projects: Array<Record<string, unknown>>;
}

export interface CompanyJsonRow {
  company_id: number;
  short_json?: Record<string, unknown>;
}

export interface CompanyFullJsonRow {
  company_id: number;
  full_json?: Record<string, unknown>;
}

export interface Company {
  company_id: number;
  name?: string;
  short_name?: string;
  category?: string;
  incorporation_year?: string;  // Changed from number to string
  nature_of_company?: string;
  headquarters_address?: string;
  office_count?: string;
  employee_size?: string;
  website_url?: string;
  linkedin_url?: string;
  twitter_handle?: string;
  facebook_url?: string;
  instagram_url?: string;
  primary_contact_email?: string;
  primary_phone_number?: string;
  overview_text?: string;
  vision_statement?: string;
  mission_statement?: string;
  legal_issues?: string;
  carbon_footprint?: string;
}

export interface PlacementAnalytics {
  company: {
    name: string;
    category?: string;
    incorporation_year?: number;
    headquarters_address?: string;
    employee_size?: string;
    operating_countries?: string;
  };
  skill_levels: Array<{
    skill_area: string;
    level: number;
    proficiency_code: string;
  }>;
  hiring_jobs: Array<{
    job_role: string;
    opportunity_type?: string;
    compensation?: string;
    rounds: Array<{
      round_number: number;
      round_name: string;
      evaluation_type?: string;
      assessment_mode?: string;
    }>;
  }>;
  skill_coverage_pct: number;
  avg_skill_level: number;
  total_hiring_rounds: number;
}

export interface SkillIntelligenceLevel {
  level: number;
  name: string;
  desc: string;
}

export interface SkillIntelligenceItem {
  name: string;
  bloom: "CU" | "AP" | "AS" | "EV" | "CR";
  bloomLabel: string;
  score: number;
  criticality: "Critical" | "Important" | "Baseline";
  description: string;
  targetLevel: number;
  levels: SkillIntelligenceLevel[];
}

export interface HiringRoundsResponse {
  company_name?: string;
  job_role_details?: Array<Record<string, unknown>>;
}

export async function fetchCompanies(): Promise<CompanyJsonRow[]> {
  const response = await fetch(`${COMPANY_API_URL}/api/v1/companies`);
  if (!response.ok) {
    throw new Error(await getErrorMessage(response));
  }
  return response.json();
}

export async function fetchCompany(companyId: number): Promise<CompanyJsonRow> {
  const response = await fetch(`${COMPANY_API_URL}/api/v1/companies/${companyId}`);
  if (!response.ok) {
    throw new Error(await getErrorMessage(response));
  }
  return response.json();
}

export async function fetchCompanyFullJson(companyId: number): Promise<CompanyFullJsonRow> {
  const response = await fetch(`${COMPANY_API_URL}/api/v1/companies/${companyId}/full-json`);
  if (!response.ok) {
    throw new Error(await getErrorMessage(response));
  }
  return response.json();
}

export async function fetchCompanyDetails(): Promise<Company[]> {
  const response = await fetch(`${COMPANY_API_URL}/api/v1/company-details`);
  if (!response.ok) {
    throw new Error(await getErrorMessage(response));
  }
  return response.json();
}

export async function fetchCompanyDetail(companyId: number): Promise<Company> {
  const response = await fetch(`${COMPANY_API_URL}/api/v1/company-details/${companyId}`);
  if (!response.ok) {
    throw new Error(await getErrorMessage(response));
  }
  return response.json();
}

export async function fetchInnovX(companyId: number, companyName?: string): Promise<InnovxResponse> {
  const params = new URLSearchParams();
  if (companyName) {
    params.set("company_name", companyName);
  }

  const query = params.toString();
  const response = await fetch(
    `${INNOVX_API_URL}/api/v1/innovx/${companyId}${query ? `?${query}` : ""}`
  );
  if (!response.ok) {
    throw new Error(await getErrorMessage(response));
  }
  return response.json();
}

export async function fetchPlacementAnalytics(companyName: string): Promise<PlacementAnalytics> {
  const response = await fetch(`${PLACEMENT_API_URL}/placement?company_name=${encodeURIComponent(companyName)}`);
  if (!response.ok) {
    throw new Error(await getErrorMessage(response));
  }
  return response.json();
}

export async function fetchHiringRounds(companyId: number, companyName?: string): Promise<HiringRoundsResponse> {
  const params = new URLSearchParams();
  if (companyName) {
    params.set("company_name", companyName);
  }

  const query = params.toString();
  const response = await fetch(
    `${COMPANY_API_URL}/api/v1/hiring-rounds/${companyId}${query ? `?${query}` : ""}`
  );
  if (!response.ok) {
    throw new Error(await getErrorMessage(response));
  }
  return response.json();
}

export async function fetchSkillIntelligence(companyId: number): Promise<SkillIntelligenceItem[]> {
  const response = await fetch(`${COMPANY_API_URL}/api/v1/skill-intelligence/${companyId}`);
  if (!response.ok) {
    throw new Error(await getErrorMessage(response));
  }
  return response.json();
}
