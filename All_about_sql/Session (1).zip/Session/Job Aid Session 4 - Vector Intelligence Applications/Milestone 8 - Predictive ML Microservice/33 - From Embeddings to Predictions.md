# 33 — From Embeddings to Predictions  *(PPT — 5 min)*

## Why ML on top of embeddings

Embeddings are dense numeric features that already encode meaning. Plain old scikit-learn models — Logistic Regression, XGBoost, Random Forest — trained on those features get surprisingly strong baselines with **tiny** training sets and **no** GPU.

Rules of thumb:

- <1k labels, ~500-dim embedding → Logistic Regression is usually the best first model.
- >10k labels or heavy non-linearity → Gradient Boosting (XGBoost / LightGBM).
- Similarity, no labels → skip the classifier entirely, use cosine distance directly.

Milestone 8 covers **one classifier** and **one similarity scorer**, both served from the same FastAPI app.

## The two tasks

| Endpoint | Task type | Input | Output |
|----------|-----------|-------|--------|
| `POST /predict/category` | Multi-class classification | Company overview text | Predicted `category` + probability table |
| `POST /placement/fit`    | Similarity (no model) | Candidate skill profile | Cosine-fit % + top-3 matching companies |

## What we are *not* doing

- **No training in class.** We ship a pre-trained `.joblib`; students load it.
- **No GPU.** Everything runs on CPU.
- **No deep learning.** The heavy lifting is done by the embedding model; the classifier on top is intentionally shallow.

## Why a separate microservice on `:8004`

Keeping search (`:8003`) and prediction (`:8004`) separate lets either one scale, fail, or ship independently. Same Supabase schema, same embeddings — different SLAs.
