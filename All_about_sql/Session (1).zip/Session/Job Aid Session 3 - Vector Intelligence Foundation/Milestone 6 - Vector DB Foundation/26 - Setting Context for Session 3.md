# 26 — Setting Context for Session 3  *(PPT — 10 min)*

## What we are building today

**One script.** `backfill.py` — a standalone CLI that reads existing Supabase rows (companies, InnovX projects, skill levels), turns their text into **vector embeddings** via two providers, and writes those vectors back into three new pgvector tables.

Nothing else ships today. Next the vectors get consumed by search + ML microservices.

## Why vectors on top of data we already have

The Supabase rows from Sessions 1 & 2 are text and numbers. Questions like *"find me companies similar to Fractal"* or *"which InnovX projects look like this new one?"* cannot be answered by SQL `WHERE` clauses — the rows are not keyword-matched, they are **semantically related**. Embeddings turn each text field into a 768-3072-dim numeric vector where "similar meaning" becomes "small cosine distance."

## Why two providers instead of one

Free tiers go down. Rate limits exist. For a classroom demo we want the backfill to **finish** the first time it runs.

- **Primary — `gemini-embedding-2-preview`** (Gemini API). High quality, Matryoshka-configurable output dim.
- **Fallback — `nvidia/llama-nemotron-embed-vl-1b-v2:free`** (OpenRouter). Different dim — that is why we have two parallel vector columns.

On every row the script tries Gemini first; if Gemini errors or rate-limits, it falls back to the NVIDIA model and records `model_used` so the read-side knows which column to query.

## Why a separate session (why not fold into Session 2)

- **Separate venv, separate `.env`.** No risk of breaking the agent or microservice environments.
- **Separate day.** Embedding 50 companies × 10 fields takes a few minutes. That is the whole class for this session — the Milestone 6 lesson *is* the embedding pipeline.
- **Foundation before application.** Search and ML only make sense once embeddings exist. Session 4 assumes Session 3 ran successfully.

## End-of-day deliverable

```
Supabase
├── companies            (Session 1) ──► company_embeddings        ◄── NEW
├── staging_innovx       (Session 2) ──► innovx_embeddings         ◄── NEW
└── staging_company_skill_levels      ──► skill_embeddings         ◄── NEW
                          (Session 1)
```

Three vector tables, backfilled, HNSW-indexed, ready for Session 4.
