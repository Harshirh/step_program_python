# Milestone 4 - Frontend Integration

This milestone covers connecting the React frontend to the FastAPI backend from milestone 3.

Frontend folder:

`Milestone 4 - Frontend Integration/career-canvas-crest-main`

Prerequisites:

- See [PREREQUISITES.md](../PREREQUISITES.md)

## Learning Objective

Students should learn how to:

- configure frontend environment variables
- connect UI pages to backend APIs
- understand where Supabase project credentials come from
- verify API requests in the browser Network tab

## Step 1 - Ensure Backend is Running

Run milestone 3 backend first:

```powershell
cd "C:\Users\DELL\Downloads\SRM\Job Aid Session 2 - FastAPI Microservice\Milestone-3\placement-analytics-service"
.venv\Scripts\Activate.ps1
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

## Step 2 - Get Supabase Project URL and Publishable Key

Official docs:

- Supabase API keys: https://supabase.com/docs/guides/api/api-keys
- Supabase API routes and project URL: https://supabase.com/docs/guides/api/creating-routes

Detailed steps:

1. Sign in to the Supabase Dashboard.
2. Open the required project.
3. Click `Connect`.
4. Locate the `Project URL`.
5. Copy the project URL. It usually looks like:
   `https://<project-ref>.supabase.co`
6. Locate the `Publishable key`.
7. Copy the publishable key value. It typically starts with `sb_publishable_`.
8. If needed, you can also open `Project Settings -> API Keys` to view the project keys.

## Step 3 - Get the Database URL from Supabase

Official docs:

- Supabase connection strings: https://supabase.com/docs/reference/postgres/connection-strings

Detailed steps:

1. Open the same Supabase project.
2. Click `Connect`.
3. Go to the PostgreSQL connection string section.
4. Copy the `Session pooler` URI if IPv4 support is needed.
5. Replace `[YOUR-PASSWORD]` with the actual password.

## Step 4 - Update the Frontend `.env`

File:

`Milestone 4 - Frontend Integration/career-canvas-crest-main/.env`

Recommended values:

```env
VITE_COMPANY_API_URL=http://localhost:8000
VITE_INNOVX_API_URL=http://localhost:8000
VITE_PLACEMENT_API_URL=http://localhost:8002

VITE_SUPABASE_URL=https://<project-ref>.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_xxxxxxxxx
VITE_DATABASE_URL=postgresql://postgres.<project-ref>:<your-password>@aws-1-ap-south-1.pooler.supabase.com:5432/postgres
```

## Step 5 - Install Frontend Dependencies

```powershell
cd "C:\Users\DELL\Downloads\SRM\Job Aid Session 2 - FastAPI Microservice\Milestone 4 - Frontend Integration\career-canvas-crest-main"
npm install
```

## Step 6 - Run the Frontend

```powershell
npm run dev
```

## Step 7 - Validate the Integration

1. Open the frontend URL shown by Vite.
2. Open the browser DevTools.
3. Go to the `Network` tab.
4. Navigate through the home page, dashboard, intelligence, skills, rounds, and InnovX pages.
5. Confirm API calls are going to the backend.

## API Design Note

- Home page uses only the `short_json` API payload.
- Dashboard uses a separate `full_json` API payload.

This reduces unnecessary server load and keeps each API response focused on the page requirement.
