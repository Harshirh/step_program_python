"""Timestamped, colour-coded terminal logging so students can see progress.

Usage:
    from log import step, ok, warn, err, detail

    step("loading rows from Supabase")
    ok("47 rows loaded")
    warn("Gemini rate-limited, falling back")
    err("DB upsert failed: ...")
    detail("prompt_chars=1284")
"""
from __future__ import annotations

import sys
from datetime import datetime

try:
    from rich.console import Console
    _console = Console(stderr=False, soft_wrap=False)

    def _emit(icon: str, style: str, msg: str, indent: int = 0) -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        prefix = "  " * indent
        _console.print(f"[dim]{ts}[/dim] {prefix}[{style}]{icon}[/] {msg}")

    def step(msg: str) -> None:   _emit("▶", "bold cyan",  msg, indent=0)
    def ok(msg: str) -> None:     _emit("✓", "bold green", msg, indent=1)
    def warn(msg: str) -> None:   _emit("!", "bold yellow",msg, indent=1)
    def err(msg: str) -> None:    _emit("✗", "bold red",   msg, indent=1)
    def detail(msg: str) -> None: _emit("·", "dim",        msg, indent=1)

except ImportError:
    # graceful degradation if rich is missing
    def _plain(icon: str, msg: str, indent: int = 0) -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        prefix = "  " * indent
        print(f"[{ts}] {prefix}{icon} {msg}", flush=True, file=sys.stdout)

    def step(msg: str) -> None:   _plain("▶", msg, 0)
    def ok(msg: str) -> None:     _plain("✓", msg, 1)
    def warn(msg: str) -> None:   _plain("!", msg, 1)
    def err(msg: str) -> None:    _plain("✗", msg, 1)
    def detail(msg: str) -> None: _plain("·", msg, 1)
