# 32 — Semantic Search FastAPI  *(Hands-On — 25 min)*

FastAPI service on **port 8003**. Reads `company_embeddings` + `innovx_embeddings` (written by Session 3 Milestone 6) and serves semantic search with optional LLM re-ranking.

## Setup

```bash
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # macOS / Linux
pip install -r requirements.txt
cp .env.example .env           # fill the 3 keys
uvicorn main:app --port 8003 --reload
```

Open `http://localhost:8003/docs`.

## Endpoints

| Method | Path | Body / Query | Returns |
|--------|------|--------------|---------|
| POST | `/search/companies` | `{ "query": "...", "k": 5, "rerank": true }` | top-k companies + optional LLM explanation (streamed to terminal) |
| POST | `/search/projects`  | `{ "query": "...", "k": 5 }` | top-k InnovX projects |
| GET  | `/similar/{company_id}` | `?k=5&rerank=true` | "more like company X" with LLM-generated reasoning |
| GET  | `/health` | — | `{"status": "ok", "embedding_provider": "...", "llm_provider": "..."}` |

## What you see in the terminal when a request comes in

```
[15:02:11] ▶ POST /search/companies  query="AI consultancy in fintech"
[15:02:11]   → Gemini: embedding 30 chars (dim=768)
[15:02:12]   ✓ Gemini OK — dim=768
[15:02:12]   · pgvector top-5 from company_embeddings (gemini column)
[15:02:12]   ✓ 5 hits, best similarity=0.83
[15:02:12] ▶ LLM rerank with openai/gpt-oss-120b:free (streaming)
[15:02:12]   · chunk 1: "Looking at the five candidate companies…"
[15:02:13]   · chunk 2: "…Fractal Analytics aligns best because…"
[15:02:14]   ✓ rerank complete, 412 tokens
[15:02:14] ← 200 OK in 2.8s
```

Every HTTP call, every SQL query, every LLM chunk is printed — no silent stalls.

## Failure behaviour (intentional)

| Failure | What happens |
|---------|--------------|
| Gemini embedding errors | Falls back to NVIDIA embedding, queries `embedding_nvidia` column instead. |
| Primary LLM errors/times out | Falls back to `nvidia/nemotron-3-super-120b-a12b:free`. |
| Both LLMs fail | Returns raw top-k with `rerank_skipped: true` in the response. |
| Supabase connection lost | Returns 503 with clear message — no silent retry. |

## Files

| File | Purpose |
|------|---------|
| `requirements.txt` | fastapi, uvicorn, google-genai, openai, psycopg[binary], pgvector, python-dotenv, rich |
| `.env.example`     | `GEMINI_API_KEY`, `OPENROUTER_API_KEY`, `SUPABASE_DB_URL` |
| `providers.py`     | `embed(text)` + `chat_stream(messages)` with fallback; streams chunks to terminal |
| `retriever.py`     | Pure-SQL top-k against pgvector, both columns |
| `main.py`          | FastAPI app, `/search/*`, `/similar/{id}`, `/health` |

## Intentional non-scope

- No pagination, no caching, no rate limiting.
- No auth.
- No hybrid search (keyword + vector). Pure vector only.
