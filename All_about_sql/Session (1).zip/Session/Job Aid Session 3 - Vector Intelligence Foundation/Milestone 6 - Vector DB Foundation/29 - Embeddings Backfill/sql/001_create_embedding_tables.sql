-- 001_create_embedding_tables.sql
-- Run against SUPABASE_DB_URL:
--   psql "$SUPABASE_DB_URL" -f sql/001_create_embedding_tables.sql
--
-- Verify provider dims with `python backfill.py --probe-dims` before editing
-- the numbers below.

CREATE EXTENSION IF NOT EXISTS vector;

-- ----------------------------------------------------------------------------
-- company_embeddings
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS company_embeddings (
    id                 bigserial PRIMARY KEY,
    company_id         integer NOT NULL REFERENCES public.companies(company_id) ON DELETE CASCADE,
    field_name         text    NOT NULL,
    source_text_hash   text    NOT NULL,
    embedding_gemini   vector(768),
    embedding_nvidia   halfvec(2048),
    model_used         text    NOT NULL,
    created_at         timestamptz NOT NULL DEFAULT now(),
    UNIQUE (company_id, field_name)
);

CREATE INDEX IF NOT EXISTS company_embeddings_gemini_hnsw
    ON company_embeddings USING hnsw (embedding_gemini vector_cosine_ops);

CREATE INDEX IF NOT EXISTS company_embeddings_nvidia_hnsw
    ON company_embeddings USING hnsw (embedding_nvidia halfvec_cosine_ops);

-- ----------------------------------------------------------------------------
-- innovx_embeddings
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS innovx_embeddings (
    id                 bigserial PRIMARY KEY,
    innovx_id          integer NOT NULL,            -- FK to innovx_json.id
    company_id         integer,
    project_idx        smallint NOT NULL,
    source_text_hash   text    NOT NULL,
    embedding_gemini   vector(768),
    embedding_nvidia   halfvec(2048),
    model_used         text    NOT NULL,
    created_at         timestamptz NOT NULL DEFAULT now(),
    UNIQUE (innovx_id, project_idx)
);

CREATE INDEX IF NOT EXISTS innovx_embeddings_gemini_hnsw
    ON innovx_embeddings USING hnsw (embedding_gemini vector_cosine_ops);

CREATE INDEX IF NOT EXISTS innovx_embeddings_nvidia_hnsw
    ON innovx_embeddings USING hnsw (embedding_nvidia halfvec_cosine_ops);

-- ----------------------------------------------------------------------------
-- skill_embeddings
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS skill_embeddings (
    id                 bigserial PRIMARY KEY,
    skill_set_id       integer NOT NULL,            -- FK to skill_set_master.skill_set_id
    source_text_hash   text    NOT NULL,
    embedding_gemini   vector(768),
    embedding_nvidia   halfvec(2048),
    model_used         text    NOT NULL,
    created_at         timestamptz NOT NULL DEFAULT now(),
    UNIQUE (skill_set_id)
);

CREATE INDEX IF NOT EXISTS skill_embeddings_gemini_hnsw
    ON skill_embeddings USING hnsw (embedding_gemini vector_cosine_ops);

CREATE INDEX IF NOT EXISTS skill_embeddings_nvidia_hnsw
    ON skill_embeddings USING hnsw (embedding_nvidia halfvec_cosine_ops);
