# 29 — Embeddings Backfill  *(Hands-On — 30 min)*

Standalone CLI that reads Supabase rows and writes dual-provider vector embeddings into three new pgvector tables.

## Setup

```bash
# from this folder:
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # macOS / Linux

pip install -r requirements.txt
cp .env.example .env           # then fill in the 3 keys
```

### Required env vars

| Name                 | Where to get it                                           |
|----------------------|-----------------------------------------------------------|
| `GEMINI_API_KEY`     | https://aistudio.google.com/apikey                        |
| `OPENROUTER_API_KEY` | https://openrouter.ai/keys                                |
| `SUPABASE_DB_URL`    | Supabase → Project Settings → Database → Connection string (URI, **transaction pooler** on port 6543 recommended) |

## SQL migration

Run **once** against the Supabase project:

```bash
psql "$SUPABASE_DB_URL" -f sql/001_create_embedding_tables.sql
```

Creates 3 tables + HNSW indexes. Safe to re-run (uses `IF NOT EXISTS`).

## CLI usage

```bash
# 1) Verify what dim each provider is actually returning
python backfill.py --probe-dims

# 2) Dry-run 10 companies — prints every call, writes nothing
python backfill.py --table companies --limit 10 --dry-run

# 3) Real backfill, one table at a time
python backfill.py --table companies
python backfill.py --table innovx
python backfill.py --table skills
```

After all three complete, verify in Supabase SQL editor:
```sql
  SELECT
    (SELECT count(*) FROM company_embeddings) AS companies,
    (SELECT count(*) FROM innovx_embeddings)  AS innovx,
    (SELECT count(*) FROM skill_embeddings)   AS skills;
```

### Flags

| Flag            | Effect                                                     |
|-----------------|------------------------------------------------------------|
| `--table`       | `companies` \| `innovx` \| `skills` \| `all`               |
| `--limit N`     | Cap rows processed (useful for dry-runs).                  |
| `--dry-run`     | Embed + log, skip DB writes.                               |
| `--probe-dims`  | Fetch one embedding per provider, print dim, exit.         |
| `--resume`      | Skip rows that already have an embedding in the target table. |
| `--verbose`     | Extra detail — prints every prompt and provider response header. |

## What you will see streaming to the terminal

```
[13:48:02] ▶ probing provider dims…
[13:48:03]   Gemini       → dim = 768  (model gemini-embedding-2-preview, matryoshka)
[13:48:04]   OpenRouter   → dim = 2048 (model nvidia/llama-nemotron-embed-vl-1b-v2:free)
[13:48:04] ▶ loaded 47 companies from Supabase
[13:48:04] ▶ row 1/47  company_id=3  field=overview_text  (1284 chars)
[13:48:04]   → Gemini: embedding 1284 chars
[13:48:05]   ✓ Gemini OK — dim=768
[13:48:05]   ↳ upsert company_embeddings (company_id=3, field=overview_text)  OK
[13:48:05] ▶ row 1/47  company_id=3  field=vision_statement  (342 chars)
...
```

Every HTTP call, every retry, every DB write logs a line.  No silent stalls.

## Files in this folder

| File                                  | Purpose                                                    |
|---------------------------------------|------------------------------------------------------------|
| `requirements.txt`                    | Isolated package list — nothing reused from Session 1.     |
| `.env.example`                        | Template; copy to `.env`.                                  |
| `sql/001_create_embedding_tables.sql` | Schema migration.                                          |
| `providers.py`                        | `embed(text)` with Gemini → NVIDIA fallback + colour logs. |
| `log.py`                              | Timestamped, colour-coded step/ok/warn/err helpers.        |
| `db.py`                               | psycopg + pgvector connection; `upsert_embedding(...)`.    |
| `sources.py`                          | Reads rows from `companies` / `staging_innovx` / `staging_company_skill_levels`. |
| `backfill.py`                         | CLI entrypoint — argparse + the main row loop.             |

## Intentional non-scope

- **No async / parallelism.** One row at a time keeps logs linear and debuggable.
- **No chunking.** InnovX project blobs are short enough to embed whole.
- **No re-embedding on row change.** `--resume` only skips rows with an existing embedding; it does not detect text changes.
- **No cost tracking.** Free tiers, but students should still eyeball their API dashboards.
