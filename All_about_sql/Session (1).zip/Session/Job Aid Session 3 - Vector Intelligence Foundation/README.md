# Job Aid Session 3 — Vector Intelligence Foundation

Standalone — does **not** reuse the Session 1 venv or `.env`. Reads the Supabase tables populated by Sessions 1 & 2 and augments them with vector embeddings.

## Scope

| Milestone | Focus | Items |
|-----------|-------|-------|
| **Milestone 6** | Vector DB foundation — pgvector tables, dual-provider embedding backfill. | 26 – 29 |

Session 4 (the next day) builds the **Semantic Search** and **Predictive ML** microservices on top of the embeddings written here.

## Provider Wiring

| Purpose | Primary | Fallback |
|---------|---------|----------|
| Embeddings | `gemini-embedding-2-preview` (Gemini API) | `nvidia/llama-nemotron-embed-vl-1b-v2:free` (OpenRouter) |

Different dims → we store **two parallel vector columns** per row (`embedding_gemini` + `embedding_nvidia`). Whichever provider succeeds fills its column; the search path at read-time picks the one that exists.

## New Supabase tables (additive — no Session 1/2 tables are modified)

```
company_embeddings     (company_id, field_name, embedding_gemini, embedding_nvidia, model_used, created_at)
innovx_embeddings      (staging_innovx_id, project_idx, embedding_gemini, embedding_nvidia, model_used, created_at)
skill_embeddings       (skill_level_id, embedding_gemini, embedding_nvidia, model_used, created_at)
```

HNSW index on each vector column for cosine distance.

## Shared venv? No.

This session gets its **own** isolated venv and `.env` — see `Milestone 6 - Vector DB Foundation/29 - Embeddings Backfill/README.md`.

Packages: `google-genai`, `openai` (for OpenRouter), `pgvector`, `psycopg[binary]`, `python-dotenv`, `rich`.

## Run order

1. `cd "Milestone 6 - Vector DB Foundation/29 - Embeddings Backfill"`
2. `python -m venv venv && venv\Scripts\activate`  *(Windows; macOS/Linux: `source venv/bin/activate`)*
3. `pip install -r requirements.txt`
4. Copy `.env.example` → `.env`, fill `GEMINI_API_KEY`, `OPENROUTER_API_KEY`, `SUPABASE_DB_URL`.
5. Run the SQL migration: `psql "$SUPABASE_DB_URL" -f sql/001_create_embedding_tables.sql`
6. `python backfill.py --probe-dims`   *(prints the actual embedding dim returned by each provider)*
7. Adjust the `vector(N)` dims in the SQL file if the probe disagrees, re-run migration.
8. `python backfill.py --table companies --limit 10 --dry-run`  *(sanity-check 10 rows, no writes)*
9. `python backfill.py --table companies`                       *(real backfill)*
10. Repeat for `--table innovx` and `--table skills`.

Every step streams progress to the terminal — see `providers.py` and the `log.step(...)` calls in `backfill.py`.
