export type BloomLevel = "CU" | "AP" | "AS" | "EV" | "CR";
export type Criticality = "Critical" | "Important" | "Baseline";

export interface SkillLevel {
  level: number;
  name: string;
  desc: string;
}

export interface SkillArea {
  name: string;
  bloom: BloomLevel;
  bloomLabel: string;
  score: number;
  criticality: Criticality;
  description: string;
  targetLevel: number;
  levels: SkillLevel[];
}

export const bloomInfo: Record<BloomLevel, { label: string; shortLabel: string; bg: string; text: string; tintBg: string; textColor: string; borderColor: string }> = {
  CU: { label: "Conceptual Understanding", shortLabel: "CU", bg: "bg-[#3b82f6]", text: "text-white", tintBg: "bg-[#eff6ff]", textColor: "text-[#3b82f6]", borderColor: "border-[#3b82f6]" },
  AP: { label: "Application", shortLabel: "AP", bg: "bg-[#22c55e]", text: "text-white", tintBg: "bg-[#f0fdf4]", textColor: "text-[#22c55e]", borderColor: "border-[#22c55e]" },
  AS: { label: "Analysis & Synthesis", shortLabel: "AS", bg: "bg-[#eab308]", text: "text-white", tintBg: "bg-[#fefce8]", textColor: "text-[#eab308]", borderColor: "border-[#eab308]" },
  EV: { label: "Evaluate", shortLabel: "EV", bg: "bg-[#ef4444]", text: "text-white", tintBg: "bg-[#fff1f2]", textColor: "text-[#ef4444]", borderColor: "border-[#ef4444]" },
  CR: { label: "Creation", shortLabel: "CR", bg: "bg-[#a855f7]", text: "text-white", tintBg: "bg-[#faf5ff]", textColor: "text-[#a855f7]", borderColor: "border-[#a855f7]" },
};

export const criticalityInfo: Record<Criticality, { bg: string; text: string; barColor: string; headerBg: string; headerText: string }> = {
  Critical: { bg: "bg-[#fff1f2]", text: "text-[#dc2626]", barColor: "bg-[#ef4444]", headerBg: "bg-[#fff1f2]", headerText: "text-[#dc2626]" },
  Important: { bg: "bg-[#fffbeb]", text: "text-[#d97706]", barColor: "bg-[#f59e0b]", headerBg: "bg-[#fffbeb]", headerText: "text-[#d97706]" },
  Baseline: { bg: "bg-[#f0fdf4]", text: "text-[#16a34a]", barColor: "bg-[#22c55e]", headerBg: "bg-[#f0fdf4]", headerText: "text-[#16a34a]" },
};
