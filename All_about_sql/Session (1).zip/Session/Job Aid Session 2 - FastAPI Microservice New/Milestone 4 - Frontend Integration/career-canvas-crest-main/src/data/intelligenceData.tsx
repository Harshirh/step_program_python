import React from "react";
import {
  Building2,
  Target,
  ShieldAlert,
  Gem,
  Globe,
  Phone,
} from "lucide-react";

export interface IntelligenceField {
  label: string;
  column: string;
  value: string;
  type?: "url" | "rating" | "list" | "paragraph" | "video";
}

export interface IntelligenceSection {
  icon: React.ReactNode;
  title: string;
  fields: IntelligenceField[];
}

interface FieldDef {
  label: string;
  column: string;
  type?: IntelligenceField["type"];
}

interface SectionDef {
  icon: React.ReactNode;
  title: string;
  fields: FieldDef[];
}

const sectionDefinitions: SectionDef[] = [
  {
    icon: <Building2 className="w-4 h-4" />,
    title: "Company Identity",
    fields: [
      { label: "Company Name", column: "name" },
      { label: "Short Name", column: "short_name" },
      { label: "Category", column: "category" },
      { label: "Nature of Company", column: "nature_of_company" },
      { label: "Year of Incorporation", column: "incorporation_year" },
      { label: "Company Headquarters", column: "headquarters_address" },
      { label: "Employee Size", column: "employee_size" },
      { label: "Number of Offices", column: "office_count" },
    ],
  },
  {
    icon: <Target className="w-4 h-4" />,
    title: "Overview & Vision",
    fields: [
      { label: "Overview of the Company", column: "overview_text", type: "paragraph" },
      { label: "Vision", column: "vision_statement", type: "paragraph" },
      { label: "Mission", column: "mission_statement", type: "paragraph" },
    ],
  },
  {
    icon: <ShieldAlert className="w-4 h-4" />,
    title: "Risk & Compliance",
    fields: [
      { label: "Legal Issues", column: "legal_issues", type: "paragraph" },
    ],
  },
  {
    icon: <Gem className="w-4 h-4" />,
    title: "Core Value Proposition & ESG",
    fields: [
      { label: "Carbon Footprint / Environmental Impact", column: "carbon_footprint" },
    ],
  },
  {
    icon: <Globe className="w-4 h-4" />,
    title: "Digital Presence & Ratings",
    fields: [
      { label: "Website URL", column: "website_url", type: "url" },
      { label: "LinkedIn Profile URL", column: "linkedin_url", type: "url" },
      { label: "Twitter (X) Handle", column: "twitter_handle", type: "url" },
      { label: "Facebook Page URL", column: "facebook_url", type: "url" },
      { label: "Instagram Page URL", column: "instagram_url", type: "url" },
    ],
  },
  {
    icon: <Phone className="w-4 h-4" />,
    title: "Contact Information",
    fields: [
      { label: "Primary Contact Email", column: "primary_contact_email", type: "url" },
      { label: "Primary Phone Number", column: "primary_phone_number" },
    ],
  },
];

export function buildIntelligenceSections(
  companyJson?: Record<string, string | null | undefined>
): IntelligenceSection[] {
  const data = companyJson ?? {};

  return sectionDefinitions.map((section) => ({
    icon: section.icon,
    title: section.title,
    fields: section.fields.map((field) => ({
      label: field.label,
      column: field.column,
      value: (data[field.column] as string) ?? "",
      type: field.type,
    })),
  }));
}
