"""Supabase Postgres connection + upsert helpers for the 3 embedding tables."""
from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Iterator

import psycopg
from dotenv import load_dotenv
from pgvector.psycopg import HalfVector, register_vector

import log
from providers import EmbedResult


def _split(result: EmbedResult) -> tuple[list[float] | None, HalfVector | None]:
    """Return (gemini_vec, nvidia_halfvec) based on which provider answered.

    The NVIDIA column is declared `halfvec(2048)` in SQL (float16) because
    pgvector's HNSW index on the regular `vector` type caps at 2000 dims.
    Wrapping the list in HalfVector lets psycopg bind it to that column.
    """
    if result.provider == "gemini":
        return list(result.vector), None
    return None, HalfVector(result.vector)

load_dotenv()
SUPABASE_DB_URL = os.environ["SUPABASE_DB_URL"]


@contextmanager
def connect() -> Iterator[psycopg.Connection]:
    log.detail("opening Supabase connection")
    with psycopg.connect(SUPABASE_DB_URL, autocommit=False) as conn:
        register_vector(conn)
        try:
            yield conn
        except Exception:
            conn.rollback()
            raise


def upsert_company_embedding(
    conn: psycopg.Connection,
    *,
    company_id: int,
    field_name: str,
    source_text_hash: str,
    result: EmbedResult,
) -> None:
    gemini_vec, nvidia_vec = _split(result)
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO company_embeddings
              (company_id, field_name, source_text_hash,
               embedding_gemini, embedding_nvidia, model_used)
            VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (company_id, field_name) DO UPDATE SET
              source_text_hash = EXCLUDED.source_text_hash,
              embedding_gemini = COALESCE(EXCLUDED.embedding_gemini, company_embeddings.embedding_gemini),
              embedding_nvidia = COALESCE(EXCLUDED.embedding_nvidia, company_embeddings.embedding_nvidia),
              model_used       = EXCLUDED.model_used,
              created_at       = now();
            """,
            (company_id, field_name, source_text_hash, gemini_vec, nvidia_vec, result.model),
        )
    conn.commit()
    log.ok(f"upsert company_embeddings (company_id={company_id}, field={field_name})")


def upsert_innovx_embedding(
    conn: psycopg.Connection,
    *,
    innovx_id: int,
    company_id: int | None,
    project_idx: int,
    source_text_hash: str,
    result: EmbedResult,
) -> None:
    gemini_vec, nvidia_vec = _split(result)
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO innovx_embeddings
              (innovx_id, company_id, project_idx, source_text_hash,
               embedding_gemini, embedding_nvidia, model_used)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (innovx_id, project_idx) DO UPDATE SET
              company_id       = EXCLUDED.company_id,
              source_text_hash = EXCLUDED.source_text_hash,
              embedding_gemini = COALESCE(EXCLUDED.embedding_gemini, innovx_embeddings.embedding_gemini),
              embedding_nvidia = COALESCE(EXCLUDED.embedding_nvidia, innovx_embeddings.embedding_nvidia),
              model_used       = EXCLUDED.model_used,
              created_at       = now();
            """,
            (innovx_id, company_id, project_idx, source_text_hash, gemini_vec, nvidia_vec, result.model),
        )
    conn.commit()
    log.ok(f"upsert innovx_embeddings (innovx_id={innovx_id}, idx={project_idx})")


def upsert_skill_embedding(
    conn: psycopg.Connection,
    *,
    skill_set_id: int,
    source_text_hash: str,
    result: EmbedResult,
) -> None:
    gemini_vec, nvidia_vec = _split(result)
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO skill_embeddings
              (skill_set_id, source_text_hash,
               embedding_gemini, embedding_nvidia, model_used)
            VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT (skill_set_id) DO UPDATE SET
              source_text_hash = EXCLUDED.source_text_hash,
              embedding_gemini = COALESCE(EXCLUDED.embedding_gemini, skill_embeddings.embedding_gemini),
              embedding_nvidia = COALESCE(EXCLUDED.embedding_nvidia, skill_embeddings.embedding_nvidia),
              model_used       = EXCLUDED.model_used,
              created_at       = now();
            """,
            (skill_set_id, source_text_hash, gemini_vec, nvidia_vec, result.model),
        )
    conn.commit()
    log.ok(f"upsert skill_embeddings (skill_set_id={skill_set_id})")
