import { useState, useEffect } from "react";
import {
  Briefcase,
  Target,
  FileText,
  Layers,
  Banknote,
  Laptop,
  Users,
  Building,
  ArrowRight,
  BrainCircuit,
  Lightbulb,
  ChevronDown,
  ChevronUp,
  FileCode2,
  Award,
  Gift,
  Check,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { fetchCompany, fetchHiringRounds } from "@/lib/serviceApi";
import { useCompany } from "@/context/CompanyContext";
import { normalizeHiringData, type RoleHiringPipeline } from "@/lib/companyData";
import { CompanyLogo } from "@/components/ui/CompanyLogo";

// ── Skill code → full readable label ─────────────────────────────────────────
const SKILL_LABELS: Record<string, string> = {
  COD: "Coding", APTI: "Aptitude", OS: "Operating Systems", NETW: "Networking",
  COMM: "Communication", HR: "HR Round", SQL: "SQL", DSA: "Data Structures",
  OOD: "Object-Oriented Design", DBMS: "Database Management", CN: "Computer Networks",
  SE: "Software Engineering", AI: "Artificial Intelligence", ML: "Machine Learning",
  WEB: "Web Development", MOB: "Mobile Development", CS: "Computer Science",
  ALGO: "Algorithms", MATH: "Mathematics", STAT: "Statistics",
  SYS: "System Design", CLOUD: "Cloud Computing", SEC: "Security",
  QA: "Quality Assurance", PM: "Project Management", AGILE: "Agile / Scrum",
  EMBED: "Embedded Systems", ELEC: "Electronics", MICRO: "Microcontrollers",
  CTRL: "Control Systems", SIGNAL: "Signal Processing", CIRC: "Circuit Design",
  Cod: "Coding", Apti: "Aptitude", Comm: "Communication", Dsa: "Data Structures",
  Ood: "Object-Oriented Design", Sql: "SQL", Os: "Operating Systems",
  Netw: "Networking", Dbms: "Database Management", Cn: "Computer Networks",
  Algo: "Algorithms", Sys: "System Design", Ml: "Machine Learning",
  Ai: "Artificial Intelligence", Web: "Web Development", Embed: "Embedded Systems",
  cod: "Coding", apti: "Aptitude", comm: "Communication", dsa: "Data Structures",
  ood: "Object-Oriented Design", sql: "SQL", os: "Operating Systems", netw: "Networking",
};

function resolveSkillName(raw: string): string {
  if (!raw) return raw;
  if (SKILL_LABELS[raw]) return SKILL_LABELS[raw];
  if (SKILL_LABELS[raw.toUpperCase()]) return SKILL_LABELS[raw.toUpperCase()];
  if (raw.length > 5 && raw !== raw.toUpperCase()) return raw;
  return raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase();
}

// ── Round category colour config ──────────────────────────────────────────────
interface RoundStyle {
  badge: string;   // Tailwind pill bg+text
  border: string;  // active border class
  text: string;    // active text class
  bg: string;      // active bg tint class
  ring: string;    // active ring class
  hex: string;     // raw hex for inline styles (accent bar, dot, badge bg)
}

const ROUND_STYLE: Record<string, RoundStyle> = {
  "Coding Test": { badge: "bg-[#2563eb] text-white", border: "border-[#2563eb]", text: "text-[#2563eb]", bg: "bg-[#2563eb]/6", ring: "ring-[#2563eb]/20", hex: "#2563eb" },
  Interview: { badge: "bg-[#7c3aed] text-white", border: "border-[#7c3aed]", text: "text-[#7c3aed]", bg: "bg-[#7c3aed]/6", ring: "ring-[#7c3aed]/20", hex: "#7c3aed" },
  HR: { badge: "bg-[#ea580c] text-white", border: "border-[#ea580c]", text: "text-[#ea580c]", bg: "bg-[#ea580c]/6", ring: "ring-[#ea580c]/20", hex: "#ea580c" },
  Aptitude: { badge: "bg-[#16a34a] text-white", border: "border-[#16a34a]", text: "text-[#16a34a]", bg: "bg-[#16a34a]/6", ring: "ring-[#16a34a]/20", hex: "#16a34a" },
  Technical: { badge: "bg-[#0f766e] text-white", border: "border-[#0f766e]", text: "text-[#0f766e]", bg: "bg-[#0f766e]/6", ring: "ring-[#0f766e]/20", hex: "#0f766e" },
};
const DEFAULT_STYLE: RoundStyle = {
  badge: "bg-[#2563eb] text-white", border: "border-[#2563eb]", text: "text-[#2563eb]",
  bg: "bg-[#2563eb]/6", ring: "ring-[#2563eb]/20", hex: "#2563eb",
};
const getRoundStyle = (cat?: string): RoundStyle => ROUND_STYLE[cat ?? ""] ?? DEFAULT_STYLE;

// ── Skill pill colours — same palette as CompanyDashboard ────────────────────
const PILL_COLORS = [
  "bg-[#eff6ff] text-[#1d4ed8] border border-[#bfdbfe]",
  "bg-[#f5f3ff] text-[#7c3aed] border border-[#ddd6fe]",
  "bg-[#ecfeff] text-[#0f766e] border border-[#a5f3fc]",
  "bg-[#fff7ed] text-[#c2410c] border border-[#fed7aa]",
  "bg-[#f0fdf4] text-[#15803d] border border-[#bbf7d0]",
  "bg-[#fef2f2] text-[#b91c1c] border border-[#fecaca]",
];

// ── Sub-components ────────────────────────────────────────────────────────────

function formatCompensation(amount: number | string | undefined | null, type?: string): string {
  if (!amount) return "Not Disclosed";
  const num = Number(amount);
  if (isNaN(num)) return String(amount);

  const isInternship = type?.toLowerCase().includes("intern");
  if (isInternship) {
    return `₹${num.toLocaleString("en-IN")} / month`;
  }

  if (num >= 100000) {
    const inLakhs = num / 100000;
    return `₹${Number(inLakhs.toFixed(2))} LPA`;
  } else if (num > 0 && num < 100) {
    return `₹${num} LPA`;
  }

  return `₹${num.toLocaleString("en-IN")}`;
}

function HeroBadge({ icon: Icon, label }: { icon: React.ElementType; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/10 border border-white/15 text-[11px] font-medium text-white/75">
      <Icon className="w-3 h-3 opacity-70 flex-shrink-0" />
      {label}
    </span>
  );
}

function SpecRow({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string }) {
  return (
    <div className="flex items-start justify-between py-2.5 border-b border-border/50 last:border-0 gap-4">
      <div className="flex items-center gap-2.5 text-muted-foreground flex-shrink-0">
        <div className="p-1.5 bg-secondary rounded-lg border border-border/50 flex-shrink-0">
          <Icon className="w-3.5 h-3.5" />
        </div>
        <span className="font-body text-sm">{label}</span>
      </div>
      <span className="font-body text-sm font-semibold text-foreground text-right leading-snug max-w-[160px]">{value}</span>
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────

export default function HiringPipeline() {
  const { companyId, companyName } = useCompany();

  const [pipelines, setPipelines] = useState<RoleHiringPipeline[]>([]);
  const [activeRoleIndex, setActiveRoleIndex] = useState(0);
  const [activeRoundIndex, setActiveRoundIndex] = useState(0);
  const [logoUrl, setLogoUrl] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [jdOpen, setJdOpen] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      if (!companyId) { setPipelines([]); setLoading(false); return; }
      const [hiringRes, companyRes] = await Promise.allSettled([
        fetchHiringRounds(companyId, companyName),
        fetchCompany(companyId),
      ]);
      if (companyRes.status === "fulfilled" && companyRes.value) {
        const json = companyRes.value.short_json || {};
        if (json?.logo_url) setLogoUrl(json.logo_url as string);
      }
      if (hiringRes.status !== "fulfilled" || !hiringRes.value) {
        setPipelines([]);
      } else {
        try {
          const normalized = normalizeHiringData(hiringRes.value);
          setPipelines(normalized.length ? normalized : []);
        } catch { setPipelines([]); }
      }
      setLoading(false);
    };
    fetchData();
  }, [companyId]);

  useEffect(() => { setActiveRoundIndex(0); }, [activeRoleIndex]);

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="rounded-xl bg-muted animate-pulse h-40" />
        <div className="bg-card rounded-xl border border-border/50 p-6 animate-pulse h-36" />
        <div className="flex gap-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 flex-1 bg-card rounded-xl border border-border/50 animate-pulse" />
          ))}
        </div>
        <div className="h-64 bg-card rounded-xl border border-border/50 animate-pulse" />
      </div>
    );
  }

  const currentPipeline = pipelines[activeRoleIndex] ?? pipelines[0];
  const rounds = currentPipeline?.rounds ?? [];
  const role = currentPipeline?.role ?? {};
  const activeRound = rounds[activeRoundIndex];
  const displayName = companyName || "Company";
  const activeStyle = getRoundStyle(activeRound?.roundCategory);

  const allSkillNames = Array.from(
    new Set(rounds.flatMap((r) => r.sections.map((s) => resolveSkillName(s.name))))
  );
  const isHard = rounds.length > 4 || allSkillNames.length > 5;

  // Empty state when no hiring data is available
  if (pipelines.length === 0) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
            <Target className="w-8 h-8 text-muted-foreground" />
          </div>
          <h2 className="font-heading font-semibold text-lg text-foreground mb-2">
            No Hiring Data Available
          </h2>
          <p className="font-body text-sm text-muted-foreground">
            Hiring pipeline information has not been configured for this company yet.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5 pb-8">

      {/* ── HERO ──────────────────────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-xl p-6 md:p-8 text-white relative overflow-hidden"
        style={{ background: "linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%)" }}
        role="banner"
      >
        <div className="relative z-10">
          <span className="inline-block text-[10px] uppercase tracking-widest text-white/50 bg-white/10 px-3 py-1 rounded-full mb-4 font-heading font-semibold">
            {displayName} · HIRING PIPELINE
          </span>
          <div className="flex items-center gap-4 mb-3">
            <div className="w-14 h-14 rounded-xl bg-white border border-border/50 flex items-center justify-center overflow-hidden flex-shrink-0 shadow-lg">
              <CompanyLogo name={displayName} databaseLogoUrl={logoUrl} className="w-full h-full object-contain p-2" />
            </div>
            <h1 className="font-heading text-2xl md:text-3xl lg:text-4xl font-bold text-white leading-tight">
              {role.role_title || "General Role"}
            </h1>
          </div>
          <div className="flex flex-wrap gap-2 mt-1">
            <HeroBadge icon={Briefcase} label={role.opportunity_type || "Employment"} />
            <HeroBadge icon={Building} label={role.role_category || "Multiple Locations"} />
            <HeroBadge icon={Banknote} label={role.ctc_or_stipend ? formatCompensation(role.ctc_or_stipend, role.opportunity_type) : "Competitive"} />
          </div>
        </div>
        {rounds.length > 0 && (
          <div className="absolute top-6 right-6 bg-white/10 backdrop-blur-sm rounded-lg px-4 py-2 text-center hidden md:block">
            <p className="text-2xl font-heading font-bold text-white">{rounds.length}</p>
            <p className="text-[10px] uppercase tracking-wide text-white/60 font-heading">Rounds</p>
          </div>
        )}
        <div className="absolute -right-20 -bottom-20 w-60 h-60 bg-dream/10 rounded-full blur-3xl pointer-events-none" />
      </motion.div>

      {/* ── ROLE SWITCHER ─────────────────────────────────────────────────── */}
      {pipelines.length > 1 && (
        <div className="inline-flex bg-secondary/60 p-1 rounded-xl w-max overflow-x-auto max-w-full hide-scrollbar border border-border/50">
          {pipelines.map((p, i) => (
            <button
              key={i}
              onClick={() => setActiveRoleIndex(i)}
              className={`px-5 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${activeRoleIndex === i
                  ? "bg-background text-foreground shadow-sm ring-1 ring-border"
                  : "text-muted-foreground hover:text-foreground hover:bg-black/5"
                }`}
            >
              {p.role.role_title}
            </button>
          ))}
        </div>
      )}

      {/* ── JOB DESCRIPTION ───────────────────────────────────────────────── */}
      {role.job_description && (
        <div className="bg-card rounded-xl shadow-sm border border-border/50 overflow-hidden">
          <button
            onClick={() => setJdOpen((v) => !v)}
            className="w-full flex items-center justify-between px-5 py-3.5 text-left select-none"
            aria-expanded={jdOpen}
          >
            <span className="font-heading font-semibold text-sm text-foreground flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-500 flex-shrink-0" />
              Job Description
            </span>
            {jdOpen
              ? <ChevronUp className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              : <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            }
          </button>
          <AnimatePresence initial={false}>
            {jdOpen && (
              <motion.div
                key="jd"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2, ease: "easeInOut" }}
                className="overflow-hidden"
              >
                <p className="font-body text-sm text-muted-foreground leading-relaxed border-t border-border/50 px-5 pt-4 pb-5">
                  {role.job_description}
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}

      {/* ── MAIN GRID ─────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_272px] gap-5 items-start">

        {/* ── LEFT ──────────────────────────────────────────────────────────── */}
        <div className="space-y-4 min-w-0">

          {/* ── Pipeline Rail ─────────────────────────────────────────────── */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-heading font-semibold text-base text-foreground flex items-center gap-2">
                <Target className="w-4 h-4 text-dream" />
                Hiring Process Flow
              </h2>
              <span className="font-body text-xs font-medium px-2.5 py-1 bg-secondary rounded-md border border-border/50 text-muted-foreground">
                {rounds.length} Rounds
              </span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-2 hide-scrollbar select-none">
              {rounds.map((round, idx) => {
                const isActive = activeRoundIndex === idx;
                const isPast = activeRoundIndex > idx;
                const s = getRoundStyle(round.roundCategory);
                const ModeIcon = round.assessmentMode === "Online" ? Laptop : Users;

                return (
                  <div key={idx} className="flex items-center flex-shrink-0">
                    {/* Rail card */}
                    <button
                      onClick={() => setActiveRoundIndex(idx)}
                      aria-pressed={isActive}
                      className={`relative flex flex-col min-w-[152px] px-3.5 py-3 rounded-xl border text-left transition-all duration-200 group ${isActive
                          ? `${s.border} ${s.bg} shadow-sm ring-2 ${s.ring}`
                          : "border-border/60 bg-card hover:border-border hover:bg-secondary/20"
                        }`}
                    >
                      {/* Row 1: R-number + category badge */}
                      <div className="flex items-center justify-between gap-1.5 mb-2">
                        <span
                          className="font-heading text-[10px] font-bold uppercase tracking-wider flex-shrink-0"
                          style={{ color: isActive ? s.hex : undefined }}
                        >
                          R{round.round}
                        </span>
                        <span
                          className="text-[10px] font-bold px-2 py-0.5 rounded-full text-white leading-tight whitespace-nowrap"
                          style={{ background: s.hex }}
                        >
                          {round.roundCategory}
                        </span>
                      </div>

                      {/* Row 2: Round name */}
                      <p
                        className="font-heading font-semibold text-[13px] leading-snug mb-2"
                        style={{ color: isActive ? s.hex : undefined }}
                      >
                        {round.name}
                      </p>

                      {/* Row 3: Mode */}
                      <div className="flex items-center gap-1 text-[11px] text-muted-foreground font-body">
                        <ModeIcon className="w-3 h-3 flex-shrink-0" />
                        {round.assessmentMode || "TBD"}
                      </div>

                      {/* Past-round indicator — small emerald pill in top-right corner INSIDE the card */}
                      {isPast && (
                        <span className="absolute top-2.5 right-2.5 inline-flex items-center justify-center w-[18px] h-[18px] rounded-full bg-emerald-500 shadow-sm">
                          <Check className="w-2.5 h-2.5 text-white stroke-[3]" />
                        </span>
                      )}
                    </button>

                    {idx < rounds.length - 1 && (
                      <ArrowRight className="w-3.5 h-3.5 text-muted-foreground/35 mx-1 flex-shrink-0" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* ── Active Round Detail ────────────────────────────────────────── */}
          <AnimatePresence mode="wait">
            {activeRound && (
              <motion.div
                key={activeRoundIndex}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.16 }}
                className="bg-card rounded-xl shadow-sm border border-border/50 overflow-hidden"
              >
                {/* Panel header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 border-b border-border/50 bg-secondary/30">
                  <div className="flex items-center gap-3">
                    {/* Coloured round-number square */}
                    <div
                      className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 font-heading text-[13px] font-bold text-white"
                      style={{ background: activeStyle.hex }}
                    >
                      {activeRound.round}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span
                          className="font-heading text-[10px] font-bold uppercase tracking-widest"
                          style={{ color: activeStyle.hex }}
                        >
                          Round {activeRound.round}
                        </span>
                        <span className="font-heading text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                          · {activeRound.roundCategory}
                        </span>
                      </div>
                      <h3 className="font-heading font-bold text-[17px] text-foreground leading-tight">
                        {activeRound.name}
                      </h3>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 sm:flex-shrink-0">
                    <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border/50 bg-card text-xs font-medium text-muted-foreground">
                      <Layers className="w-3.5 h-3.5 flex-shrink-0" />
                      {activeRound.evaluationType || "General"}
                    </div>
                    <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border/50 bg-card text-xs font-medium text-muted-foreground">
                      {activeRound.assessmentMode === "Online"
                        ? <Laptop className="w-3.5 h-3.5 flex-shrink-0" />
                        : <Users className="w-3.5 h-3.5 flex-shrink-0" />
                      }
                      {activeRound.assessmentMode || "TBD"}
                    </div>
                  </div>
                </div>

                {/* Panel body */}
                <div className="p-5">
                  <h4 className="font-heading font-semibold text-xs uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-1.5">
                    <BrainCircuit className="w-3.5 h-3.5 text-orange-500" />
                    Skill Sets Evaluated
                  </h4>

                  {activeRound.sections.length > 0 ? (
                    <div className="space-y-3">
                      {activeRound.sections.map((sec, idx) => {
                        const fullName = resolveSkillName(sec.name);
                        return (
                          <div key={idx} className="rounded-xl border border-border/50 overflow-hidden">
                            {/* Skill header with left accent bar */}
                            <div className="flex items-center gap-0 bg-secondary/50 border-b border-border/50">
                              <div
                                className="w-[3px] self-stretch flex-shrink-0"
                                style={{ background: activeStyle.hex }}
                              />
                              <div className="flex items-center gap-2.5 flex-1 px-3.5 py-2.5 min-w-0">
                                <FileCode2
                                  className="w-3.5 h-3.5 flex-shrink-0"
                                  style={{ color: activeStyle.hex }}
                                />
                                <span className="font-heading font-semibold text-[13px] text-foreground flex-1 min-w-0">
                                  {fullName}
                                </span>
                                <span
                                  className="text-[10px] font-heading font-bold px-2 py-0.5 rounded-full flex-shrink-0 text-white"
                                  style={{ background: activeStyle.hex }}
                                >
                                  {sec.items.length}Q
                                </span>
                              </div>
                            </div>

                            {/* Questions */}
                            <ul className="px-4 py-3 space-y-2">
                              {sec.items.map((item, i) => (
                                <li key={i} className="flex items-start gap-2.5">
                                  <div
                                    className="w-1.5 h-1.5 rounded-full mt-[7px] flex-shrink-0"
                                    style={{ background: activeStyle.hex }}
                                  />
                                  <span className="font-body text-sm text-foreground/80 leading-relaxed">{item}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="py-8 text-center bg-secondary/30 rounded-xl border border-dashed border-border/50">
                      <p className="font-body text-sm text-muted-foreground">No detailed topics specified for this round.</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ── RIGHT SIDEBAR ─────────────────────────────────────────────────── */}
        <div className="space-y-4">

          {/* Preparation Insights */}
          <div className="bg-card rounded-xl shadow-sm border border-border/50 p-5">
            <h2 className="font-heading font-semibold text-base mb-4 text-foreground flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-amber-500" />
              Preparation Insights
            </h2>

            <div className="mb-4">
              <p className="font-heading text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-2">
                Core Focus Areas
              </p>
              <div className="flex flex-wrap gap-1.5">
                {allSkillNames.length > 0
                  ? allSkillNames.slice(0, 8).map((name, i) => (
                    <span key={i} className={`px-2.5 py-1 rounded-full text-xs font-medium ${PILL_COLORS[i % PILL_COLORS.length]}`}>
                      {name}
                    </span>
                  ))
                  : <span className="font-body text-sm text-muted-foreground">Data unavailable</span>
                }
              </div>
            </div>

            {/* Unified stats: label left, value right, single bordered container */}
            <div className="rounded-xl border border-border/50 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-2.5 bg-secondary/40 border-b border-border/50">
                <p className="font-heading text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                  Difficulty
                </p>
                <p className={`font-heading font-bold text-sm ${isHard ? "text-rose-600" : "text-emerald-600"}`}>
                  {isHard ? "Medium–Hard" : "Easy–Medium"}
                </p>
              </div>
              <div className="flex items-center justify-between px-4 py-2.5 bg-secondary/40">
                <p className="font-heading text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                  Total Rounds
                </p>
                <p className="font-heading font-bold text-sm text-foreground">
                  {rounds.length} Stages
                </p>
              </div>
            </div>
          </div>

          {/* Compensation & Specs */}
          <div className="bg-card rounded-xl shadow-sm border border-border/50 p-5">
            <h2 className="font-heading font-semibold text-base mb-3 text-foreground flex items-center gap-2">
              <Award className="w-4 h-4 text-yellow-500" />
              Compensation &amp; Specs
            </h2>

            <SpecRow
              icon={Banknote}
              label="Package"
              value={formatCompensation(role.ctc_or_stipend, role.opportunity_type)}
            />
            <SpecRow icon={Gift} label="Bonus" value={role.bonus || "Not specified"} />
            <SpecRow icon={Briefcase} label="Comp Type" value={role.compensation || "Standard"} />

            {role.benefits_summary && (
              <div className="mt-3 pt-3 border-t border-border/50">
                <p className="font-heading text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-2">
                  Benefits
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {role.benefits_summary.split(",").map((b, i) => (
                    <span key={i} className="font-body text-xs px-2.5 py-1 bg-secondary text-muted-foreground rounded-full border border-border/50 whitespace-nowrap">
                      {b.trim()}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
