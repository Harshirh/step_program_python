import { useState, useEffect, useRef, useMemo, memo } from "react";
import {
  Globe, MapPin, ChevronDown, Rocket, Building2, Zap,
  LayoutTemplate, Target, TrendingUp, Users, FlaskConical,
  BarChart3, CheckCircle2, Layers, Code2, Sparkles,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useCompany } from "@/context/CompanyContext";
import { normalizeInnovXData } from "@/lib/companyData";
import type { InnovXViewModel } from "@/lib/companyData";
import { fetchInnovX } from "@/lib/serviceApi";
import { cn } from "@/lib/utils";

/* ─────────────────────────────────────────────────
   HELPERS
───────────────────────────────────────────────── */
const importanceColor = (imp?: string) => {
  switch ((imp ?? "").toLowerCase()) {
    case "critical": return "bg-red-50 text-red-600 border-red-200";
    case "high": return "bg-orange-50 text-orange-600 border-orange-200";
    default: return "bg-sky-50 text-sky-600 border-sky-200";
  }
};

const threatBadge = (t?: string) => {
  switch ((t ?? "").toLowerCase()) {
    case "high": return { cls: "bg-red-50 text-red-600 border-red-200", dot: "bg-red-500" };
    case "medium": return { cls: "bg-amber-50 text-amber-600 border-amber-200", dot: "bg-amber-400" };
    default: return { cls: "bg-emerald-50 text-emerald-600 border-emerald-200", dot: "bg-emerald-400" };
  }
};

const tierConfig = (tier?: string) => {
  switch ((tier ?? "").toLowerCase()) {
    case "tier 1": return { cls: "bg-violet-50 text-violet-700 border-violet-200", label: "Tier 1 · Core" };
    case "tier 2": return { cls: "bg-blue-50 text-blue-700 border-blue-200", label: "Tier 2 · Growth" };
    default: return { cls: "bg-slate-50 text-slate-600 border-slate-200", label: "Tier 3 · Future" };
  }
};

/* ─────────────────────────────────────────────────
   NAV CONFIG
───────────────────────────────────────────────── */
const NAV_ITEMS = [
  { id: "pillars", label: "Strategic Pillars", icon: Target, iconColor: "text-indigo-600" },
  { id: "roadmap", label: "Industry Trends", icon: Rocket, iconColor: "text-emerald-600" },
  { id: "themes", label: "Innovation Roadmap", icon: TrendingUp, iconColor: "text-blue-600" },
  { id: "projects", label: "InnovX Projects", icon: FlaskConical, iconColor: "text-amber-600" },
  { id: "competitors", label: "Competitive Landscape", icon: BarChart3, iconColor: "text-rose-600" },
];

/* ─────────────────────────────────────────────────
   EMPTY STATE
───────────────────────────────────────────────── */
const EmptyState = ({ message }: { message: string }) => (
  <div className="py-10 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200">
    <div className="w-10 h-10 rounded-full bg-slate-100 mx-auto mb-3 flex items-center justify-center">
      <Layers size={18} className="text-slate-400" />
    </div>
    <p className="text-sm text-slate-400">{message}</p>
  </div>
);

/* ─────────────────────────────────────────────────
   SECTION HEADER
───────────────────────────────────────────────── */
const SectionHeader = ({
  icon: Icon, title, subtitle, iconColor = "text-slate-600",
}: { icon: React.ElementType; title: string; subtitle?: string; iconColor?: string }) => (
  <div className="flex items-start gap-3 mb-4 md:mb-6">
    <div className="w-8 h-8 md:w-9 md:h-9 rounded-lg bg-slate-100 flex items-center justify-center shrink-0 mt-0.5">
      <Icon size={16} className={iconColor} />
    </div>
    <div>
      <h2 className="text-sm md:text-[15px] font-semibold text-slate-800 leading-tight tracking-tight">{title}</h2>
      {subtitle && <p className="text-[11px] md:text-xs text-slate-400 mt-0.5 leading-snug">{subtitle}</p>}
    </div>
  </div>
);

/* ═════════════════════════════════════════════════
   MAIN COMPONENT
═════════════════════════════════════════════════ */
const InnovX = () => {
  const { companyId, companyName } = useCompany();
  const [data, setData] = useState<InnovXViewModel | null>(null);
  const [innovxLoading, setInnovxLoading] = useState(false);
  const [innovxError, setInnovxError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTrendIdx, setActiveTrendIdx] = useState<string | null>(null);
  const [expandedProject, setExpandedProject] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState(0);

  const tabBarRef = useRef<HTMLDivElement>(null);
  const tabRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const sectionRefs = useRef<(HTMLElement | null)[]>([]);
  const isScrolling = useRef(false);
  const hasInnovxData = Boolean(data?.master || data?.pillars.length || data?.trends.length || data?.roadmap.length || data?.projects.length || data?.competitors.length);

  const getScrollContainer = (): HTMLElement =>
    (document.querySelector("main") as HTMLElement) ?? document.documentElement;

  const getOffset = () => 104;

  /* ── FETCH ── */
  useEffect(() => {
    let active = true;

    const fetchData = async () => {
      setLoading(true);
      setInnovxLoading(true);
      setInnovxError(null);

      if (!companyId) {
        if (!active) return;
        setData({ master: null, trends: [], roadmap: [], projects: [], competitors: [], pillars: [] });
        setLoading(false);
        setInnovxLoading(false);
        return;
      }

      try {
        const innovxData = await fetchInnovX(companyId, companyName);
        if (!active) return;
        setData(normalizeInnovXData(innovxData));
      } catch (error) {
        if (!active) return;
        setData({ master: null, trends: [], roadmap: [], projects: [], competitors: [], pillars: [] });
        setInnovxError(error instanceof Error ? error.message : String(error));
      } finally {
        if (!active) return;
        setLoading(false);
        setInnovxLoading(false);
      }
    };
    fetchData();

    return () => { active = false; };
  }, [companyId, companyName]);

  const scrollToSection = (idx: number) => {
    isScrolling.current = true;
    setActiveTab(idx);
    const el = sectionRefs.current[idx];
    const container = getScrollContainer();
    if (el && container) {
      const newTop =
        el.getBoundingClientRect().top -
        container.getBoundingClientRect().top +
        container.scrollTop -
        getOffset();
      container.scrollTo({ top: newTop, behavior: "smooth" });
    }
    const tab = tabRefs.current[idx];
    if (tab && tabBarRef.current) {
      tabBarRef.current.scrollTo({
        left: tab.offsetLeft - tabBarRef.current.offsetWidth / 2 + tab.offsetWidth / 2,
        behavior: "smooth",
      });
    }
    setTimeout(() => { isScrolling.current = false; }, 900);
  };

  const renderData = data ?? {
    master: null,
    trends: [],
    roadmap: [],
    projects: [],
    competitors: [],
    pillars: [],
  };
  const { master, trends, roadmap, projects, competitors, pillars } = renderData;

  const groupedTrends = useMemo(() => {
    const active = trends.filter(t => (t.timeHorizonYears ?? 0) <= 2);
    const emerging = trends.filter(t => (t.timeHorizonYears ?? 0) > 2 && (t.timeHorizonYears ?? 0) <= 5);
    const longTerm = trends.filter(t => (t.timeHorizonYears ?? 0) > 5);
    return [
      { label: "Active", sublabel: "0–2 Years", trends: active, color: "text-emerald-700", bg: "bg-emerald-50", border: "border-emerald-200", dot: "bg-emerald-500" },
      { label: "Emerging", sublabel: "2–5 Years", trends: emerging, color: "text-blue-700", bg: "bg-blue-50", border: "border-blue-200", dot: "bg-blue-500" },
      { label: "Long Term", sublabel: "5–10 Years", trends: longTerm, color: "text-amber-700", bg: "bg-amber-50", border: "border-amber-200", dot: "bg-amber-500" },
    ].filter(g => g.trends.length > 0);
  }, [trends]);

  /* ── LOADING ── */
  if (loading) {
    return (
      <div className="space-y-3 pt-4 animate-pulse px-0">
        <div className="h-36 md:h-44 bg-muted rounded-xl" />
        <div className="h-9 bg-muted rounded-xl" />
        {[...Array(3)].map((_, i) => (
          <div key={i} className="h-28 bg-card rounded-xl border border-border/50" />
        ))}
      </div>
    );
  }

  /* ════════════════════════════════════════════════
     RENDER
  ════════════════════════════════════════════════ */
  return (
    <div className="flex flex-col pb-10">

      {/* ══════════════════════════════════════════
          HERO — scrolls away, mobile-first layout
      ══════════════════════════════════════════ */}
      <div className="pt-3 md:pt-6 pb-0">
        {/* Platform label */}
        <div className="flex items-center gap-1.5 mb-2.5">
          <Sparkles size={12} className="text-violet-500" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-violet-500">InnovX Intelligence</span>
        </div>

        {master && (
          <>
            {/* Mobile: single stacked card | Desktop: 2-col grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">

              {/* Identity card */}
              <div className="bg-card border border-border/60 rounded-xl p-4 md:p-5 shadow-sm">
                <h1 className="font-bold text-foreground text-lg md:text-xl leading-tight mb-0.5">
                  {companyName || master.companyName}
                </h1>
                <p className="text-xs md:text-sm font-medium text-muted-foreground mb-3">
                  {master.industry} • {master.subIndustry}
                </p>
                {/* On mobile: 2-col pill grid for compact display */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div className="flex items-start gap-2 p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                    <Globe size={13} className="text-indigo-500 shrink-0 mt-0.5" />
                    <div className="min-w-0">
                      <p className="text-[9px] font-bold uppercase tracking-wider text-slate-400 mb-0.5">Target Market</p>
                      <p className="text-xs font-semibold text-slate-700 leading-snug">{master.targetMarket}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2 p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                    <MapPin size={13} className="text-rose-500 shrink-0 mt-0.5" />
                    <div className="min-w-0">
                      <p className="text-[9px] font-bold uppercase tracking-wider text-slate-400 mb-0.5">Geographic Focus</p>
                      <p className="text-xs font-semibold text-slate-700 leading-snug">{master.geographicFocus}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Business model card */}
              <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 md:p-5 shadow-sm">
                <div className="flex items-center gap-1.5 mb-1.5">
                  <LayoutTemplate size={13} className="text-emerald-600" />
                  <h4 className="font-bold text-slate-700 text-xs uppercase tracking-wider">Core Business Model</h4>
                </div>
                <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                  {master.coreBusinessModel}
                </p>
              </div>
            </div>
          </>
        )}

        {!master && (
          <div className="mb-3">
            <h1 className="font-bold text-foreground text-xl md:text-2xl">
              {companyName || "Innovation Portal"}
            </h1>
          </div>
        )}
      </div>

      {/* ══════════════════════════════════════════
          STICKY TAB BAR — only this part sticks
      ══════════════════════════════════════════ */}
      <div className="sticky top-0 z-10 bg-background border-b border-border/50 -mx-4 px-4 md:-mx-6 md:px-6 lg:-mx-8 lg:px-8">
        <div
          ref={tabBarRef}
          role="tablist"
          className="flex gap-1 md:gap-1.5 overflow-x-auto py-1.5 md:py-2"
          style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}
        >
          {NAV_ITEMS.map(({ id, label, icon: Icon, iconColor }, idx) => {
            const isActive = activeTab === idx;
            return (
              <button
                key={id}
                ref={el => { tabRefs.current[idx] = el; }}
                role="tab"
                aria-selected={isActive}
                onClick={() => scrollToSection(idx)}
                /* min-h-[44px] ensures 44 px tap target on mobile */
                className={cn(
                  "flex items-center gap-1 md:gap-1.5 whitespace-nowrap px-2.5 md:px-3 py-1.5 rounded-full",
                  "text-[11px] md:text-[12px] font-semibold min-h-[36px] md:min-h-[auto]",
                  "transition-all duration-200 shrink-0 border touch-manipulation",
                  isActive
                    ? "bg-dream text-white border-dream shadow-sm"
                    : "bg-secondary/60 text-muted-foreground border-transparent hover:bg-secondary hover:text-foreground"
                )}
              >
                <Icon size={12} className={isActive ? "text-white" : iconColor} />
                {/* On very small screens show shortened label */}
                <span className="hidden xs:inline sm:inline">{label}</span>
                <span className="xs:hidden sm:hidden">{label.split(" ")[0]}</span>
              </button>
            );
          })}
        </div>
      </div>

      {(innovxLoading || innovxError || !hasInnovxData) && (
        <div className="mt-4 rounded-3xl border border-border/70 bg-slate-50 p-4 md:p-5">
          <p className="text-sm text-slate-600">
            {innovxLoading
              ? "Loading InnovX intelligence from backend..."
              : "No InnovX intelligence is configured for this company yet."}
          </p>
          {innovxError && (
            <p className="mt-2 text-sm font-semibold text-red-600">
              InnovX backend error: {innovxError}
            </p>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════
          SECTIONS
      ══════════════════════════════════════════ */}
      <div className="space-y-5 md:space-y-6 mt-4 md:mt-6">

        {/* ── 1. STRATEGIC PILLARS ── */}
        <section ref={el => { sectionRefs.current[0] = el; }} id="section-pillars">
          <SectionHeader
            icon={Target}
            iconColor="text-indigo-600"
            title="Strategic Pillars"
            subtitle="Focus area, key technologies & CTO vision"
          />
          {pillars.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
              {pillars.map((p, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.06 }}
                  className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm"
                >
                  <div className="h-1 bg-gradient-to-r from-indigo-400 to-violet-400" />
                  <div className="p-4 md:p-5">
                    {/* Header row */}
                    <div className="flex items-start justify-between gap-2 mb-2.5">
                      <h4 className="font-bold text-slate-800 text-[13px] md:text-base leading-tight">{p.pillarName}</h4>
                      <span className={cn(
                        "text-[9px] md:text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border shrink-0",
                        p.focusArea?.toLowerCase() === "disruption"
                          ? "bg-rose-50 text-rose-600 border-rose-200"
                          : "bg-blue-50 text-blue-600 border-blue-200"
                      )}>
                        {p.focusArea}
                      </span>
                    </div>
                    <p className="text-xs md:text-sm text-slate-600 leading-relaxed mb-3">{p.description}</p>
                    {p.ctoVision && (
                      <div className="bg-indigo-50 border-l-2 border-indigo-400 rounded-r-lg px-3 py-2 mb-3">
                        <p className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-indigo-400 mb-1">CTO Vision Statement</p>
                        <p className="text-[11px] md:text-xs italic text-indigo-800 leading-snug">"{p.ctoVision}"</p>
                      </div>
                    )}
                    <div>
                      <p className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">Key Technologies</p>
                      <div className="flex flex-wrap gap-1 md:gap-1.5">
                        {p.technologies.map((t, idx) => (
                          <span key={idx} className="inline-flex items-center gap-1 text-[10px] md:text-[11px] font-semibold bg-slate-50 border border-slate-200 text-slate-600 px-2 py-0.5 rounded-md">
                            <Code2 size={8} className="text-slate-400" />{t}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <EmptyState message="No strategic pillars data available." />
          )}
        </section>

        {/* ── 2. INDUSTRY TRENDS ── */}
        <section ref={el => { sectionRefs.current[1] = el; }} id="section-roadmap">
          <SectionHeader
            icon={Rocket}
            iconColor="text-emerald-600"
            title="Industry Trends"
            subtitle="Strategic importance, time horizon, impact areas & trend drivers"
          />
          {groupedTrends.length > 0 ? (
            <div className="space-y-5">
              {groupedTrends.map((group, groupIdx) => (
                <div key={groupIdx}>
                  {/* Group label row */}
                  <div className="flex items-center gap-2 mb-2.5">
                    <div className={cn("w-2 h-2 rounded-full shrink-0", group.dot)} />
                    <span className={cn("text-[11px] font-bold uppercase tracking-widest", group.color)}>{group.label}</span>
                    <span className="text-[11px] text-slate-400 hidden sm:inline">· {group.sublabel}</span>
                    <div className="flex-1 h-px bg-slate-100" />
                    <span className="text-[10px] text-slate-400">{group.trends.length}</span>
                  </div>
                  <div className="space-y-1.5 md:space-y-2">
                    {group.trends.map((t, i) => {
                      const idx = `${groupIdx}-${i}`;
                      const isOpen = activeTrendIdx === idx;
                      return (
                        <div
                          key={idx}
                          className={cn(
                            "bg-white border rounded-xl overflow-hidden transition-all duration-200",
                            isOpen ? `border-l-[3px] ${group.border} shadow-sm` : "border-slate-200"
                          )}
                        >
                          {/* Tap target — min 48px tall on mobile */}
                          <button
                            className="w-full text-left px-3 py-3.5 md:p-4 flex items-center gap-3 touch-manipulation"
                            onClick={() => setActiveTrendIdx(isOpen ? null : idx)}
                          >
                            <div className={cn("w-2 h-2 rounded-full shrink-0", isOpen ? group.dot : "bg-slate-300")} />
                            <div className="flex-1 min-w-0">
                              {/* Title + chevron row */}
                              <div className="flex items-start justify-between gap-2">
                                <span className="text-[13px] md:text-sm font-semibold text-slate-800 leading-snug">{t.title}</span>
                                <ChevronDown size={14} className={cn("text-slate-400 shrink-0 mt-0.5 transition-transform duration-200", isOpen && "rotate-180")} />
                              </div>
                              {/* Badges row — below title on mobile */}
                              <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                                {t.importance && (
                                  <span className={cn("text-[9px] md:text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border", importanceColor(t.importance))}>
                                    {t.importance}
                                  </span>
                                )}
                                {t.period && (
                                  <span className="text-[9px] md:text-[10px] text-slate-400 bg-slate-50 border border-slate-200 px-1.5 py-0.5 rounded">
                                    {t.period}
                                  </span>
                                )}
                              </div>
                            </div>
                          </button>

                          <AnimatePresence initial={false}>
                            {isOpen && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: "auto", opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.2 }}
                                className="overflow-hidden"
                              >
                                <div className={cn("px-3 md:px-4 pb-4 border-t", group.border)}>
                                  <p className="text-xs md:text-sm text-slate-600 leading-relaxed pt-3 mb-3">{t.description}</p>
                                  {/* Stack on mobile, 2-col on sm+ */}
                                  <div className="space-y-3 sm:grid sm:grid-cols-2 sm:gap-4 sm:space-y-0">
                                    {t.impactAreas.length > 0 && (
                                      <div>
                                        <p className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Impact Areas</p>
                                        <div className="flex flex-wrap gap-1 md:gap-1.5">
                                          {t.impactAreas.map((a, j) => (
                                            <span key={j} className="text-[10px] md:text-[11px] font-semibold bg-slate-50 border border-slate-200 text-slate-600 px-2 py-0.5 rounded-md">{a}</span>
                                          ))}
                                        </div>
                                      </div>
                                    )}
                                    {t.drivers.length > 0 && (
                                      <div>
                                        <p className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Trend Drivers</p>
                                        <div className="flex flex-wrap gap-1 md:gap-1.5">
                                          {t.drivers.map((d, j) => (
                                            <span key={j} className={cn("text-[10px] md:text-[11px] font-semibold px-2 py-0.5 rounded-md border", group.bg, group.border, group.color)}>{d}</span>
                                          ))}
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <EmptyState message="No industry trends data available." />
          )}
        </section>

        {/* ── 3. INNOVATION ROADMAP ── */}
        <section ref={el => { sectionRefs.current[2] = el; }} id="section-themes">
          <SectionHeader
            icon={TrendingUp}
            iconColor="text-blue-600"
            title="Innovation Roadmap"
            subtitle="Innovation themes, problem statements, expected outcomes & required capabilities"
          />
          {roadmap.length > 0 ? (
            /* Mobile: single col stack | md: 2-col | lg: 3-col */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
              {roadmap.map((item, i) => {
                const phaseRaw = item.timeHorizon?.toLowerCase() || "";
                let phase = { label: "Now", sublabel: "0–2 Yrs", bg: "bg-emerald-500", lightBg: "bg-emerald-50", border: "border-emerald-200", text: "text-emerald-700" };
                if (phaseRaw.includes("next") || i === 1) {
                  phase = { label: "Next", sublabel: "2–5 Yrs", bg: "bg-blue-500", lightBg: "bg-blue-50", border: "border-blue-200", text: "text-blue-700" };
                } else if (phaseRaw.includes("future") || phaseRaw.includes("long") || i >= 2) {
                  phase = { label: "Future", sublabel: "5–10 Yrs", bg: "bg-amber-500", lightBg: "bg-amber-50", border: "border-amber-200", text: "text-amber-700" };
                }
                return (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 12 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.08 }}
                    className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm"
                  >
                    {/* Phase header */}
                    <div className={cn("px-3 md:px-4 py-2 flex items-center justify-between", phase.lightBg)}>
                      <div className="flex items-center gap-1.5">
                        <span className={cn("w-5 h-5 rounded text-white flex items-center justify-center text-[9px] font-bold shrink-0", phase.bg)}>{i + 1}</span>
                        <span className={cn("text-[10px] md:text-[11px] font-bold uppercase tracking-wider", phase.text)}>
                          {item.timeHorizon || phase.label}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {item.innovationType && (
                          <span className="text-[9px] font-semibold text-slate-400 bg-white border border-slate-200 px-1.5 py-0.5 rounded hidden sm:inline">
                            {item.innovationType}
                          </span>
                        )}
                        <span className="text-[9px] md:text-[10px] text-slate-400">{phase.sublabel}</span>
                      </div>
                    </div>

                    <div className="p-3 md:p-5">
                      <h4 className="font-bold text-slate-800 text-[13px] md:text-[15px] leading-snug mb-1">{item.title}</h4>
                      {item.targetCustomer && (
                        <div className="flex items-center gap-1 mb-2">
                          <Users size={10} className="text-slate-400 shrink-0" />
                          <p className="text-[10px] text-slate-400">Target: {item.targetCustomer}</p>
                        </div>
                      )}
                      <p className="text-xs md:text-sm text-slate-500 leading-relaxed mb-3">{item.problemStatement}</p>

                      {item.outcome && (
                        <div className="flex items-start gap-2 p-2.5 md:p-3 bg-slate-50 border border-slate-100 rounded-lg mb-3">
                          <CheckCircle2 size={12} className="text-emerald-500 mt-0.5 shrink-0" />
                          <div>
                            <p className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-0.5">Expected Outcome</p>
                            <p className="text-[11px] md:text-xs font-semibold text-slate-700 leading-snug">{item.outcome}</p>
                          </div>
                        </div>
                      )}

                      {item.capabilities.length > 0 && (
                        <div>
                          <p className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Required Capabilities</p>
                          <div className="flex flex-wrap gap-1 md:gap-1.5">
                            {item.capabilities.map((cap, idx) => (
                              <span key={idx} className="text-[10px] md:text-[11px] font-semibold bg-slate-50 border border-slate-200 text-slate-600 px-1.5 md:px-2 py-0.5 rounded-md">{cap}</span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <EmptyState message="No innovation roadmap data available." />
          )}
        </section>

        {/* ── 4. INNOVX PROJECTS ── */}
        <section ref={el => { sectionRefs.current[3] = el; }} id="section-projects">
          <SectionHeader
            icon={FlaskConical}
            iconColor="text-amber-600"
            title="InnovX Projects"
            subtitle={projects.length > 0 ? `${projects.length} projects · tier level, business value & target users` : "Project data"}
          />
          {projects.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 md:gap-4">
              {projects.map((p, i) => {
                const isExpanded = expandedProject === i;
                const tier = tierConfig(p.tierLevel);
                return (
                  <motion.div
                    key={i}
                    layout
                    className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm active:scale-[0.99] transition-transform touch-manipulation"
                    onClick={() => setExpandedProject(isExpanded ? null : i)}
                  >
                    <div className="p-3.5 md:p-5">
                      {/* Title + chevron */}
                      <div className="flex items-start justify-between gap-2 mb-2.5">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-[13px] md:text-[14px] text-slate-800 leading-snug mb-1.5">{p.title}</h4>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className={cn("text-[9px] md:text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border", tier.cls)}>{tier.label}</span>
                            {p.timeHorizon && (
                              <span className="text-[9px] md:text-[10px] font-semibold bg-slate-50 border border-slate-200 text-slate-500 px-1.5 py-0.5 rounded">{p.timeHorizon}</span>
                            )}
                          </div>
                        </div>
                        {/* 36px tap circle */}
                        <div className={cn(
                          "w-8 h-8 rounded-full flex items-center justify-center shrink-0 border",
                          isExpanded ? "bg-slate-100 border-slate-300" : "bg-slate-50 border-slate-200"
                        )}>
                          <ChevronDown size={13} className={cn("text-slate-500 transition-transform duration-200", isExpanded && "rotate-180")} />
                        </div>
                      </div>

                      <p className={cn("text-xs md:text-sm text-slate-600 leading-relaxed", !isExpanded && "line-clamp-2")}>{p.description}</p>

                      <AnimatePresence initial={false}>
                        {isExpanded && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden"
                          >
                            <div className="mt-3 pt-3 border-t border-slate-100 space-y-2.5">
                              {p.outcome && (
                                <div className="p-2.5 bg-emerald-50 border border-emerald-100 rounded-lg">
                                  <p className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-emerald-500 mb-0.5">Business Value</p>
                                  <p className="text-[11px] md:text-xs font-semibold text-slate-700 leading-snug">{p.outcome}</p>
                                </div>
                              )}
                              {p.targetCustomer && (
                                <div className="flex items-start gap-2">
                                  <Users size={11} className="text-slate-400 mt-0.5 shrink-0" />
                                  <div>
                                    <p className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-0.5">Target Users</p>
                                    <p className="text-[11px] md:text-xs font-semibold text-slate-600 leading-snug">{p.targetCustomer}</p>
                                  </div>
                                </div>
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Capabilities footer */}
                    {p.capabilities.length > 0 && (
                      <div className="px-3.5 md:px-5 pb-3.5 md:pb-4 pt-0 border-t border-slate-100">
                        <div className="flex flex-wrap gap-1 md:gap-1.5 pt-2.5">
                          {p.capabilities.slice(0, isExpanded ? undefined : 3).map((cap, idx) => (
                            <span key={idx} className="text-[9px] md:text-[10px] font-semibold bg-slate-50 border border-slate-100 text-slate-500 px-1.5 py-0.5 rounded">{cap}</span>
                          ))}
                          {!isExpanded && p.capabilities.length > 3 && (
                            <span className="text-[9px] md:text-[10px] text-slate-400 self-center">+{p.capabilities.length - 3} more</span>
                          )}
                        </div>
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <EmptyState message="No projects data available." />
          )}
        </section>

        {/* ── 5. COMPETITIVE LANDSCAPE ── */}
        <section ref={el => { sectionRefs.current[4] = el; }} id="section-competitors">
          <SectionHeader
            icon={BarChart3}
            iconColor="text-rose-600"
            title="Competitive Landscape"
            subtitle="Competitor name, threat level, innovation category, market positioning & core strength"
          />
          {competitors.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
              {competitors.map((c, i) => {
                const threat = threatBadge(c.threatLevel);
                return (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 8 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.06 }}
                    className="bg-white border border-slate-200 rounded-xl p-3.5 md:p-5 shadow-sm"
                  >
                    {/* Name + threat badge — wraps on very small screens */}
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-[13px] md:text-[14px] text-slate-800 leading-tight mb-1">{c.competitorName}</h4>
                        {c.competitorType && (
                          <span className="text-[9px] md:text-[10px] font-semibold bg-slate-100 text-slate-600 border border-slate-200 px-1.5 py-0.5 rounded-md">
                            {c.competitorType} Competitor
                          </span>
                        )}
                      </div>
                      <div className={cn("flex items-center gap-1 px-2 py-1 rounded-full border text-[9px] md:text-[10px] font-bold uppercase tracking-wider shrink-0", threat.cls)}>
                        <div className={cn("w-1.5 h-1.5 rounded-full shrink-0", threat.dot)} />
                        {c.threatLevel}
                      </div>
                    </div>

                    <div className="space-y-2.5">
                      {c.innovationCategory && (
                        <div className="flex items-start gap-2">
                          <Zap size={11} className="text-slate-400 shrink-0 mt-0.5" />
                          <div className="min-w-0">
                            <span className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">Innovation Category</span>
                            <span className="text-[11px] md:text-xs font-semibold text-slate-700">{c.innovationCategory}</span>
                          </div>
                        </div>
                      )}
                      {c.marketPositioning && (
                        <div className="flex items-start gap-2">
                          <Target size={11} className="text-slate-400 shrink-0 mt-0.5" />
                          <div className="min-w-0">
                            <span className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">Market Positioning</span>
                            <span className="text-[11px] md:text-xs font-semibold text-slate-700">{c.marketPositioning}</span>
                          </div>
                        </div>
                      )}
                      {c.coreStrength && (
                        <div className="bg-slate-50 border border-slate-100 rounded-lg p-2.5">
                          <p className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Core Strength</p>
                          <p className="text-[11px] md:text-xs text-slate-600 font-medium leading-snug">{c.coreStrength}</p>
                        </div>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <EmptyState message="No competitor data available." />
          )}
        </section>

      </div>

      <style dangerouslySetInnerHTML={{
        __html: `
        [role="tablist"]::-webkit-scrollbar { display: none; }
        [role="tablist"] { -ms-overflow-style: none; scrollbar-width: none; }
      `}} />
    </div>
  );
};

export default InnovX;






