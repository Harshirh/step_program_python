"""Dual-provider embedding with streaming terminal output.

Primary  : gemini-embedding-2-preview            (Gemini API,  google-genai SDK)
Fallback : nvidia/llama-nemotron-embed-vl-1b-v2:free  (OpenRouter, OpenAI-compat)

The caller only sees `EmbedResult(provider, vector)`; which provider answered is
recorded so the DB writer knows which column to fill.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Literal

from dotenv import load_dotenv

import log

load_dotenv()

GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]
OPENROUTER_API_KEY = os.environ["OPENROUTER_API_KEY"]
GEMINI_OUTPUT_DIM = int(os.getenv("GEMINI_OUTPUT_DIM", "768"))

GEMINI_MODEL = "gemini-embedding-2-preview"
NVIDIA_MODEL = "nvidia/llama-nemotron-embed-vl-1b-v2:free"


@dataclass(frozen=True)
class EmbedResult:
    provider: Literal["gemini", "nvidia"]
    model: str
    vector: list[float]

    @property
    def dim(self) -> int:
        return len(self.vector)


# --- lazy client singletons ---------------------------------------------------

_gemini_client = None
_openrouter_client = None


def _gemini():
    global _gemini_client
    if _gemini_client is None:
        from google import genai
        _gemini_client = genai.Client(api_key=GEMINI_API_KEY)
    return _gemini_client


def _openrouter():
    global _openrouter_client
    if _openrouter_client is None:
        from openai import OpenAI
        _openrouter_client = OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=OPENROUTER_API_KEY,
        )
    return _openrouter_client


# --- individual providers -----------------------------------------------------

def embed_with_gemini(text: str) -> EmbedResult:
    log.detail(f"→ Gemini: embedding {len(text)} chars (dim={GEMINI_OUTPUT_DIM})")
    resp = _gemini().models.embed_content(
        model=GEMINI_MODEL,
        contents=[text],
        config={"output_dimensionality": GEMINI_OUTPUT_DIM},
    )
    vec = list(resp.embeddings[0].values)
    log.ok(f"Gemini OK — dim={len(vec)}")
    return EmbedResult(provider="gemini", model=GEMINI_MODEL, vector=vec)


def embed_with_nvidia(text: str) -> EmbedResult:
    """Fallback path via OpenRouter.  On failure, run a raw HTTP probe so the
    real response body is visible — the OpenAI SDK's ``ValueError: No embedding
    data received`` hides the underlying reason (wrong endpoint support,
    non-standard shape, rate limit, etc.)."""
    log.detail(f"→ OpenRouter NVIDIA: embedding {len(text)} chars")
    try:
        # encoding_format="float" is REQUIRED for OpenAI-compat providers that
        # ignore the SDK's default base64 request and always return floats.
        # Without it the SDK attempts a base64 decode on the float list and
        # raises ValueError: No embedding data received.
        resp = _openrouter().embeddings.create(
            model=NVIDIA_MODEL,
            input=text,
            encoding_format="float",
        )
        vec = list(resp.data[0].embedding)
        log.ok(f"NVIDIA OK — dim={len(vec)}")
        return EmbedResult(provider="nvidia", model=NVIDIA_MODEL, vector=vec)
    except Exception as e:  # noqa: BLE001
        log.warn(f"OpenAI SDK failed: {type(e).__name__}: {e}")
        log.step("running raw HTTP probe against OpenRouter to reveal response body…")
        _raw_openrouter_probe(text)
        raise


def _raw_openrouter_probe(text: str) -> None:
    """Call OpenRouter's /embeddings endpoint with httpx and print the result."""
    import json
    import httpx

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://localhost",
        "X-Title": "dsa-mentor backfill probe",
    }
    payload = {"model": NVIDIA_MODEL, "input": text}
    url = "https://openrouter.ai/api/v1/embeddings"
    try:
        r = httpx.post(url, headers=headers, json=payload, timeout=30.0)
    except Exception as e:  # noqa: BLE001
        log.err(f"raw probe transport error: {type(e).__name__}: {e}")
        return
    log.detail(f"HTTP {r.status_code}")
    log.detail(f"response headers (subset): "
               f"x-openrouter-provider={r.headers.get('x-openrouter-provider')!r}  "
               f"x-ratelimit-remaining={r.headers.get('x-ratelimit-remaining')!r}")
    body_preview = r.text[:800]
    log.detail(f"response body[:800]: {body_preview}")
    try:
        parsed = r.json()
        if isinstance(parsed, dict):
            if "error" in parsed:
                log.err(f"OpenRouter error.message: {parsed['error'].get('message')!r}")
                log.err(f"OpenRouter error.code:    {parsed['error'].get('code')!r}")
            elif "data" in parsed and isinstance(parsed["data"], list):
                log.detail(f"data array length: {len(parsed['data'])}")
                if parsed["data"]:
                    first = parsed["data"][0]
                    keys = list(first.keys()) if isinstance(first, dict) else "n/a"
                    log.detail(f"data[0] keys: {keys}")
    except json.JSONDecodeError:
        log.err("response body was not valid JSON")


# --- the one function the backfill calls --------------------------------------

def embed(text: str) -> EmbedResult:
    """Try Gemini; on any failure fall back to NVIDIA via OpenRouter."""
    try:
        return embed_with_gemini(text)
    except Exception as e:  # noqa: BLE001 — classroom-grade catch-all is intentional
        log.warn(f"Gemini failed: {type(e).__name__}: {e}")
        log.step("falling back to OpenRouter NVIDIA…")
        return embed_with_nvidia(text)


def probe_dims() -> None:
    """Fetch one embedding from each provider, print the dim, return."""
    log.step("probing provider dims (one embedding per provider)")
    probe_text = "vector intelligence probe"
    try:
        g = embed_with_gemini(probe_text)
        log.ok(f"Gemini       → dim={g.dim}  model={g.model}")
    except Exception as e:  # noqa: BLE001
        log.err(f"Gemini probe failed: {type(e).__name__}: {e}")
    try:
        n = embed_with_nvidia(probe_text)
        log.ok(f"OpenRouter   → dim={n.dim}  model={n.model}")
    except Exception as e:  # noqa: BLE001
        log.err(f"OpenRouter probe failed: {type(e).__name__}: {e}")
    log.step("probe complete — adjust sql/001_create_embedding_tables.sql if needed")
