# See ../35 - Category Classifier/main.py — the /placement/fit route is defined
# in the same FastAPI app to reuse the embedding client and keep deployment to
# one process.
#
# This file is intentionally empty of runtime code.  It exists so the job-aid
# folder numbering matches the lesson plan.
#
# To run the service:
#   cd "../35 - Category Classifier"
#   uvicorn main:app --port 8004 --reload
