# 35 — Category Classifier  *(Hands-On — 20 min)*

FastAPI service on **port 8004** with a single endpoint backed by a pre-trained scikit-learn pipeline.

## Setup

```bash
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # macOS / Linux

pip install -r requirements.txt
cp .env.example .env           # fill GEMINI_API_KEY, OPENROUTER_API_KEY, SUPABASE_DB_URL
```

### Drop the pre-trained artifact in place

Place `category_classifier.joblib` into `artifacts/`. You should receive this file from the instructor — it was trained on the Gemini-768 embeddings that Session 3 produced.

```
artifacts/
  README.md
  category_classifier.joblib        ◄── add this
```

### Run

```bash
uvicorn main:app --port 8004 --reload
```

Open `http://localhost:8004/docs`.

Item 36 adds `/placement/fit` to the **same** service — no new uvicorn process.

## Endpoint

```
POST /predict/category
{
  "company_overview": "We are a fintech analytics consultancy helping banks..."
}
```

Response:

```json
{
  "predicted_category": "Consulting",
  "probability": 0.71,
  "top_k": [
    {"category": "Consulting", "probability": 0.71},
    {"category": "Product",    "probability": 0.18},
    {"category": "Services",   "probability": 0.08}
  ],
  "embedding_provider": "gemini",
  "model_file": "artifacts/category_classifier.joblib"
}
```

## What streams to the terminal

```
[15:24:03] ▶ POST /predict/category  text_len=214
[15:24:03]   → Gemini: embedding 214 chars (dim=768)
[15:24:03]   ✓ Gemini OK — dim=768
[15:24:03]   · scoring against 12 categories
[15:24:03]   ✓ predicted=Consulting (p=0.71)
[15:24:03] ← 200 OK in 0.4s
```

## Failure behaviour

| Failure | Response |
|---------|----------|
| `.joblib` missing at startup | `/predict/category` returns `503 Service Unavailable` with a clear message. `/health` still works. |
| Embedding request fails on both providers | `502 Bad Gateway` with the underlying error. |
| Embedding dim ≠ model-expected dim | `500` with `"embedding dim mismatch: got 768, expected 768"` — a sanity guard. |

## Files

| File | Purpose |
|------|---------|
| `requirements.txt` | fastapi, uvicorn, scikit-learn, joblib, google-genai, openai, python-dotenv, rich, numpy |
| `.env.example` | `GEMINI_API_KEY`, `OPENROUTER_API_KEY`, `SUPABASE_DB_URL` |
| `main.py` | FastAPI app, lazy model loader, `/predict/category`, `/health` |
| `artifacts/README.md` | Where to put the `.joblib` |

## Intentional non-scope

- No training in this file. See item 34.
- No confidence calibration. Raw `predict_proba` only.
- No model versioning beyond the file name.
