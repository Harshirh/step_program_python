import { createContext, useContext, useEffect, useState, useCallback, useMemo, type ReactNode } from "react";
import { fetchCompany } from "@/lib/serviceApi";

const COMPANY_STORAGE_KEY = "selected-company";

const getStoredCompany = () => {
  if (typeof window === "undefined") {
    return { companyId: null as number | null, companyName: "", logoUrl: "" };
  }

  try {
    const raw = window.localStorage.getItem(COMPANY_STORAGE_KEY);
    if (!raw) {
      return { companyId: null as number | null, companyName: "", logoUrl: "" };
    }

    const parsed = JSON.parse(raw) as { companyId?: number; companyName?: string; logoUrl?: string };
    return {
      companyId: typeof parsed.companyId === "number" ? parsed.companyId : null,
      companyName: typeof parsed.companyName === "string" ? parsed.companyName : "",
      logoUrl: typeof parsed.logoUrl === "string" ? parsed.logoUrl : "",
    };
  } catch {
    return { companyId: null as number | null, companyName: "", logoUrl: "" };
  }
};

interface CompanyContextType {
  companyId: number | null;
  companyName: string;
  logoUrl: string;
  setCompany: (id: number, name: string, logo?: string) => void;
}

const CompanyContext = createContext<CompanyContextType>({
  companyId: null,
  companyName: "",
  logoUrl: "",
  setCompany: () => {},
});

export const useCompany = () => useContext(CompanyContext);

export function CompanyProvider({ children }: { children: ReactNode }) {
  const storedCompany = getStoredCompany();
  const [companyId, setCompanyId] = useState<number | null>(storedCompany.companyId);
  const [companyName, setCompanyName] = useState(storedCompany.companyName);
  const [logoUrl, setLogoUrl] = useState(storedCompany.logoUrl);

  useEffect(() => {
    // If we have a companyId but no logoUrl, try to fetch it from company_json
    if (companyId && !logoUrl) {
      const fetchLogo = async () => {
        try {
          const data = await fetchCompany(companyId);
          const json = data.short_json as any;
          if (json?.logo_url) {
            setLogoUrl(json.logo_url as string);
          }
        } catch {
          // Ignore failures; we can still render without a logo.
        }
      };
      fetchLogo();
    }
  }, [companyId, logoUrl]);

  useEffect(() => {
    if (typeof window === "undefined") {
      return;
    }

    try {
      if (companyId === null) {
        window.localStorage.removeItem(COMPANY_STORAGE_KEY);
        return;
      }

      window.localStorage.setItem(
        COMPANY_STORAGE_KEY,
        JSON.stringify({ companyId, companyName, logoUrl })
      );
    } catch {
      // Ignore storage failures and keep in-memory state.
    }
  }, [companyId, companyName, logoUrl]);

  const setCompany = useCallback((id: number, name: string, logo?: string) => {
    setCompanyId(id);
    setCompanyName(name);
    if (logo !== undefined) {
      setLogoUrl(logo);
    } else {
      setLogoUrl("");
    }
  }, []);

  const value = useMemo(() => ({
    companyId,
    companyName,
    logoUrl,
    setCompany,
  }), [companyId, companyName, logoUrl, setCompany]);

  return (
    <CompanyContext.Provider value={value}>
      {children}
    </CompanyContext.Provider>
  );
}
