// SRM Placement Portal - Service Worker
// Strategy: Cache-first for static assets, Network-first for API/Supabase

const CACHE_NAME = 'srm-portal-v1';
const STATIC_CACHE_NAME = 'srm-static-v1';
const API_CACHE_NAME = 'srm-api-v1';

const PRECACHE_URLS = [
  '/',
  '/manifest.json',
  '/favicon.ico',
  '/srm_logo.png',
  '/srm_favicon.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_URLS);
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== STATIC_CACHE_NAME && key !== API_CACHE_NAME)
          .map((key) => caches.delete(key))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  if (request.method !== 'GET') return;
  if (url.protocol === 'chrome-extension:') return;

  if (url.hostname.includes('supabase')) {
    event.respondWith(networkFirst(request, API_CACHE_NAME, 10 * 60));
    return;
  }

  if (url.hostname.includes('fonts.googleapis.com') || url.hostname.includes('fonts.gstatic.com')) {
    event.respondWith(networkFirst(request, STATIC_CACHE_NAME, 60 * 60 * 24));
    return;
  }

  if (url.pathname.match(/\.(js|css|woff2?|ttf|otf|png|jpg|jpeg|svg|ico|webp)$/)) {
    event.respondWith(cacheFirst(request, STATIC_CACHE_NAME));
    return;
  }

  if (request.mode === 'navigate') {
    event.respondWith(networkFirst(request, STATIC_CACHE_NAME, 60 * 60));
    return;
  }

  event.respondWith(networkFirst(request, CACHE_NAME, 5 * 60));
});

async function cacheFirst(request, cacheName) {
  const cached = await caches.match(request);
  if (cached) return cached;

  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(cacheName);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    return new Response('Offline - resource not cached.', { status: 503 });
  }
}

async function networkFirst(request, cacheName, maxAgeSeconds = 0) {
  try {
    const response = await fetch(request);
    if (response.ok && maxAgeSeconds > 0) {
      const cache = await caches.open(cacheName);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    const cached = await caches.match(request);
    if (cached) return cached;
    if (request.mode === 'navigate') {
      const rootCache = await caches.match('/');
      if (rootCache) return rootCache;
    }
    return new Response('You are offline. Please check your connection.', {
      status: 503,
      headers: { 'Content-Type': 'text/plain' },
    });
  }
}
